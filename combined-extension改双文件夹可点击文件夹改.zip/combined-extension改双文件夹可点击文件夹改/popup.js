document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.getElementById('list');
    const searchInput = document.getElementById('searchInput');
    const saveBtn = document.getElementById('saveBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const configBtn = document.getElementById('configBtn');
    const settingsSection = document.getElementById('settingsSection');
    const readFolderSelect = document.getElementById('readFolderSelect');
    const archiveFolderSelect = document.getElementById('archiveFolderSelect');
    const saveFolderBtn = document.getElementById('saveFolderBtn');
    const viewReadBtn = document.getElementById('viewReadBtn');
    const viewArchiveBtn = document.getElementById('viewArchiveBtn');
    const navBar = document.getElementById('navBar');
    const backBtn = document.getElementById('backBtn');
    const currentPathSpan = document.getElementById('currentPath');

    let currentMode = 'read';         // 'read' or 'archive'
    let readFolderId = null;
    let archiveFolderId = null;

    // 浏览状态
    let currentFolderId = null;
    let folderStack = [];

    // 搜索状态
    let isSearchMode = false;

    // ----- 辅助函数 -----
    function getCleanTitle(title) {
        return title.replace(/^[🔵⚪]\s*/, '');
    }

    function isUnread(title) {
        return title.startsWith('🔵');
    }

    function getRootFolderId() {
        return currentMode === 'read' ? readFolderId : archiveFolderId;
    }

    async function saveFolderIds() {
        await chrome.storage.local.set({ readFolderId, archiveFolderId });
    }

    // ----- 书签树递归搜索（返回匹配的书签数组）-----
    async function searchBookmarks(folderId, query) {
        const results = [];
        const queryLower = query.toLowerCase();
        async function traverse(id) {
            try {
                const children = await chrome.bookmarks.getChildren(id);
                for (const child of children) {
                    if (child.url) {
                        const cleanTitle = getCleanTitle(child.title).toLowerCase();
                        const url = child.url.toLowerCase();
                        if (cleanTitle.includes(queryLower) || url.includes(queryLower)) {
                            results.push(child);
                        }
                    } else {
                        await traverse(child.id);
                    }
                }
            } catch (e) {
                console.error('搜索遍历出错', e);
            }
        }
        await traverse(folderId);
        return results;
    }

    // 渲染搜索结果
    async function renderSearchResults(query) {
        const rootId = getRootFolderId();
        if (!rootId) {
            listEl.innerHTML = '<li style="border:none; color:#666;">请先设置文件夹</li>';
            return;
        }
        listEl.innerHTML = '<li style="border:none; color:#999;">搜索中...</li>';
        const results = await searchBookmarks(rootId, query);
        if (results.length === 0) {
            listEl.innerHTML = '<li style="border:none; color:#999;">未找到匹配的书签</li>';
            return;
        }
        listEl.innerHTML = '';
        for (const item of results) {
            const li = document.createElement('li');
            const unread = isUnread(item.title);
            const displayTitle = getCleanTitle(item.title);
            li.innerHTML = `
                <button class="del-btn">✕</button>
                <div class="status-icon" style="cursor:pointer;">${unread ? '🔵' : '⚪'}</div>
                <div class="item-info">
                    <a href="${item.url}" class="title ${!unread ? 'read-text' : ''}" target="_blank">
                        ${escapeHtml(displayTitle)}
                    </a>
                </div>
            `;
            const titleLink = li.querySelector('.title');
            const iconBtn = li.querySelector('.status-icon');
            titleLink.onclick = async (e) => {
                if (unread) {
                    const newTitle = item.title.replace('🔵', '⚪');
                    await chrome.bookmarks.update(item.id, { title: newTitle });
                    renderSearchResults(query);
                }
            };
            iconBtn.onclick = async () => {
                const newTitle = unread
                    ? item.title.replace('🔵', '⚪')
                    : '🔵 ' + item.title.replace(/^⚪\s*/, '');
                await chrome.bookmarks.update(item.id, { title: newTitle });
                renderSearchResults(query);
            };
            li.querySelector('.del-btn').onclick = async () => {
                await chrome.bookmarks.remove(item.id);
                renderSearchResults(query);
            };
            listEl.appendChild(li);
        }
    }

    // 正常渲染当前文件夹（支持导航和本地过滤）
    async function renderFolderContents(query = '') {
        if (!currentFolderId) {
            const rootId = getRootFolderId();
            if (!rootId) {
                listEl.innerHTML = `<li style="border:none; color:#666;">请点击 ⚙️ 设置 ${currentMode === 'read' ? '稍后阅读' : '标签存档'} 文件夹</li>`;
                navBar.style.display = 'none';
                return;
            } else {
                currentFolderId = rootId;
                folderStack = [];
                await updateNavBar(rootId);
            }
        }
        try {
            await chrome.bookmarks.get(currentFolderId);
        } catch (e) {
            listEl.innerHTML = '<li style="border:none; color:#666;">文件夹已被删除，请重新设置</li>';
            navBar.style.display = 'none';
            return;
        }
        try {
            const children = await chrome.bookmarks.getChildren(currentFolderId);
            let filtered = children;
            if (query) {
                const q = query.toLowerCase();
                filtered = children.filter(item =>
                    getCleanTitle(item.title).toLowerCase().includes(q)
                );
            }
            filtered = filtered.reverse();
            listEl.innerHTML = '';
            for (const item of filtered) {
                const li = document.createElement('li');
                const isFolder = !item.url;
                const unread = !isFolder && isUnread(item.title);
                const displayTitle = getCleanTitle(item.title);
                li.innerHTML = `
                    <button class="del-btn">✕</button>
                    <div class="status-icon" style="cursor:pointer;">${isFolder ? '📁' : (unread ? '🔵' : '⚪')}</div>
                    <div class="item-info">
                        <a href="${isFolder ? '#' : item.url}" class="title ${!unread && !isFolder ? 'read-text' : ''}" target="_blank">
                            ${escapeHtml(displayTitle)}
                        </a>
                    </div>
                `;
                const titleLink = li.querySelector('.title');
                const iconBtn = li.querySelector('.status-icon');
                if (isFolder) {
                    const enterHandler = (e) => {
                        e.preventDefault();
                        openFolder(item.id, item.title);
                    };
                    titleLink.onclick = enterHandler;
                    iconBtn.onclick = enterHandler;
                } else {
                    titleLink.onclick = async (e) => {
                        if (unread) {
                            const newTitle = item.title.replace('🔵', '⚪');
                            await chrome.bookmarks.update(item.id, { title: newTitle });
                            renderFolderContents(searchInput.value);
                        }
                    };
                    iconBtn.onclick = async () => {
                        const newTitle = unread
                            ? item.title.replace('🔵', '⚪')
                            : '🔵 ' + item.title.replace(/^⚪\s*/, '');
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                        renderFolderContents(searchInput.value);
                    };
                }
                li.querySelector('.del-btn').onclick = async () => {
                    if (isFolder) {
                        await chrome.bookmarks.removeTree(item.id);
                        if (item.id === currentFolderId || folderStack.some(f => f.id === item.id)) {
                            await resetNavigation();
                        } else {
                            renderFolderContents(searchInput.value);
                        }
                    } else {
                        await chrome.bookmarks.remove(item.id);
                        renderFolderContents(searchInput.value);
                    }
                };
                listEl.appendChild(li);
            }
            if (filtered.length === 0) {
                listEl.innerHTML = '<li style="border:none; color:#999;">暂无内容</li>';
            }
        } catch (e) {
            console.error(e);
            listEl.innerHTML = '<li style="border:none;">加载失败</li>';
        }
    }

    // 统一渲染入口
    async function renderList() {
        const query = searchInput.value;
        if (isSearchMode && query.trim() !== '') {
            await renderSearchResults(query);
        } else {
            if (isSearchMode) {
                isSearchMode = false;
                navBar.style.display = (currentFolderId && currentFolderId !== getRootFolderId()) ? 'flex' : 'none';
            }
            await renderFolderContents(query);
        }
    }

    // 搜索输入事件
    function onSearchInput() {
        const query = searchInput.value;
        if (query.trim() !== '') {
            isSearchMode = true;
            navBar.style.display = 'none';
            renderSearchResults(query);
        } else {
            isSearchMode = false;
            if (currentFolderId) {
                navBar.style.display = (currentFolderId !== getRootFolderId()) ? 'flex' : 'none';
            } else {
                navBar.style.display = 'none';
            }
            renderFolderContents('');
        }
    }

    // 导航相关函数
    async function updateNavBar(folderId) {
        if (!folderId) {
            navBar.style.display = 'none';
            return;
        }
        const rootId = getRootFolderId();
        if (folderId === rootId && folderStack.length === 0) {
            navBar.style.display = 'none';
            return;
        }
        navBar.style.display = 'flex';
        try {
            const node = await chrome.bookmarks.get(folderId);
            if (node && node[0]) {
                currentPathSpan.textContent = node[0].title || '未命名';
            } else {
                currentPathSpan.textContent = '文件夹';
            }
        } catch (e) {
            currentPathSpan.textContent = '文件夹';
        }
    }

    async function openFolder(folderId, folderTitle) {
        if (!folderId) return;
        if (currentFolderId) {
            let currentTitle = '根目录';
            try {
                const node = await chrome.bookmarks.get(currentFolderId);
                if (node && node[0]) currentTitle = node[0].title;
            } catch (e) {}
            folderStack.push({ id: currentFolderId, title: currentTitle });
        }
        currentFolderId = folderId;
        await updateNavBar(folderId);
        searchInput.value = '';
        isSearchMode = false;
        renderFolderContents('');
    }

    async function goBack() {
        if (folderStack.length === 0) {
            const rootId = getRootFolderId();
            if (rootId) {
                currentFolderId = rootId;
                folderStack = [];
                await updateNavBar(rootId);
                searchInput.value = '';
                isSearchMode = false;
                renderFolderContents('');
            }
        } else {
            const parent = folderStack.pop();
            currentFolderId = parent.id;
            await updateNavBar(parent.id);
            searchInput.value = '';
            isSearchMode = false;
            renderFolderContents('');
        }
    }

    async function resetNavigation() {
        const rootId = getRootFolderId();
        if (rootId) {
            currentFolderId = rootId;
            folderStack = [];
            await updateNavBar(rootId);
            searchInput.value = '';
            isSearchMode = false;
            renderFolderContents('');
        }
    }

    backBtn.onclick = goBack;

    function escapeHtml(str) {
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // ----- 保存与存档 -----
    saveBtn.onclick = async () => {
        if (!readFolderId) {
            alert('请先在设置中指定“稍后阅读文件夹”');
            return;
        }
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.bookmarks.create({
            parentId: readFolderId,
            title: "🔵 " + tab.title,
            url: tab.url
        });
        if (currentMode === 'read') {
            await resetNavigation();
        } else {
            alert('已保存到稍后阅读文件夹，当前视图为存档列表，可切换查看');
        }
    };

    archiveBtn.onclick = async () => {
        if (!archiveFolderId) {
            alert('请先在设置中指定“标签存档文件夹”');
            return;
        }
        const tabs = await chrome.tabs.query({ currentWindow: true });
        const timestamp = new Date().toLocaleString('zh-CN', { hour12: false });
        const newFolder = await chrome.bookmarks.create({ parentId: archiveFolderId, title: timestamp });
        for (const tab of tabs) {
            if (tab.url.startsWith('http')) {
                await chrome.bookmarks.create({ parentId: newFolder.id, title: "🔵 " + tab.title, url: tab.url });
            }
        }
        if (currentMode === 'archive') {
            await resetNavigation();
        } else {
            alert('已存档到指定文件夹，当前视图为待读列表，可切换查看');
        }
    };

    // ----- 设置面板 -----
    async function populateFolderSelects() {
        const tree = await chrome.bookmarks.getTree();
        const walk = (nodes, depth = 0, selectEl) => {
            nodes.forEach(n => {
                if (!n.url) {
                    const opt = document.createElement('option');
                    opt.value = n.id;
                    opt.textContent = "\u00A0".repeat(depth * 2) + (n.title || "书签栏");
                    selectEl.appendChild(opt);
                    if (n.children) walk(n.children, depth + 1, selectEl);
                }
            });
        };
        readFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        archiveFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        walk(tree, 0, readFolderSelect);
        walk(tree, 0, archiveFolderSelect);
        if (readFolderId) readFolderSelect.value = readFolderId;
        if (archiveFolderId) archiveFolderSelect.value = archiveFolderId;
    }

    async function toggleSettings(force = false) {
        const show = force || window.getComputedStyle(settingsSection).display === 'none';
        settingsSection.style.display = show ? 'block' : 'none';
        if (show) await populateFolderSelects();
    }
    configBtn.onclick = () => toggleSettings();

    saveFolderBtn.onclick = async () => {
        const newReadId = readFolderSelect.value;
        const newArchiveId = archiveFolderSelect.value;
        if (!newReadId || !newArchiveId) {
            alert('请为两个文件夹都选择目录');
            return;
        }
        readFolderId = newReadId;
        archiveFolderId = newArchiveId;
        await saveFolderIds();
        settingsSection.style.display = 'none';
        await resetNavigation();
    };

    // ----- 模式切换 -----
    function setMode(mode) {
        currentMode = mode;
        if (mode === 'read') {
            viewReadBtn.classList.add('active');
            viewArchiveBtn.classList.remove('active');
        } else {
            viewArchiveBtn.classList.add('active');
            viewReadBtn.classList.remove('active');
        }
        searchInput.value = '';
        isSearchMode = false;
        const rootId = getRootFolderId();
        if (rootId) {
            currentFolderId = rootId;
            folderStack = [];
            updateNavBar(rootId);
            renderFolderContents('');
        } else {
            currentFolderId = null;
            folderStack = [];
            navBar.style.display = 'none';
            renderFolderContents('');
        }
    }

    viewReadBtn.onclick = () => setMode('read');
    viewArchiveBtn.onclick = () => setMode('archive');

    searchInput.oninput = onSearchInput;

    // ----- 加载存储的文件夹ID（兼容旧版）-----
    async function loadFolderIds() {
        const result = await chrome.storage.local.get(['readFolderId', 'archiveFolderId', 'folderId']);
        if (result.folderId && !result.readFolderId && !result.archiveFolderId) {
            readFolderId = result.folderId;
            archiveFolderId = result.folderId;
            await saveFolderIds();
        } else {
            readFolderId = result.readFolderId || null;
            archiveFolderId = result.archiveFolderId || null;
        }
    }

    async function init() {
        await loadFolderIds();
        if (!readFolderId || !archiveFolderId) {
            toggleSettings(true);
            listEl.innerHTML = '<li style="border:none; color:#666;">请完成文件夹设置后使用</li>';
        } else {
            setMode('read');
        }
    }
    init();
});