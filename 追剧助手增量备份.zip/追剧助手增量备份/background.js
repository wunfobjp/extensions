/**
 * 追剧助手 - Background Service Worker (MV3)
 * 功能：
 * 1. 监听进度上报并写入 storage
 * 2. 协助 Iframe 获取父页面标题和 URL (解决跨域匹配问题)
 * 3. 管理图标状态反馈 (REC 角标)，增加节流防止频繁闪烁
 */

// 记录每个标签页最后一次显示角标的时间戳
const lastBadgeTime = new Map();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // --- 逻辑 1：处理进度上报 (UPDATE_FAV) ---
    if (request.action === "UPDATE_FAV") {
        const { series, data } = { 
            series: request.data.series, 
            data: request.data 
        };

        // 从存储中获取现有记录并合并
        chrome.storage.local.get(['favorites'], (res) => {
            let favs = res.favorites || {};
            const oldRecord = favs[series];
            const newRecord = {
                ...data,
                ts: Date.now()
            };
            
            // 检查进度是否有实质性变化（避免无意义更新时闪烁）
            let hasProgressChanged = true;
            if (oldRecord) {
                const timeDiff = Math.abs((oldRecord.time || 0) - (newRecord.time || 0));
                const epChanged = oldRecord.episode !== newRecord.episode;
                // 如果进度变化小于2秒且集数未变，则认为无变化
                if (timeDiff < 2 && !epChanged) {
                    hasProgressChanged = false;
                }
            }
            
            favs[series] = newRecord;
            chrome.storage.local.set({ favorites: favs }, () => {
                // 仅在进度真正变化时才显示角标，并应用节流
                if (hasProgressChanged && sender.tab && sender.tab.id) {
                    showBadgeWithThrottle(sender.tab.id);
                }
            });
        });
    }

    // --- 逻辑 2：解决跨域 Iframe 拿不到父页面标题的问题 (GET_TOP_INFO) ---
    if (request.action === "GET_TOP_INFO") {
        if (sender.tab) {
            sendResponse({
                title: sender.tab.title,
                url: sender.tab.url
            });
        } else {
            sendResponse(null);
        }
    }

    return true; 
});

/**
 * 带节流的角标显示函数
 * @param {number} tabId 
 */
function showBadgeWithThrottle(tabId) {
    if (!tabId) return;
    
    const now = Date.now();
    const lastTime = lastBadgeTime.get(tabId) || 0;
    // 3秒内不重复显示
    if (now - lastTime < 3000) {
        return;
    }
    lastBadgeTime.set(tabId, now);
    
    // 设置角标文字和颜色
    chrome.action.setBadgeText({ text: "REC", tabId: tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#00aeec", tabId: tabId });

    // 2秒后清除
    setTimeout(() => {
        chrome.tabs.get(tabId, (tab) => {
            if (!chrome.runtime.lastError && tab) {
                // 清除前检查是否还是同一个角标，避免误清除其他操作设置的角标
                chrome.action.getBadgeText({ tabId: tabId }, (currentText) => {
                    if (currentText === "REC") {
                        chrome.action.setBadgeText({ text: "", tabId: tabId });
                    }
                });
            }
        });
    }, 2000);
}

// 插件安装或更新时的初始化
chrome.runtime.onInstalled.addListener(() => {
    console.log("追剧助手已就绪！");
});