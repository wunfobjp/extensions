// ========== 配置 ==========
const BATCH_SIZE = 500;
const MAX_TOTAL_LIMIT = 10000;

// ========== 状态变量 ==========
let mode = 'current';
let currentDomain = '';
let allHistoryItems = [];
let oldestTimeInResults = 0;
let isLoading = false;
let hasMore = true;

// ========== DOM 元素 ==========
const tabCurrentBtn = document.getElementById('tab-current');
const tabAllBtn = document.getElementById('tab-all');
const searchInput = document.getElementById('search-input');
const resultsList = document.getElementById('results');
const emptyMsg = document.getElementById('empty-message');
const loadMoreBtn = document.getElementById('load-more');

// ========== 工具函数 ==========
function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

// 获取 favicon URL（使用 Google 的 favicon 服务，稳定可靠）
function getFaviconUrl(url) {
  try {
    const domain = getDomain(url);
    if (!domain) return '';
    return `https://www.google.com/s2/favicons?domain=${domain}&sz=16`;
  } catch {
    return '';
  }
}

// 前端关键词过滤
function filterItems(items, query) {
  const q = query.trim().toLowerCase();
  if (!q) return items;
  return items.filter(item =>
    (item.title && item.title.toLowerCase().includes(q)) ||
    (item.url && item.url.toLowerCase().includes(q))
  );
}

// 域名二次过滤（补足 text 查询的模糊性）
function domainFilter(items) {
  if (mode === 'current' && currentDomain) {
    return items.filter(item => getDomain(item.url) === currentDomain);
  }
  return items;
}

// ========== 渲染列表 ==========
function render(items) {
  resultsList.innerHTML = '';
  if (items.length === 0) {
    emptyMsg.classList.add('visible');
  } else {
    emptyMsg.classList.remove('visible');
    items.forEach(item => {
      const li = document.createElement('li');

      // favicon 图标
      const favicon = document.createElement('img');
      favicon.className = 'favicon';
      favicon.src = getFaviconUrl(item.url);
      favicon.alt = '';
      favicon.onerror = () => {
        // 加载失败则隐藏该图标
        favicon.style.display = 'none';
      };

      // 文本容器
      const textWrapper = document.createElement('div');
      textWrapper.className = 'text-wrapper';

      const link = document.createElement('a');
      link.href = item.url;
      link.textContent = item.title || item.url;
      link.target = '_blank';

      const timeSpan = document.createElement('span');
      timeSpan.className = 'time';
      timeSpan.textContent = new Date(item.lastVisitTime).toLocaleString();

      textWrapper.appendChild(link);
      textWrapper.appendChild(timeSpan);

      li.appendChild(favicon);
      li.appendChild(textWrapper);
      resultsList.appendChild(li);
    });
  }
}

// ========== 更新加载更多按钮 ==========
function updateLoadMoreButton() {
  if (!hasMore || allHistoryItems.length >= MAX_TOTAL_LIMIT) {
    loadMoreBtn.style.display = 'none';
    return;
  }
  if (allHistoryItems.length === 0) {
    loadMoreBtn.style.display = 'none';
    return;
  }
  loadMoreBtn.style.display = 'inline-flex';
}

// ========== 数据获取 ==========
async function fetchBatch(startTime, endTime, textFilter = '') {
  const query = {
    text: textFilter,
    startTime: startTime,
    endTime: endTime,
    maxResults: BATCH_SIZE
  };
  try {
    return await chrome.history.search(query);
  } catch (err) {
    console.error('加载历史记录失败:', err);
    return [];
  }
}

// 初始加载（重置状态）
async function loadInitial() {
  // 获取当前域名（仅 current 模式）
  if (mode === 'current') {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      currentDomain = tab?.url ? getDomain(tab.url) : '';
    } catch {
      currentDomain = '';
    }
  } else {
    currentDomain = '';
  }

  allHistoryItems = [];
  oldestTimeInResults = 0;
  hasMore = true;
  isLoading = false;

  const endTime = Date.now();
  const textFilter = (mode === 'current' && currentDomain) ? currentDomain : '';

  isLoading = true;
  updateUI();
  const batch = await fetchBatch(0, endTime, textFilter);
  isLoading = false;

  if (batch.length > 0) {
    allHistoryItems = batch;
    oldestTimeInResults = Math.min(...batch.map(item => item.lastVisitTime));
    hasMore = batch.length >= BATCH_SIZE;
  } else {
    hasMore = false;
  }
  updateUI();
}

// 加载更多
async function loadMore() {
  if (isLoading || !hasMore || allHistoryItems.length === 0) return;

  isLoading = true;
  updateUI();

  const textFilter = (mode === 'current' && currentDomain) ? currentDomain : '';
  const nextEndTime = oldestTimeInResults - 1;
  const batch = await fetchBatch(0, nextEndTime, textFilter);
  isLoading = false;

  if (batch.length > 0) {
    allHistoryItems = allHistoryItems.concat(batch);
    oldestTimeInResults = Math.min(...batch.map(item => item.lastVisitTime));
    hasMore = batch.length >= BATCH_SIZE && allHistoryItems.length < MAX_TOTAL_LIMIT;
  } else {
    hasMore = false;
  }
  updateUI();
}

// ========== 综合 UI 更新 ==========
function updateUI() {
  const baseItems = domainFilter(allHistoryItems);
  const searchText = searchInput.value;
  const displayed = filterItems(baseItems, searchText);
  render(displayed);
  updateLoadMoreButton();

  // 更新加载按钮文字与旋转动画
  const btnText = loadMoreBtn.querySelector('.btn-text');
  const spinner = loadMoreBtn.querySelector('.spinner');
  if (isLoading) {
    btnText.textContent = '加载中…';
    spinner.style.display = 'inline-block';
    loadMoreBtn.disabled = true;
  } else {
    btnText.textContent = '加载更早记录';
    spinner.style.display = 'none';
    loadMoreBtn.disabled = false;
  }
}

// ========== 模式切换 ==========
async function switchMode(newMode) {
  if (mode === newMode) return;
  mode = newMode;
  tabCurrentBtn.classList.toggle('active', mode === 'current');
  tabAllBtn.classList.toggle('active', mode === 'all');
  await loadInitial();
}

// ========== 事件绑定 ==========
searchInput.addEventListener('input', updateUI);
loadMoreBtn.addEventListener('click', loadMore);
tabCurrentBtn.addEventListener('click', () => switchMode('current'));
tabAllBtn.addEventListener('click', () => switchMode('all'));

// 页面初始化
document.addEventListener('DOMContentLoaded', () => {
  switchMode('current');
});