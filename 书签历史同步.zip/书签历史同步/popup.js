const statusDiv = document.getElementById('status');
const bookmarkLocalSpan = document.getElementById('bookmarkLocal');
const bookmarkRemoteSpan = document.getElementById('bookmarkRemote');

function setStatus(text, isError = false) {
  statusDiv.textContent = text;
  statusDiv.className = isError ? 'status error' : 'status';
  setTimeout(() => {
    if (statusDiv.textContent === text) {
      statusDiv.textContent = '就绪';
      statusDiv.className = 'status';
    }
  }, 4000);
}

async function sendMessage(action, loadingText) {
  if (!chrome.runtime?.id) {
    setStatus('扩展上下文失效，请重新打开', true);
    return { success: false };
  }
  setStatus(loadingText);
  try {
    const result = await chrome.runtime.sendMessage({ action });
    setStatus(result.message, !result.success);
    return result;
  } catch (err) {
    setStatus('操作失败: ' + err.message, true);
    return { success: false, message: err.message };
  }
}

async function refreshBookmarkStats() {
  try {
    const stats = await chrome.runtime.sendMessage({ action: 'getBookmarkStats' });
    bookmarkLocalSpan.textContent = stats.local ?? '?';
    bookmarkRemoteSpan.textContent = stats.remote ?? '?';
  } catch {
    bookmarkLocalSpan.textContent = '?';
    bookmarkRemoteSpan.textContent = '?';
  }
}

// 绑定按钮事件
document.getElementById('bookmarksUpload').addEventListener('click', async () => {
  await sendMessage('bookmarksUpload', '书签上传中...');
  await refreshBookmarkStats();
});

document.getElementById('bookmarksDownload').addEventListener('click', async () => {
  await sendMessage('bookmarksDownload', '书签下载中...');
  await refreshBookmarkStats();
});

document.getElementById('bookmarksClear').addEventListener('click', async () => {
  if (!confirm('确定清空所有书签吗？（书签栏、其他书签、移动书签将被完全清空）')) return;
  await sendMessage('bookmarksClear', '清空书签中...');
  await refreshBookmarkStats();
});

document.getElementById('historyIncremental').addEventListener('click', () => {
  sendMessage('incrementalBackup', '合并上传中...');
});

document.getElementById('historyDownload').addEventListener('click', () => {
  sendMessage('fullDownload', '全量下载中...');
});

document.getElementById('historyFullBackup').addEventListener('click', () => {
  sendMessage('fullBackup', '全量上传中...');
});

document.getElementById('btnSettings').addEventListener('click', () => {
  if (chrome.runtime?.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    setStatus('无法打开设置页', true);
  }
});

// 初始化统计
refreshBookmarkStats();