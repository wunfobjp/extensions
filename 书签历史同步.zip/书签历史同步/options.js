// 选项页逻辑
const { STORAGE_KEYS, getStorage, setStorage, getSyncStorage, setSyncStorage, showNotification } = self.Common;
const WebDAVClient = self.WebDAVClient;

// DOM 元素
const urlInput = document.getElementById('webdavUrl');
const userInput = document.getElementById('webdavUser');
const passInput = document.getElementById('webdavPass');
const testBtn = document.getElementById('testBtn');
const fullUploadBtn = document.getElementById('fullUploadBtn');
const fullDownloadBtn = document.getElementById('fullDownloadBtn');
const mergeUploadBtn = document.getElementById('mergeUploadBtn');
const connectionStatusSpan = document.getElementById('connectionStatus');

// 书签专属设置
const bookmarksRemotePathInput = document.getElementById('bookmarksRemotePath');
const swapBookmarkMobileCheck = document.getElementById('swapBookmarkMobile');

// 默认书签设置
const DEFAULT_BOOKMARKS_SETTINGS = {
  remotePath: '/bookmarks.json',
  swapBookmarkMobile: false,
  lastSync: 0
};

// 加载所有设置
async function loadSettings() {
  // WebDAV 通用配置
  const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
  const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
  const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
  if (url) urlInput.value = url;
  if (user) userInput.value = user;
  if (pass) passInput.value = pass;

  // 书签设置
  const bookmarksSettings = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS) || DEFAULT_BOOKMARKS_SETTINGS;
  bookmarksRemotePathInput.value = bookmarksSettings.remotePath || '/bookmarks.json';
  swapBookmarkMobileCheck.checked = bookmarksSettings.swapBookmarkMobile || false;

  await checkConnectionStatus();
}

// 保存 WebDAV 通用配置
async function saveWebDAVSettings() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    showNotification('设置', '请填写完整的 WebDAV 信息');
    return false;
  }
  await setStorage(STORAGE_KEYS.WEBDAV_URL, url);
  await setStorage(STORAGE_KEYS.WEBDAV_USER, user);
  await setStorage(STORAGE_KEYS.WEBDAV_PASS, pass);
  return true;
}

// 保存书签设置（不覆盖 lastSync）
async function saveBookmarksSettings() {
  const current = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS) || DEFAULT_BOOKMARKS_SETTINGS;
  const newSettings = {
    ...current,
    remotePath: bookmarksRemotePathInput.value.trim() || '/bookmarks.json',
    swapBookmarkMobile: swapBookmarkMobileCheck.checked
  };
  await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, newSettings);
}

// 连接状态检测
async function checkConnectionStatus() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    connectionStatusSpan.textContent = '未连接';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
  const client = new WebDAVClient(url, user, pass);
  try {
    const ok = await client.testConnection(STORAGE_KEYS.HISTORY_BACKUP_FILE);
    if (ok) {
      connectionStatusSpan.textContent = '已连接';
      connectionStatusSpan.className = 'connected';
      return true;
    } else {
      connectionStatusSpan.textContent = '连接失败';
      connectionStatusSpan.className = 'disconnected';
      return false;
    }
  } catch (e) {
    connectionStatusSpan.textContent = '连接失败';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
}

// 事件绑定
testBtn.addEventListener('click', async () => {
  if (!(await saveWebDAVSettings())) return;
  await saveBookmarksSettings();
  connectionStatusSpan.textContent = '测试中...';
  const connected = await checkConnectionStatus();
  showNotification('WebDAV', connected ? '连接成功！' : '连接失败，请检查配置');
});

// 历史记录操作（触发 background 消息）
async function runHistoryAction(action, btn, loadingText) {
  if (!(await saveWebDAVSettings())) return;
  const connected = await checkConnectionStatus();
  if (!connected) {
    showNotification('操作失败', '请先成功连接 WebDAV');
    return;
  }
  btn.disabled = true;
  const originalText = btn.textContent;
  btn.textContent = loadingText;
  try {
    const result = await chrome.runtime.sendMessage({ action });
    showNotification(action, result.message);
    if (result.success) await checkConnectionStatus();
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
}

fullUploadBtn.addEventListener('click', () => runHistoryAction('fullBackup', fullUploadBtn, '上传中...'));
fullDownloadBtn.addEventListener('click', () => runHistoryAction('fullDownload', fullDownloadBtn, '下载中...'));
mergeUploadBtn.addEventListener('click', () => runHistoryAction('incrementalBackup', mergeUploadBtn, '合并中...'));

// 当输入框变化时自动保存书签设置（简化，也可在测试连接时保存）
bookmarksRemotePathInput.addEventListener('change', saveBookmarksSettings);
swapBookmarkMobileCheck.addEventListener('change', saveBookmarksSettings);

// 初始化
loadSettings();