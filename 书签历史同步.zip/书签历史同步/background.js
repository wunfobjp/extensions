// 导入公共模块和同步模块
importScripts(
  'common.js',
  'webdav-client.js',
  'bookmarks-sync.js',
  'history-sync.js'
);

// 消息路由
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { action } = message;

  // 历史记录相关
  if (action === 'incrementalBackup') {
    self.HistorySync.incrementalBackup().then(sendResponse);
    return true;
  }
  if (action === 'fullDownload') {
    self.HistorySync.fullDownload().then(sendResponse);
    return true;
  }
  if (action === 'fullBackup') {
    self.HistorySync.fullBackup().then(sendResponse);
    return true;
  }

  // 书签相关
  if (action === 'bookmarksUpload') {
    self.BookmarksSync.uploadBookmarks().then(sendResponse);
    return true;
  }
  if (action === 'bookmarksDownload') {
    self.BookmarksSync.downloadBookmarks().then(sendResponse);
    return true;
  }
  if (action === 'bookmarksClear') {
    self.BookmarksSync.clearAllBookmarks().then(sendResponse);
    return true;
  }
  if (action === 'getBookmarkStats') {
    self.BookmarksSync.getStats().then(sendResponse);
    return true;
  }

  return false;
});