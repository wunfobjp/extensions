// 公共工具函数和存储键常量
self.Common = (function() {
  const STORAGE_KEYS = {
    // WebDAV 配置（共用）
    WEBDAV_URL: 'webdav_url',
    WEBDAV_USER: 'webdav_user',
    WEBDAV_PASS: 'webdav_pass',
    // 历史记录专用
    LAST_SYNC_TIME: 'last_sync_time',
    HISTORY_BACKUP_FILE: 'history_backup.json',
    // 书签专用
    BOOKMARKS_SETTINGS: 'bookmarks_settings',      // 书签扩展设置（remotePath, swapBookmarkMobile）
    BOOKMARKS_META: 'bookmarksMeta',               // 书签元数据（GUID映射等）
    BOOKMARKS_BACKUP_FILE: 'bookmarks.json'        // 默认文件名，实际从设置读取
  };

  async function getStorage(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }

  async function setStorage(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  async function getSyncStorage(key) {
    const result = await chrome.storage.sync.get(key);
    return result[key];
  }

  async function setSyncStorage(key, value) {
    await chrome.storage.sync.set({ [key]: value });
  }

  function showNotification(title, message, type = 'basic') {
    chrome.notifications.create({
      type: type,
      iconUrl: 'icons/icon48.png',
      title: title,
      message: message,
      priority: 2
    }).catch(() => {});
  }

  return {
    STORAGE_KEYS,
    getStorage,
    setStorage,
    getSyncStorage,
    setSyncStorage,
    showNotification
  };
})();