// ==================== 内联工具函数 ====================

const NOTES_STORAGE_KEY = 'gistNotes';
const SETTINGS_STORAGE_KEY = 'gistSettings';
const GIST_FILENAME = 'notes.json';
const GIST_API_BASE = 'https://api.github.com';

// ---------- Storage ----------
async function getAllNotes() {
  const result = await chrome.storage.local.get(NOTES_STORAGE_KEY);
  return result[NOTES_STORAGE_KEY] || [];
}

async function saveAllNotes(notes) {
  await chrome.storage.local.set({ [NOTES_STORAGE_KEY]: notes });
}

async function saveNote(id, note) {
  const notes = await getAllNotes();
  const index = notes.findIndex(n => n.id === id);
  if (index >= 0) {
    notes[index] = note;
  } else {
    notes.push(note);
  }
  await saveAllNotes(notes);
}

async function deleteNote(id) {
  const notes = await getAllNotes();
  const filtered = notes.filter(n => n.id !== id);
  await saveAllNotes(filtered);
}

async function getSettings() {
  const result = await chrome.storage.sync.get(SETTINGS_STORAGE_KEY);
  return result[SETTINGS_STORAGE_KEY] || {};
}

async function saveSettingsToStorage(settings) {
  await chrome.storage.sync.set({ [SETTINGS_STORAGE_KEY]: settings });
}

// ---------- Gist API ----------
async function fetchGistContent(gistId, token, filename) {
  const response = await fetch(`${GIST_API_BASE}/gists/${gistId}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  if (!response.ok) throw new Error(`获取 Gist 失败: ${response.status}`);
  const gist = await response.json();
  const file = gist.files[filename];
  return file ? file.content : null;
}

async function updateOrCreateGist(gistId, token, filename, content) {
  const files = { [filename]: { content } };
  let response;
  if (gistId) {
    response = await fetch(`${GIST_API_BASE}/gists/${gistId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ files })
    });
  } else {
    response = await fetch(`${GIST_API_BASE}/gists`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: 'Gist Notes Sync Data',
        public: false,
        files
      })
    });
  }
  if (!response.ok) throw new Error(`更新/创建 Gist 失败: ${response.status}`);
  const result = await response.json();
  if (!gistId) {
    const settings = await getSettings();
    settings.gistId = result.id;
    await saveSettingsToStorage(settings);
  }
  return result;
}

// ---------- 加密 ----------
async function encryptData(plaintext, password) {
  const encoder = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt);
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    encoder.encode(plaintext)
  );
  const combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
  combined.set(salt, 0);
  combined.set(iv, salt.length);
  combined.set(new Uint8Array(encrypted), salt.length + iv.length);
  return btoa(String.fromCharCode(...combined));
}

async function decryptData(encryptedBase64, password) {
  const decoder = new TextDecoder();
  const combined = Uint8Array.from(atob(encryptedBase64), c => c.charCodeAt(0));
  const salt = combined.slice(0, 16);
  const iv = combined.slice(16, 28);
  const data = combined.slice(28);
  const key = await deriveKey(password, salt);
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    data
  );
  return decoder.decode(decrypted);
}

async function deriveKey(password, salt) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

// ==================== 同步核心（本地强制覆盖） ====================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncNow') {
    performSync().then(sendResponse).catch(e => sendResponse({ success: false, message: e.message }));
    return true;
  }
  if (request.action === 'updateNote') {
    handleNoteUpdate(request.note).then(sendResponse);
    return true;
  }
  if (request.action === 'deleteNote') {
    handleNoteDelete(request.id).then(sendResponse);
    return true;
  }
});

async function performSync() {
  try {
    const settings = await getSettings();
    if (!settings.token) {
      return { success: false, message: '未配置 GitHub Token' };
    }

    // 获取本地笔记（当前真实状态）
    const localNotes = await getAllNotes();

    // 获取远程 Gist 内容（仅用于判断是否需要更新）
    let remoteContent = null;
    try {
      if (settings.gistId) {
        remoteContent = await fetchGistContent(settings.gistId, settings.token, GIST_FILENAME);
      }
    } catch (e) {
      if (!e.message.includes('404')) throw e;
    }

    let remoteNotes = [];
    if (remoteContent) {
      try {
        const decrypted = settings.encryptPassword 
          ? await decryptData(remoteContent, settings.encryptPassword)
          : remoteContent;
        remoteNotes = JSON.parse(decrypted);
      } catch (e) {
        console.warn('解密失败，视为远程无效');
      }
    }

    // ⭐ 关键修改：如果本地与远程内容不同，直接以本地覆盖远程
    const localJson = JSON.stringify(localNotes);
    const remoteJson = JSON.stringify(remoteNotes);
    if (localJson !== remoteJson) {
      await uploadMergedNotes(settings, localNotes);
      console.log('本地与远程不一致，已用本地覆盖远程');
    } else {
      console.log('本地与远程一致，无需上传');
    }

    return { success: true, message: `同步成功 (${localNotes.length} 条笔记)` };
  } catch (error) {
    console.error('同步失败:', error);
    return { success: false, message: error.message };
  }
}

async function handleNoteUpdate(note) {
  await saveNote(note.id, note);
  return await performSync();
}

async function handleNoteDelete(id) {
  await deleteNote(id);
  return await performSync();
}

async function uploadMergedNotes(settings, notes) {
  const content = JSON.stringify(notes);
  const dataToUpload = settings.encryptPassword 
    ? await encryptData(content, settings.encryptPassword)
    : content;
  await updateOrCreateGist(settings.gistId, settings.token, GIST_FILENAME, dataToUpload);
}