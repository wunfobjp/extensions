document.addEventListener('DOMContentLoaded', loadSettings);

document.getElementById('saveBtn').addEventListener('click', saveSettings);
document.getElementById('resetBtn').addEventListener('click', resetSettings);
document.getElementById('testConnectionBtn').addEventListener('click', testConnection);

async function loadSettings() {
  const settings = await getSettings();
  document.getElementById('githubToken').value = settings.token || '';
  document.getElementById('gistId').value = settings.gistId || '';
  document.getElementById('encryptPassword').value = settings.encryptPassword || '';
}

async function saveSettings() {
  const token = document.getElementById('githubToken').value.trim();
  const gistId = document.getElementById('gistId').value.trim();
  const encryptPassword = document.getElementById('encryptPassword').value;
  
  if (!token) {
    showStatus('请输入 GitHub Token', 'error');
    return;
  }
  
  const settings = { token, gistId, encryptPassword };
  await saveSettingsToStorage(settings);
  showStatus('设置已保存', 'success');
}

async function resetSettings() {
  if (!confirm('确定重置所有设置吗？')) return;
  await chrome.storage.sync.clear();
  await chrome.storage.local.remove('gistNotes');
  document.getElementById('githubToken').value = '';
  document.getElementById('gistId').value = '';
  document.getElementById('encryptPassword').value = '';
  showStatus('设置已重置', 'success');
}

async function testConnection() {
  const token = document.getElementById('githubToken').value.trim();
  if (!token) {
    document.getElementById('testResult').textContent = '请先输入 Token';
    return;
  }
  
  document.getElementById('testResult').textContent = '测试中...';
  
  try {
    const response = await fetch('https://api.github.com/user', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (response.ok) {
      const user = await response.json();
      document.getElementById('testResult').textContent = `✅ 连接成功，用户: ${user.login}`;
    } else {
      document.getElementById('testResult').textContent = '❌ Token 无效';
    }
  } catch (e) {
    document.getElementById('testResult').textContent = '❌ 网络错误';
  }
}

function showStatus(message, type) {
  const el = document.getElementById('statusMessage');
  el.textContent = message;
  el.className = type;
  setTimeout(() => {
    el.textContent = '';
    el.className = '';
  }, 3000);
}