// 生成唯一 ID
function generateId() {
  return Date.now() + '-' + Math.random().toString(36).substr(2, 9);
}

let currentEditingId = null;
let currentViewMode = 'edit';

// 配置 marked（如果库已加载）
if (typeof marked !== 'undefined') {
  marked.setOptions({
    highlight: function(code, lang) {
      if (typeof hljs !== 'undefined') {
        if (lang && hljs.getLanguage(lang)) {
          return hljs.highlight(code, { language: lang }).value;
        }
        return hljs.highlightAuto(code).value;
      }
      return code;
    },
    breaks: true,
    gfm: true
  });
}

document.addEventListener('DOMContentLoaded', init);

async function init() {
  await loadNotesList();
  
  document.getElementById('settingsBtn').addEventListener('click', openSettings);
  document.getElementById('syncBtn').addEventListener('click', syncNow);
  document.getElementById('newNoteBtn').addEventListener('click', createNewNote);
  document.getElementById('saveNoteBtn').addEventListener('click', saveCurrentNote);
  document.getElementById('cancelEditBtn').addEventListener('click', cancelEdit);
  document.getElementById('deleteNoteBtn').addEventListener('click', deleteCurrentNote);
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchViewMode(btn.dataset.tab));
  });
  
  document.getElementById('noteContent').addEventListener('input', updatePreview);
}

function openSettings() {
  chrome.runtime.openOptionsPage();
}

async function loadNotesList() {
  const notes = await getAllNotes();
  const container = document.getElementById('notesList');
  
  if (notes.length === 0) {
    container.innerHTML = '<p style="text-align:center;color:#7f8c8d;">暂无笔记，点击"新建"开始</p>';
    return;
  }
  
  notes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  
  container.innerHTML = notes.map(note => `
    <div class="note-item" data-id="${note.id}">
      <h3>${escapeHtml(note.title || '无标题')}</h3>
      <p>${escapeHtml(note.content.substring(0, 50))}${note.content.length > 50 ? '...' : ''}</p>
      <small>${formatTime(note.updatedAt)}</small>
    </div>
  `).join('');
  
  document.querySelectorAll('.note-item').forEach(el => {
    el.addEventListener('click', () => editNote(el.dataset.id));
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function formatTime(isoString) {
  const date = new Date(isoString);
  return date.toLocaleString();
}

async function syncNow() {
  setStatus('同步中...');
  try {
    const result = await chrome.runtime.sendMessage({ action: 'syncNow' });
    setStatus(result.message);
  } catch (e) {
    setStatus('同步失败');
  }
  await loadNotesList();
  setTimeout(() => setStatus(''), 3000);
}

function setStatus(text) {
  document.getElementById('syncStatus').textContent = text;
}

function createNewNote() {
  currentEditingId = generateId();
  showEditor({
    id: currentEditingId,
    title: '',
    content: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
  switchViewMode('edit');
}

async function editNote(id) {
  const notes = await getAllNotes();
  const note = notes.find(n => n.id === id);
  if (note) {
    currentEditingId = id;
    showEditor(note);
    switchViewMode('edit');
  }
}

function showEditor(note) {
  document.getElementById('notesList').classList.add('hidden');
  document.getElementById('editorPanel').classList.remove('hidden');
  document.getElementById('noteTitle').value = note.title || '';
  document.getElementById('noteContent').value = note.content || '';
  updatePreview();
}

function cancelEdit() {
  document.getElementById('notesList').classList.remove('hidden');
  document.getElementById('editorPanel').classList.add('hidden');
  currentEditingId = null;
}

async function saveCurrentNote() {
  const title = document.getElementById('noteTitle').value.trim();
  const content = document.getElementById('noteContent').value;
  
  if (!title && !content) {
    alert('请至少输入标题或内容');
    return;
  }
  
  const notes = await getAllNotes();
  const existingIndex = notes.findIndex(n => n.id === currentEditingId);
  const now = new Date().toISOString();
  
  const note = {
    id: currentEditingId,
    title: title || '无标题',
    content: content,
    createdAt: existingIndex >= 0 ? notes[existingIndex].createdAt : now,
    updatedAt: now
  };
  
  setStatus('保存中...');
  await saveNote(note.id, note);
  
  const result = await chrome.runtime.sendMessage({ action: 'syncNow' });
  setStatus(result.message || '保存成功');
  
  cancelEdit();
  await loadNotesList();
  setTimeout(() => setStatus(''), 3000);
}

async function deleteCurrentNote() {
  if (!currentEditingId) return;
  if (!confirm('确定删除这条笔记吗？')) return;
  
  setStatus('删除中...');
  await deleteNote(currentEditingId);
  
  const result = await chrome.runtime.sendMessage({ action: 'syncNow' });
  setStatus(result.message || '已删除');
  
  cancelEdit();
  await loadNotesList();
  setTimeout(() => setStatus(''), 3000);
}

function switchViewMode(mode) {
  currentViewMode = mode;
  const panel = document.getElementById('editorPanel');
  const editArea = document.getElementById('editArea');
  const previewArea = document.getElementById('previewArea');
  const tabs = document.querySelectorAll('.tab-btn');
  
  tabs.forEach(tab => {
    tab.classList.toggle('active', tab.dataset.tab === mode);
  });
  
  panel.classList.remove('split-view');
  editArea.classList.remove('hidden');
  previewArea.classList.add('hidden');
  
  if (mode === 'preview') {
    editArea.classList.add('hidden');
    previewArea.classList.remove('hidden');
  } else if (mode === 'split') {
    panel.classList.add('split-view');
    previewArea.classList.remove('hidden');
  }
  
  updatePreview();
}

function updatePreview() {
  const content = document.getElementById('noteContent').value;
  const previewArea = document.getElementById('previewArea');
  
  if (typeof marked !== 'undefined') {
    const html = marked.parse(content);
    previewArea.innerHTML = html;
    
    if (typeof hljs !== 'undefined') {
      previewArea.querySelectorAll('pre code').forEach(block => {
        hljs.highlightElement(block);
      });
    }
  } else {
    previewArea.innerHTML = '<p>Markdown 库未加载。</p>';
  }
}