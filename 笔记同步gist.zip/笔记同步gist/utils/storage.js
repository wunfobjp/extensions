// 存储键名
const NOTES_STORAGE_KEY = 'gistNotes';
const SETTINGS_STORAGE_KEY = 'gistSettings';

// 获取所有笔记
async function getAllNotes() {
  const result = await chrome.storage.local.get(NOTES_STORAGE_KEY);
  return result[NOTES_STORAGE_KEY] || [];
}

// 保存所有笔记
async function saveAllNotes(notes) {
  await chrome.storage.local.set({ [NOTES_STORAGE_KEY]: notes });
}

// 保存单条笔记 (更新或新增)
async function saveNote(id, note) {
  const notes = await getAllNotes();
  const index = notes.findIndex(n => n.id === id);
  if (index >= 0) {
    notes[index] = note;
  } else {
    notes.push(note);
  }
  await saveAllNotes(notes);
}

// 删除笔记
async function deleteNote(id) {
  const notes = await getAllNotes();
  const filtered = notes.filter(n => n.id !== id);
  await saveAllNotes(filtered);
}

// 获取设置
async function getSettings() {
  const result = await chrome.storage.sync.get(SETTINGS_STORAGE_KEY);
  return result[SETTINGS_STORAGE_KEY] || {};
}

// 保存设置
async function saveSettingsToStorage(settings) {
  await chrome.storage.sync.set({ [SETTINGS_STORAGE_KEY]: settings });
}