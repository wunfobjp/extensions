const GIST_API_BASE = 'https://api.github.com';

/**
 * 获取 Gist 中指定文件的内容
 */
async function fetchGistContent(gistId, token, filename) {
  const response = await fetch(`${GIST_API_BASE}/gists/${gistId}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  
  if (!response.ok) {
    throw new Error(`获取 Gist 失败: ${response.status}`);
  }
  
  const gist = await response.json();
  const file = gist.files[filename];
  return file ? file.content : null;
}

/**
 * 更新或创建 Gist
 */
async function updateOrCreateGist(gistId, token, filename, content) {
  const files = { [filename]: { content } };
  
  let response;
  if (gistId) {
    // 更新现有 Gist
    response = await fetch(`${GIST_API_BASE}/gists/${gistId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ files })
    });
  } else {
    // 创建新 Gist
    response = await fetch(`${GIST_API_BASE}/gists`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: 'Gist Notes Sync Data',
        public: false,
        files
      })
    });
  }
  
  if (!response.ok) {
    throw new Error(`更新/创建 Gist 失败: ${response.status}`);
  }
  
  const result = await response.json();
  
  // 如果是新建的，自动保存 Gist ID 到设置中
  if (!gistId) {
    const settings = await getSettings();
    settings.gistId = result.id;
    await saveSettingsToStorage(settings);
    console.log('已自动保存新建的 Gist ID:', result.id);
  }
  
  return result;
}