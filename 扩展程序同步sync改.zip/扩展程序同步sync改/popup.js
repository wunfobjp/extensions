// DOM 元素
const backupBtn = document.getElementById('backupBtn');
const restoreBtn = document.getElementById('restoreBtn');
const settingsBtn = document.getElementById('settingsBtn');
const manageBtn = document.getElementById('manageBtn');
const statusDiv = document.getElementById('status');
const statsPanel = document.getElementById('statsPanel');
const searchInput = document.getElementById('searchInput');
const extGrid = document.getElementById('extGrid');

let currentExtensions = [];
let filteredExtensions = [];

function setStatus(msg, isError = false) {
  statusDiv.innerText = msg;
  statusDiv.style.color = isError ? '#d93025' : '#1a73e8';
  statusDiv.style.background = isError ? '#fce8e6' : '#e8f0fe';
  setTimeout(() => {
    if (statusDiv.innerText === msg) setTimeout(() => {}, 3000);
  }, 3000);
}

function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

async function loadExtensions() {
  try {
    const exts = await chrome.management.getAll();
    currentExtensions = exts.filter(ext => ext.type === 'extension');
    applyFilterAndRender();
  } catch (err) {
    setStatus('加载失败: ' + err.message, true);
    extGrid.innerHTML = '<div>加载失败</div>';
  }
}

function applyFilterAndRender() {
  const searchTerm = searchInput.value.trim().toLowerCase();
  filteredExtensions = currentExtensions.filter(ext => 
    ext.name.toLowerCase().includes(searchTerm)
  );
  renderGrid();
  updateStats();
}

function renderGrid() {
  if (!filteredExtensions.length) {
    extGrid.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:20px;">未找到扩展</div>';
    return;
  }
  let html = '';
  for (const ext of filteredExtensions) {
    const enabled = ext.enabled;
    const name = escapeHtml(ext.name);
    const version = ext.version || '?';
    const extId = ext.id;
    const hasOptions = ext.optionsUrl ? true : false;
    const storeUrl = `https://chrome.google.com/webstore/detail/${extId}`;
    html += `
      <div class="ext-card" data-id="${extId}">
        <div class="ext-name">
          <span title="${name} (${extId})">${name}</span>
          <label class="toggle-switch">
            <input type="checkbox" class="ext-toggle" data-id="${extId}" ${enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="ext-version">v${version}</div>
        <div class="ext-controls">
          <div>
            ${hasOptions ? `<button class="ext-options-btn" data-id="${extId}" data-optionsurl="${escapeHtml(ext.optionsUrl)}">⚙️ 选项</button>` : ''}
            <button class="ext-store-btn" data-storeurl="${storeUrl}">🛒 商店</button>
          </div>
          <span class="${enabled ? 'ext-enabled' : 'ext-disabled'}" style="font-size:10px;">${enabled ? '●启用' : '○禁用'}</span>
        </div>
      </div>
    `;
  }
  extGrid.innerHTML = html;

  // 开关事件
  document.querySelectorAll('.ext-toggle').forEach(toggle => {
    toggle.addEventListener('change', async (e) => {
      e.stopPropagation();
      const id = toggle.getAttribute('data-id');
      const newState = toggle.checked;
      try {
        await chrome.management.setEnabled(id, newState);
        const ext = currentExtensions.find(e => e.id === id);
        if (ext) ext.enabled = newState;
        applyFilterAndRender();
        setStatus(`已${newState ? '启用' : '禁用'} ${ext.name}`);
      } catch (err) {
        setStatus(`失败: ${err.message}`, true);
        toggle.checked = !newState;
      }
    });
  });

  // 选项按钮
  document.querySelectorAll('.ext-options-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-optionsurl');
      if (url) chrome.tabs.create({ url });
      else setStatus('无选项页');
    });
  });

  // 商店按钮
  document.querySelectorAll('.ext-store-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-storeurl');
      chrome.tabs.create({ url });
    });
  });
}

function updateStats() {
  const total = currentExtensions.length;
  const enabledCount = currentExtensions.filter(ext => ext.enabled).length;
  const disabledCount = total - enabledCount;
  statsPanel.innerHTML = `
    <span>📦 总计: <span>${total}</span></span>
    <span>✅ 启用: <span>${enabledCount}</span></span>
    <span>❌ 禁用: <span>${disabledCount}</span></span>
  `;
}

// ---------- WebDAV 相关 ----------
async function getDeviceSuffix() {
  const result = await chrome.storage.sync.get('deviceSuffix');
  let suffix = result.deviceSuffix || 'default';
  suffix = suffix.replace(/[^a-zA-Z0-9_-]/g, '');
  return suffix || 'default';
}

async function getWebDavConfig() {
  const result = await chrome.storage.sync.get(['webdavUrl', 'webdavUser', 'webdavPass']);
  if (!result.webdavUrl) throw new Error('未配置 WebDAV 地址');
  return {
    url: result.webdavUrl,
    user: result.webdavUser || '',
    pass: result.webdavPass || ''
  };
}

async function getFullBackupUrl() {
  const config = await getWebDavConfig();
  const suffix = await getDeviceSuffix();
  const fileName = `extensions-backup_${suffix}.json`;
  let base = config.url.trim();
  if (!base.endsWith('/')) base += '/';
  return { url: base + fileName, config };
}

async function takeSnapshot() {
  const exts = await chrome.management.getAll();
  return exts.filter(ext => ext.type === 'extension').map(ext => ({
    id: ext.id,
    name: ext.name,
    enabled: ext.enabled,
    version: ext.version,
    installType: ext.installType
  }));
}

async function uploadSnapshot(snapshot) {
  const { url, config } = await getFullBackupUrl();
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': 'Basic ' + btoa(`${config.user}:${config.pass}`),
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(snapshot, null, 2)
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return true;
}

async function downloadSnapshot() {
  const { url, config } = await getFullBackupUrl();
  const response = await fetch(url, {
    method: 'GET',
    headers: { 'Authorization': 'Basic ' + btoa(`${config.user}:${config.pass}`) }
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.json();
}

async function backup() {
  setStatus('备份中...');
  try {
    const snapshot = await takeSnapshot();
    await uploadSnapshot(snapshot);
    setStatus(`✅ 备份成功 (${snapshot.length} 个扩展)`);
  } catch (err) {
    setStatus('备份失败: ' + err.message, true);
  }
}

async function restore() {
  setStatus('读取快照...');
  let remote;
  try {
    remote = await downloadSnapshot();
  } catch (err) {
    setStatus('读取失败: ' + err.message, true);
    return;
  }
  setStatus('同步中...');
  const localMap = new Map(currentExtensions.map(e => [e.id, e]));
  let changed = 0;
  const missing = [];
  for (const r of remote) {
    const local = localMap.get(r.id);
    if (!local) { missing.push(r); continue; }
    if (local.enabled !== r.enabled) {
      try {
        await chrome.management.setEnabled(r.id, r.enabled);
        local.enabled = r.enabled;
        changed++;
      } catch(e) { console.warn(e); }
    }
  }
  applyFilterAndRender();
  let msg = `恢复完成，调整 ${changed} 个扩展。`;
  if (missing.length) {
    msg += ` 缺失 ${missing.length} 个扩展。`;
    let missingHtml = `<div style="margin-top:8px; border-top:1px solid #ddd; padding-top:5px;"><strong>缺失扩展：</strong><div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:4px;">`;
    for (const ext of missing) {
      const storeLink = `https://chrome.google.com/webstore/detail/${ext.id}`;
      missingHtml += `<a href="${storeLink}" target="_blank" style="background:#fce8e6; border-radius:16px; padding:2px 8px; font-size:10px; text-decoration:none; color:#d93025;">${escapeHtml(ext.name)}</a>`;
    }
    missingHtml += `</div></div>`;
    const oldDiv = document.getElementById('missingDiv');
    if (oldDiv) oldDiv.remove();
    const newDiv = document.createElement('div');
    newDiv.id = 'missingDiv';
    newDiv.innerHTML = missingHtml;
    extGrid.parentNode.insertBefore(newDiv, extGrid.nextSibling);
    chrome.notifications.create({ type: 'basic', iconUrl: 'icon.png', title: '扩展同步', message: `缺失 ${missing.length} 个扩展` });
  } else {
    document.getElementById('missingDiv')?.remove();
  }
  setStatus(msg);
}

// 事件绑定
backupBtn.addEventListener('click', backup);
restoreBtn.addEventListener('click', restore);
settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
manageBtn.addEventListener('click', () => chrome.tabs.create({ url: 'manage.html' }));
searchInput.addEventListener('input', applyFilterAndRender);

loadExtensions();