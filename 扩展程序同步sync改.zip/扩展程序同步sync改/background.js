// 后台服务：定时自动备份、存储监听
const STORAGE_KEYS = {
  webdavUrl: 'webdavUrl',
  webdavUser: 'webdavUser',
  webdavPass: 'webdavPass',
  deviceSuffix: 'deviceSuffix',
  autoBackupEnabled: 'autoBackupEnabled',
  autoBackupInterval: 'autoBackupInterval',
  lastBackupTime: 'lastBackupTime',
  lastSyncStatus: 'lastSyncStatus'
};

const DEFAULTS = {
  autoBackupEnabled: false,
  autoBackupInterval: 24,
  lastBackupTime: 0
};

async function getStorageValue(key, defaultValue) {
  const result = await chrome.storage.sync.get(key);
  return result[key] !== undefined ? result[key] : defaultValue;
}

async function setStorageValue(key, value) {
  await chrome.storage.sync.set({ [key]: value });
}

async function getDeviceSuffix() {
  let suffix = await getStorageValue(STORAGE_KEYS.deviceSuffix, 'default');
  suffix = suffix.replace(/[^a-zA-Z0-9_-]/g, '');
  return suffix || 'default';
}

async function getWebDavConfig() {
  const url = await getStorageValue(STORAGE_KEYS.webdavUrl, '');
  if (!url) throw new Error('未配置 WebDAV 地址');
  const user = await getStorageValue(STORAGE_KEYS.webdavUser, '');
  const pass = await getStorageValue(STORAGE_KEYS.webdavPass, '');
  return { url, user, pass };
}

async function getFullBackupUrl() {
  const config = await getWebDavConfig();
  const suffix = await getDeviceSuffix();
  const fileName = `extensions-backup_${suffix}.json`;
  let base = config.url.trim();
  if (!base.endsWith('/')) base += '/';
  return { url: base + fileName, config };
}

async function takeSnapshot() {
  const exts = await chrome.management.getAll();
  return exts.filter(ext => ext.type === 'extension').map(ext => ({
    id: ext.id,
    name: ext.name,
    enabled: ext.enabled,
    version: ext.version,
    installType: ext.installType
  }));
}

async function uploadSnapshot(snapshot) {
  const { url, config } = await getFullBackupUrl();
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': 'Basic ' + btoa(`${config.user}:${config.pass}`),
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(snapshot, null, 2)
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return true;
}

async function performAutoBackup() {
  console.log('[Background] 执行自动备份...');
  const enabled = await getStorageValue(STORAGE_KEYS.autoBackupEnabled, false);
  if (!enabled) return;

  try {
    const snapshot = await takeSnapshot();
    await uploadSnapshot(snapshot);
    const now = Date.now();
    await setStorageValue(STORAGE_KEYS.lastBackupTime, now);
    await setStorageValue(STORAGE_KEYS.lastSyncStatus, { success: true, time: now, count: snapshot.length });
    console.log(`[Background] 自动备份成功，共 ${snapshot.length} 个扩展`);
    
    const sendNotification = await getStorageValue('notifyOnBackup', false);
    if (sendNotification) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon.png',
        title: '扩展同步备份',
        message: `自动备份成功，已同步 ${snapshot.length} 个扩展`
      });
    }
  } catch (err) {
    console.error('[Background] 自动备份失败:', err);
    await setStorageValue(STORAGE_KEYS.lastSyncStatus, { success: false, time: Date.now(), error: err.message });
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: '扩展同步备份失败',
      message: `自动备份失败: ${err.message}`
    });
  }
}

async function setupAutoBackupAlarm() {
  const enabled = await getStorageValue(STORAGE_KEYS.autoBackupEnabled, false);
  if (!enabled) {
    await chrome.alarms.clear('autoBackup');
    return;
  }
  const intervalHours = await getStorageValue(STORAGE_KEYS.autoBackupInterval, 24);
  const intervalMinutes = intervalHours * 60;
  await chrome.alarms.create('autoBackup', {
    periodInMinutes: intervalMinutes,
    delayInMinutes: 1
  });
  console.log(`[Background] 已设置自动备份闹钟，间隔 ${intervalHours} 小时`);
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'autoBackup') performAutoBackup();
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync') {
    if (changes[STORAGE_KEYS.autoBackupEnabled] || changes[STORAGE_KEYS.autoBackupInterval]) {
      setupAutoBackupAlarm();
    }
  }
});

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Background] 扩展安装/更新:', details.reason);
  const enabled = await getStorageValue(STORAGE_KEYS.autoBackupEnabled, null);
  if (enabled === null) {
    await setStorageValue(STORAGE_KEYS.autoBackupEnabled, DEFAULTS.autoBackupEnabled);
    await setStorageValue(STORAGE_KEYS.autoBackupInterval, DEFAULTS.autoBackupInterval);
  }
  await setupAutoBackupAlarm();
  if (await getStorageValue(STORAGE_KEYS.autoBackupEnabled, false)) {
    performAutoBackup();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'manualBackup') {
    performAutoBackup().then(() => sendResponse({ success: true })).catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (message.action === 'getBackupStatus') {
    getStorageValue(STORAGE_KEYS.lastSyncStatus, null).then(status => sendResponse({ status }));
    return true;
  }
});

console.log('[Background] 后台服务已启动');