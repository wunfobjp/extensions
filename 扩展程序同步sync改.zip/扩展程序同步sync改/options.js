async function loadConfig() {
  const result = await chrome.storage.sync.get([
    'webdavUrl', 'webdavUser', 'webdavPass', 'deviceSuffix',
    'autoBackupEnabled', 'autoBackupInterval', 'notifyOnBackup'
  ]);
  document.getElementById('webdavUrl').value = result.webdavUrl || '';
  document.getElementById('webdavUser').value = result.webdavUser || '';
  document.getElementById('webdavPass').value = result.webdavPass || '';
  document.getElementById('deviceSuffix').value = result.deviceSuffix || 'default';
  document.getElementById('autoBackupEnabled').checked = result.autoBackupEnabled === true;
  document.getElementById('autoBackupInterval').value = result.autoBackupInterval || 24;
  document.getElementById('notifyOnBackup').checked = result.notifyOnBackup === true;
}

async function saveConfig() {
  const webdavUrl = document.getElementById('webdavUrl').value.trim();
  const webdavUser = document.getElementById('webdavUser').value.trim();
  const webdavPass = document.getElementById('webdavPass').value;
  let deviceSuffix = document.getElementById('deviceSuffix').value.trim();
  const autoBackupEnabled = document.getElementById('autoBackupEnabled').checked;
  let autoBackupInterval = parseInt(document.getElementById('autoBackupInterval').value, 10);
  const notifyOnBackup = document.getElementById('notifyOnBackup').checked;

  if (!webdavUrl) {
    showMsg('请填写 WebDAV 地址', true);
    return;
  }
  if (!deviceSuffix) deviceSuffix = 'default';
  deviceSuffix = deviceSuffix.replace(/[^a-zA-Z0-9_-]/g, '');
  if (deviceSuffix === '') deviceSuffix = 'default';
  if (isNaN(autoBackupInterval) || autoBackupInterval < 1) autoBackupInterval = 24;
  if (autoBackupInterval > 168) autoBackupInterval = 168;

  await chrome.storage.sync.set({
    webdavUrl, webdavUser, webdavPass, deviceSuffix,
    autoBackupEnabled, autoBackupInterval, notifyOnBackup
  });
  showMsg('✅ 设置已保存', false);
}

async function testWebDAV() {
  const testDiv = document.getElementById('testResult');
  testDiv.innerText = '⏳ 测试中...';
  testDiv.style.color = '#333';
  testDiv.style.background = '#f1f3f4';

  const webdavUrl = document.getElementById('webdavUrl').value.trim();
  const webdavUser = document.getElementById('webdavUser').value.trim();
  const webdavPass = document.getElementById('webdavPass').value;

  if (!webdavUrl) {
    testDiv.innerText = '❌ 请先填写 WebDAV 地址';
    testDiv.style.color = 'red';
    testDiv.style.background = '#fce8e6';
    return;
  }

  let base = webdavUrl;
  if (!base.endsWith('/')) base += '/';
  const testFileName = `test_${Date.now()}.txt`;
  const testUrl = base + testFileName;
  const testContent = 'WebDAV connection test from extension';

  try {
    const putRes = await fetch(testUrl, {
      method: 'PUT',
      headers: {
        'Authorization': 'Basic ' + btoa(`${webdavUser}:${webdavPass}`),
        'Content-Type': 'text/plain'
      },
      body: testContent
    });
    if (!putRes.ok) throw new Error(`PUT 失败 (${putRes.status})`);

    const getRes = await fetch(testUrl, {
      method: 'GET',
      headers: { 'Authorization': 'Basic ' + btoa(`${webdavUser}:${webdavPass}`) }
    });
    if (!getRes.ok) throw new Error(`GET 失败 (${getRes.status})`);
    const text = await getRes.text();
    if (text !== testContent) throw new Error('内容不匹配');

    const delRes = await fetch(testUrl, {
      method: 'DELETE',
      headers: { 'Authorization': 'Basic ' + btoa(`${webdavUser}:${webdavPass}`) }
    });
    if (!delRes.ok) console.warn('删除测试文件失败，但连接可用');

    testDiv.innerText = '✅ WebDAV 连接成功！服务器可读写。';
    testDiv.style.color = 'green';
    testDiv.style.background = '#e6f4ea';
  } catch (err) {
    testDiv.innerText = `❌ 连接失败: ${err.message}`;
    testDiv.style.color = 'red';
    testDiv.style.background = '#fce8e6';
  }
}

function showMsg(msg, isErr) {
  const testDiv = document.getElementById('testResult');
  testDiv.innerText = msg;
  testDiv.style.color = isErr ? 'red' : 'green';
  testDiv.style.background = isErr ? '#fce8e6' : '#e6f4ea';
  setTimeout(() => {
    if (testDiv.innerText === msg) testDiv.innerText = '';
  }, 3000);
}

document.addEventListener('DOMContentLoaded', () => {
  loadConfig();
  document.getElementById('saveBtn').addEventListener('click', saveConfig);
  document.getElementById('testBtn').addEventListener('click', testWebDAV);
});