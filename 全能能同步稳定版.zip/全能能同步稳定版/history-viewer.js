// history-viewer.js - 历史记录备份查看器（带本地缓存）
const { STORAGE_KEYS, getStorage } = self.Common;
const WebDAVClient = self.WebDAVClient;

const CACHE_KEY = 'history_viewer_cache';
const CACHE_TIME_KEY = 'history_viewer_cache_time';
const CACHE_DURATION = 30 * 60 * 1000; // 缓存有效期：30分钟

let allRecords = [];
let filteredRecords = [];
let currentPage = 0;
const PAGE_SIZE = 100;
let sortField = 'lastVisitTime';
let sortDir = 'desc';

// DOM
const searchInput = document.getElementById('searchInput');
const reloadBtn = document.getElementById('reloadBtn');
const exportCSVBtn = document.getElementById('exportCSVBtn');
const infoStatus = document.getElementById('infoStatus');
const tableContainer = document.getElementById('tableContainer');

let searchTimer;

// ---------- 工具函数 ----------
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[m]);
}

// ---------- 缓存相关 ----------
async function getCachedData() {
  const cached = await chrome.storage.local.get([CACHE_KEY, CACHE_TIME_KEY]);
  if (cached[CACHE_KEY] && cached[CACHE_TIME_KEY]) {
    const age = Date.now() - cached[CACHE_TIME_KEY];
    if (age < CACHE_DURATION) {
      return cached[CACHE_KEY];
    }
  }
  return null;
}

async function setCache(data) {
  await chrome.storage.local.set({
    [CACHE_KEY]: data,
    [CACHE_TIME_KEY]: Date.now()
  });
}

// ---------- 加载备份（优先缓存）----------
async function loadBackup(forceRefresh = false) {
  tableContainer.innerHTML = '<div class="loading">正在加载数据...</div>';

  try {
    // 尝试读取缓存（非强制刷新时）
    if (!forceRefresh) {
      const cached = await getCachedData();
      if (cached) {
        allRecords = cached;
        updateInfo();
        applyFilters();
        return;
      }
    }

    // 从 WebDAV 拉取
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) throw new Error('请先在选项页配置 WebDAV');

    const client = new WebDAVClient(url, user, pass);
    const fileName = STORAGE_KEYS.HISTORY_BACKUP_FILE || 'history_backup.json';
    const content = await client.getFile(fileName);
    if (!content) throw new Error('云端无备份文件');

    let raw = JSON.parse(content);

    // 兼容压缩格式 [url, title, lastVisitTime, visitCount]
    if (Array.isArray(raw) && raw.length && Array.isArray(raw[0])) {
      allRecords = raw.map(r => ({
        url: r[0],
        title: r[1] || '',
        lastVisitTime: r[2],
        visitCount: r[3] || 1
      }));
    } else if (Array.isArray(raw)) {
      allRecords = raw.map(r => ({
        ...r,
        title: r.title || ''
      }));
    } else {
      throw new Error('数据格式不正确');
    }

    // 写入缓存
    await setCache(allRecords);
    updateInfo();
    applyFilters();
  } catch (err) {
    tableContainer.innerHTML = `<div class="loading" style="color:red;">加载失败：${err.message}</div>`;
    infoStatus.textContent = '';
  }
}

function updateInfo() {
  const total = allRecords.length;
  infoStatus.textContent = `共 ${total} 条记录` + (total > 0 ? ' (缓存有效期内刷新免下载)' : '');
}

// ---------- 过滤与排序 ----------
function applyFilters() {
  const query = searchInput.value.trim().toLowerCase();
  if (query) {
    filteredRecords = allRecords.filter(r =>
      (r.title || '').toLowerCase().includes(query) ||
      (r.url || '').toLowerCase().includes(query)
    );
  } else {
    filteredRecords = [...allRecords];
  }

  filteredRecords.sort((a, b) => {
    let valA = a[sortField] || '';
    let valB = b[sortField] || '';
    if (sortField === 'lastVisitTime' || sortField === 'visitCount') {
      valA = Number(valA);
      valB = Number(valB);
    }
    if (valA < valB) return sortDir === 'asc' ? -1 : 1;
    if (valA > valB) return sortDir === 'asc' ? 1 : -1;
    return 0;
  });

  currentPage = 0;
  renderPage();
}

function renderPage() {
  const start = currentPage * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  const pageData = filteredRecords.slice(start, end);

  if (pageData.length === 0) {
    tableContainer.innerHTML = '<div class="loading">无匹配记录</div>';
    return;
  }

  let html = '<table><thead><tr>';
  const headers = [
    { label: '访问时间', field: 'lastVisitTime' },
    { label: '标题 / URL', field: 'title' },
    { label: '访问次数', field: 'visitCount' }
  ];
  headers.forEach(h => {
    html += `<th data-sort="${h.field}">${h.label} ${sortField === h.field ? (sortDir === 'asc' ? '▲' : '▼') : ''}</th>`;
  });
  html += '</tr></thead><tbody>';

  pageData.forEach(r => {
    const timeStr = r.lastVisitTime ? new Date(r.lastVisitTime).toLocaleString() : '';
    const displayTitle = r.title || '';
const titleHtml = displayTitle
  ? `<a href="${r.url}" target="_blank" title="${escapeHtml(r.url)}">${escapeHtml(displayTitle)}</a>`
  : `<a href="${r.url}" target="_blank" style="color:#999; font-style:italic;" title="${escapeHtml(r.url)}">${escapeHtml(r.url)}</a>`;
    html += `<tr>
      <td>${timeStr}</td>
      <td class="url-col">${titleHtml}</td>
      <td>${r.visitCount}</td>
    </tr>`;
  });
  html += '</tbody></table>';

  const totalPages = Math.ceil(filteredRecords.length / PAGE_SIZE);
  html += '<div class="pagination">';
  html += `<button id="prevPage" ${currentPage === 0 ? 'disabled' : ''}>上一页</button>`;
  html += `<span>${currentPage + 1} / ${totalPages || 1}</span>`;
  html += `<button id="nextPage" ${currentPage >= totalPages - 1 ? 'disabled' : ''}>下一页</button>`;
  html += '</div>';

  tableContainer.innerHTML = html;
}

// ---------- 事件委托 ----------
tableContainer.addEventListener('click', (e) => {
  const th = e.target.closest('th[data-sort]');
  if (th) {
    const field = th.dataset.sort;
    if (sortField === field) {
      sortDir = sortDir === 'asc' ? 'desc' : 'asc';
    } else {
      sortField = field;
      sortDir = 'desc';
    }
    applyFilters();
    return;
  }
  if (e.target.id === 'prevPage') {
    if (currentPage > 0) {
      currentPage--;
      renderPage();
    }
  }
  if (e.target.id === 'nextPage') {
    const totalPages = Math.ceil(filteredRecords.length / PAGE_SIZE);
    if (currentPage < totalPages - 1) {
      currentPage++;
      renderPage();
    }
  }
});

// ---------- 导出 CSV ----------
function exportCSV() {
  if (filteredRecords.length === 0) {
    alert('没有数据可导出');
    return;
  }
  const csvContent = [
    '"访问时间","标题","URL","访问次数"',
    ...filteredRecords.map(r =>
      `"${new Date(r.lastVisitTime).toLocaleString()}","${(r.title || '').replace(/"/g, '""')}","${r.url || ''}","${r.visitCount}"`
    )
  ].join('\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'history_backup_export.csv';
  a.click();
  URL.revokeObjectURL(url);
}

// ---------- 事件绑定 ----------
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(applyFilters, 300);
});

// 刷新按钮强制重新拉取，忽略缓存
reloadBtn.addEventListener('click', () => loadBackup(true));
exportCSVBtn.addEventListener('click', exportCSV);

// 启动（优先使用缓存）
loadBackup(false);