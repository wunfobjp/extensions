// bookmarks-sync.js - 书签上传/下载/清空功能（支持 WebDAV 和 GitHub Gist）
self.BookmarksSync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, getSyncStorage, setSyncStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;
  const GistClient = self.GistClient;

  // ---------- 默认书签设置 ----------
  const DEFAULT_BOOKMARKS_SETTINGS = {
    remotePath: '/bookmarks.json',
    swapBookmarkMobile: false,
    lastSync: 0
  };

  // ---------- 获取书签设置 ----------
  async function getBookmarksSettings() {
    const settings = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS);
    return settings || DEFAULT_BOOKMARKS_SETTINGS;
  }

  // ---------- 获取书签同步后端类型 ----------
  async function getSyncBackend() {
    const backend = await getStorage(STORAGE_KEYS.BOOKMARKS_SYNC_BACKEND);
    return backend || 'webdav'; // 默认 webdav
  }

  // ---------- 获取书签同步客户端（根据后端类型）----------
  async function getBookmarksClient() {
    const backend = await getSyncBackend();
    if (backend === 'gist') {
      const token = await getStorage(STORAGE_KEYS.GIST_TOKEN);
      if (!token) {
        throw new Error('请先在选项页配置 GitHub Token');
      }
      return { type: 'gist', client: new GistClient(token) };
    } else {
      const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
      const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
      const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
      if (!url || !user || !pass) {
        throw new Error('请先在选项页配置 WebDAV 参数');
      }
      return { type: 'webdav', client: new WebDAVClient(url, user, pass) };
    }
  }

  // ---------- 获取远程书签数据 ----------
  async function fetchRemoteBookmarks() {
    const { type, client } = await getBookmarksClient();
    const settings = await getBookmarksSettings();

    let content;
    if (type === 'gist') {
      const gistId = await getStorage(STORAGE_KEYS.GIST_ID);
      const fileName = await getStorage(STORAGE_KEYS.GIST_FILENAME) || 'bookmarks.json';
      if (!gistId) throw new Error('请配置 Gist ID');
      content = await client.getFileContent(gistId, fileName);
    } else {
      content = await client.getFile(settings.remotePath);
    }

    if (!content) return null;
    return JSON.parse(content);
  }

  // ---------- 上传远程书签数据 ----------
  async function uploadRemoteBookmarks(data) {
    const { type, client } = await getBookmarksClient();
    const settings = await getBookmarksSettings();
    const jsonStr = JSON.stringify(data);

    if (type === 'gist') {
      const gistId = await getStorage(STORAGE_KEYS.GIST_ID);
      const fileName = await getStorage(STORAGE_KEYS.GIST_FILENAME) || 'bookmarks.json';
      if (!gistId) throw new Error('请配置 Gist ID');
      await client.updateFile(gistId, fileName, jsonStr);
    } else {
      await client.putFile(settings.remotePath, jsonStr);
    }
  }

  // ---------- 获取标准文件夹 ID（书签栏、其他书签、移动书签）----------
  async function getStandardFolderIds() {
    const children = await chrome.bookmarks.getChildren('0');
    const folders = { bookmarkBar: null, other: null, mobile: null };

    // 1. 尝试标准固定 ID
    const tryGetById = async (id) => {
      try {
        await chrome.bookmarks.get(id);
        return id;
      } catch { return null; }
    };
    folders.bookmarkBar = await tryGetById('1');
    folders.other = await tryGetById('2');
    folders.mobile = await tryGetById('3');

    // 2. 通过标题关键词识别
    for (const node of children) {
      const title = (node.title || '').toLowerCase();
      if (!folders.bookmarkBar) {
        if (title.includes('bookmark bar') || title.includes('书签栏') || title.includes('桌面书签')) {
          folders.bookmarkBar = node.id;
          continue;
        }
      }
      if (!folders.other) {
        if (title.includes('other bookmarks') || title.includes('其他书签')) {
          folders.other = node.id;
          continue;
        }
      }
      if (!folders.mobile) {
        if (title.includes('mobile bookmarks') || title.includes('移动设备书签') || title.includes('移动书签')) {
          folders.mobile = node.id;
          continue;
        }
      }
    }

    // 3. 兜底
    if (!folders.bookmarkBar && !folders.other && !folders.mobile && children.length === 1) {
      folders.other = children[0].id;
    }

    // 4. 交换选项
    const settings = await getBookmarksSettings();
    if (settings.swapBookmarkMobile) {
      [folders.bookmarkBar, folders.mobile] = [folders.mobile, folders.bookmarkBar];
    }

    return folders;
  }

  // ---------- 工具函数 ----------
  function generateGUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  }

  function computeNodeHash(node) {
    let str = (node.title || '') + (node.url || '');
    if (node.children) {
      for (const child of node.children) str += computeNodeHash(child);
    }
    return simpleHash(str);
  }

  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  }

  async function getMeta() {
    const meta = await getStorage(STORAGE_KEYS.BOOKMARKS_META);
    return meta || { guidMap: {}, lastModified: {}, hash: {}, deleted: [] };
  }

  async function saveMeta(meta) {
    await setStorage(STORAGE_KEYS.BOOKMARKS_META, meta);
  }

  async function getOrCreateGUID(localId, meta) {
    if (!meta.guidMap[localId]) meta.guidMap[localId] = generateGUID();
    return meta.guidMap[localId];
  }

  // ---------- 导出书签树（用于上传）----------
  async function exportBookmarks() {
    const settings = await getBookmarksSettings();
    const folders = await getStandardFolderIds();
    const meta = await getMeta();
    const exportTree = [];
    const order = ['bookmarkBar', 'other', 'mobile'];

    for (const key of order) {
      const id = folders[key];
      if (!id) continue;
      try {
        const nodes = await chrome.bookmarks.getSubTree(id);
        if (nodes && nodes[0]) {
          const root = nodes[0];
          const processed = await processNodeForExport(root, meta);
          processed.id = key;
          exportTree.push(processed);
        }
      } catch (e) {
        console.error(`导出文件夹 ${key} 失败:`, e);
      }
    }

    await saveMeta(meta);
    return {
      version: 4,
      timestamp: Date.now(),
      tree: exportTree,
      deleted: meta.deleted || []
    };
  }

  async function processNodeForExport(node, meta) {
    const guid = await getOrCreateGUID(node.id, meta);
    const currentHash = computeNodeHash(node);
    const oldHash = meta.hash[guid];
    let lastModified = meta.lastModified[guid];

    if (oldHash !== currentHash || !lastModified) {
      lastModified = Date.now();
      meta.lastModified[guid] = lastModified;
      meta.hash[guid] = currentHash;
    }

    const exportNode = {
      guid,
      title: node.title,
      url: node.url || undefined,
      dateAdded: node.dateAdded,
      lastModified
    };
    if (node.children) {
      exportNode.children = [];
      for (const child of node.children) {
        exportNode.children.push(await processNodeForExport(child, meta));
      }
    }
    return exportNode;
  }

  // ---------- 清空文件夹 ----------
  async function clearFolder(folderId) {
    try {
      const children = await chrome.bookmarks.getChildren(folderId);
      for (const child of children) {
        await chrome.bookmarks.removeTree(child.id);
      }
    } catch (e) {}
  }

  // ---------- 递归创建书签 ----------
  async function createBookmarksRecursive(node, parentId, isRoot = false, meta = null) {
    if (!node || typeof node !== 'object') return;
    if (isRoot) {
      for (const child of (node.children || [])) {
        await createBookmarksRecursive(child, parentId, false, meta);
      }
      return;
    }

    const title = node.title || '未命名';
    const url = node.url;
    let newId;
    if (url) {
      const created = await chrome.bookmarks.create({ parentId, title, url });
      newId = created.id;
    } else {
      const created = await chrome.bookmarks.create({ parentId, title });
      newId = created.id;
      for (const child of (node.children || [])) {
        await createBookmarksRecursive(child, newId, false, meta);
      }
    }

    if (meta && node.guid) {
      meta.guidMap[newId] = node.guid;
      meta.lastModified[node.guid] = node.lastModified || Date.now();
      try {
        const createdNode = (await chrome.bookmarks.get(newId))[0];
        meta.hash[node.guid] = computeNodeHash(createdNode);
      } catch (e) {}
    }
  }

  // ---------- 导入书签（完全替换）----------
  async function importBookmarks(remoteData) {
    if (!remoteData || !Array.isArray(remoteData.tree)) {
      throw new Error('远程数据格式错误');
    }

    const localFolders = await getStandardFolderIds();
    const meta = await getMeta();

    const remoteRoots = remoteData.tree
      .map(node => {
        if (!node || !node.id) return null;
        const targetId = localFolders[node.id];
        if (!targetId) return null;
        return { ...node, id: targetId };
      })
      .filter(n => n !== null);

    for (const root of remoteRoots) {
      await clearFolder(root.id);
    }
    for (const root of remoteRoots) {
      await createBookmarksRecursive(root, root.id, true, meta);
    }
    meta.deleted = [];
    await saveMeta(meta);
  }

  // ---------- 统计本地书签数量 ----------
  async function countBookmarksInTree(node, isRoot = false) {
    if (!node) return 0;
    let count = (!isRoot && node.url) ? 1 : 0;
    if (node.children) {
      for (const child of node.children) {
        count += await countBookmarksInTree(child, false);
      }
    }
    return count;
  }

  async function getLocalBookmarkCount() {
    const folders = await getStandardFolderIds();
    let total = 0;
    for (const key of ['bookmarkBar', 'other', 'mobile']) {
      const id = folders[key];
      if (id) {
        try {
          const nodes = await chrome.bookmarks.getSubTree(id);
          if (nodes && nodes[0]) {
            total += await countBookmarksInTree(nodes[0], true);
          }
        } catch (e) {}
      }
    }
    if (total === 0 && !folders.bookmarkBar && !folders.other && !folders.mobile) {
      try {
        const rootNodes = await chrome.bookmarks.getTree();
        if (rootNodes && rootNodes[0]) {
          total = await countBookmarksInTree(rootNodes[0], true);
        }
      } catch (e) {}
    }
    return total;
  }

  async function getRemoteBookmarkCount() {
    try {
      const remoteData = await fetchRemoteBookmarks();
      if (!remoteData) return null;
      let count = 0;
      const countInNode = (node) => {
        if (!node) return;
        if (node.url) count++;
        for (const child of (node.children || [])) countInNode(child);
      };
      (remoteData.tree || []).forEach(countInNode);
      return count;
    } catch {
      return null;
    }
  }

  // ---------- 公开方法 ----------
  async function uploadBookmarks() {
    try {
      const data = await exportBookmarks();
      await uploadRemoteBookmarks(data);
      const settings = await getBookmarksSettings();
      await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, { ...settings, lastSync: Date.now() });
      showNotification('书签上传', '书签已上传');
      return { success: true, message: '上传成功' };
    } catch (err) {
      showNotification('书签上传失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function downloadBookmarks() {
    try {
      const remoteData = await fetchRemoteBookmarks();
      if (!remoteData) throw new Error('远程文件不存在');
      await importBookmarks(remoteData);
      const settings = await getBookmarksSettings();
      await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, { ...settings, lastSync: Date.now() });
      showNotification('书签下载', '已下载并替换本地书签');
      return { success: true, message: '下载成功' };
    } catch (err) {
      showNotification('书签下载失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function clearAllBookmarks() {
    try {
      const folders = await getStandardFolderIds();
      for (const key of ['bookmarkBar', 'other', 'mobile']) {
        const id = folders[key];
        if (id) await clearFolder(id);
      }
      await setStorage(STORAGE_KEYS.BOOKMARKS_META, null);
      const settings = await getBookmarksSettings();
      await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, { ...settings, lastSync: 0 });
      showNotification('书签清空', '本地书签已清空');
      return { success: true, message: '清空成功' };
    } catch (err) {
      showNotification('清空失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function getStats() {
    const local = await getLocalBookmarkCount();
    const remote = await getRemoteBookmarkCount();
    return { local, remote };
  }

  return {
    uploadBookmarks,
    downloadBookmarks,
    clearAllBookmarks,
    getStats
  };
})();