// manage.js - 高级管理工具
const { STORAGE_KEYS, getStorage } = self.Common;

// 辅助函数
function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

// ========== 1. 检测支持云同步的扩展 ==========
async function detectSyncExtensions() {
  const statusDiv = document.getElementById('syncStatus');
  const listDiv = document.getElementById('syncExtList');
  statusDiv.innerText = '检测中...';
  listDiv.innerHTML = '';

  try {
    const exts = await chrome.management.getAll();
    const extensions = exts.filter(ext => ext.type === 'extension');
    let html = '';
    for (const ext of extensions) {
      const storeUrl = `https://chrome.google.com/webstore/detail/${ext.id}`;
      html += `
        <div class="ext-item">
          <span><strong>${escapeHtml(ext.name)}</strong> v${ext.version}</span>
          <a href="${storeUrl}" target="_blank" style="font-size:11px;">查看商店页面</a>
        </div>
      `;
    }
    listDiv.innerHTML = html || '<div>未找到扩展</div>';
    statusDiv.innerText = `共 ${extensions.length} 个扩展。点击链接查看是否支持云同步（商店页面通常会说明）。`;
  } catch (err) {
    statusDiv.innerText = '检测失败：' + err.message;
    statusDiv.style.color = 'red';
  }
}

// ========== 2. 集中管理导入/导出文件 ==========
async function getWebDavConfig() {
  const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
  const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
  const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
  if (!url) throw new Error('未配置 WebDAV 地址，请先在扩展设置中配置');
  return { url, user: user || '', pass: pass || '' };
}

async function getConfigFileUrl(fileName) {
  const config = await getWebDavConfig();
  let base = config.url.trim();
  if (!base.endsWith('/')) base += '/';
  return { url: base + fileName, config };
}

async function uploadConfigFile(file) {
  const statusDiv = document.getElementById('configStatus');
  statusDiv.innerText = '上传中...';
  try {
    const { url, config } = await getConfigFileUrl(file.name);
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Authorization': 'Basic ' + btoa(`${config.user}:${config.pass}`),
        'Content-Type': file.type || 'application/octet-stream'
      },
      body: file
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    statusDiv.innerText = `✅ 已上传 ${file.name} 到 WebDAV`;
    statusDiv.style.color = 'green';
  } catch (err) {
    statusDiv.innerText = `上传失败: ${err.message}`;
    statusDiv.style.color = 'red';
  }
}

async function downloadConfigFile() {
  const fileName = prompt('请输入要下载的配置文件名（例如：my-extension-settings.json）:', 'config.json');
  if (!fileName) return;
  const statusDiv = document.getElementById('configStatus');
  statusDiv.innerText = '下载中...';
  try {
    const { url, config } = await getConfigFileUrl(fileName);
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Authorization': 'Basic ' + btoa(`${config.user}:${config.pass}`) }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const blob = await response.blob();
    const downloadUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(downloadUrl);
    statusDiv.innerText = `✅ 已下载 ${fileName}`;
    statusDiv.style.color = 'green';
  } catch (err) {
    statusDiv.innerText = `下载失败: ${err.message}`;
    statusDiv.style.color = 'red';
  }
}

// ========== 3. 备份/恢复整个 Chrome 配置文件 ==========
async function showProfilePath() {
  const profilePathDiv = document.getElementById('profilePath');
  profilePathDiv.innerHTML = `
    <strong>如何找到配置文件目录：</strong><br>
    1. 在地址栏输入 <code>chrome://version/</code> 并回车。<br>
    2. 找到 <strong>个人资料路径</strong>（Profile Path）一行，复制路径。<br>
    3. 关闭 Chrome 浏览器后，备份该文件夹即可。<br>
    示例路径（Windows）: <code>C:\\Users\\用户名\\AppData\\Local\\Google\\Chrome\\User Data\\Default</code><br>
    示例路径（macOS）: <code>/Users/用户名/Library/Application Support/Google/Chrome/Default</code><br>
    示例路径（Linux）: <code>/home/用户名/.config/google-chrome/Default</code>
  `;
}

async function openProfileDirectory() {
  alert('请手动打开文件管理器，并导航到 chrome://version/ 中显示的“个人资料路径”。');
}

// ========== 4. 本地缺失扩展列表 ==========
async function loadMissingExtensions() {
  const statusDiv = document.getElementById('missingExtensionsStatus');
  const listDiv = document.getElementById('missingExtensionsList');
  statusDiv.innerText = '检测中...';
  listDiv.innerHTML = '';

  try {
    const response = await chrome.runtime.sendMessage({ action: 'getMissingExtensions' });
    if (!response.success) {
      statusDiv.innerText = `检测失败：${response.error || '未知错误'}`;
      statusDiv.style.color = 'red';
      listDiv.innerHTML = '<div>无法获取缺失扩展列表，请确保已配置 WebDAV 并进行过扩展备份。</div>';
      return;
    }

    const missing = response.missing || [];
    if (missing.length === 0) {
      listDiv.innerHTML = '<div>🎉 所有备份扩展均已安装！</div>';
      statusDiv.innerText = `共检测到 0 个缺失扩展。`;
      statusDiv.style.color = 'green';
      return;
    }

    let html = `<div style="margin-bottom:8px;">⚠️ 共缺失 ${missing.length} 个扩展：</div>`;
    missing.forEach(ext => {
      const escapedName = escapeHtml(ext.name);
      const storeUrl = `https://chrome.google.com/webstore/detail/${ext.id}`;
      html += `
        <div class="ext-item">
          <span><strong>${escapedName}</strong> (${ext.id})</span>
          <a href="${storeUrl}" target="_blank" style="font-size:11px;">前往商店安装</a>
        </div>
      `;
    });
    listDiv.innerHTML = html;
    statusDiv.innerText = `检测完成，缺失 ${missing.length} 个扩展。点击链接可跳转 Chrome 网上商店安装。`;
    statusDiv.style.color = '#b45f06';
  } catch (err) {
    statusDiv.innerText = `检测异常：${err.message}`;
    statusDiv.style.color = 'red';
    listDiv.innerHTML = '<div>发生错误，请检查控制台。</div>';
  }
}

// 绑定事件
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('detectSyncBtn').addEventListener('click', detectSyncExtensions);
  document.getElementById('uploadConfigBtn').addEventListener('click', () => {
    const fileInput = document.getElementById('configFileInput');
    fileInput.onchange = (e) => {
      if (e.target.files.length) uploadConfigFile(e.target.files[0]);
      fileInput.value = '';
    };
    fileInput.click();
  });
  document.getElementById('downloadConfigBtn').addEventListener('click', downloadConfigFile);
  document.getElementById('showProfilePathBtn').addEventListener('click', showProfilePath);
  document.getElementById('openProfileDirBtn').addEventListener('click', openProfileDirectory);
  document.getElementById('checkMissingExtensionsBtn').addEventListener('click', loadMissingExtensions);
  // 页面加载时自动检测一次
  loadMissingExtensions();
});