// gist-client.js - GitHub Gist API 客户端
self.GistClient = class GistClient {
  constructor(token) {
    this.token = token;
  }

  async _request(method, url, body = null) {
    const options = {
      method,
      headers: {
        'Authorization': `token ${this.token}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    const response = await fetch(url, options);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gist API 错误 (${response.status}): ${errorText}`);
    }
    return response.json();
  }

  /**
   * 获取指定 Gist 的详情
   */
  async getGist(gistId) {
    return this._request('GET', `https://api.github.com/gists/${gistId}`);
  }

  /**
   * 读取 Gist 中指定文件的内容
   */
  async getFileContent(gistId, fileName) {
    const gist = await this.getGist(gistId);
    if (!gist.files || !gist.files[fileName]) {
      return null; // 文件不存在
    }
    const file = gist.files[fileName];
    return file.content || '';
  }

  /**
   * 更新 Gist 中的文件内容
   */
  async updateFile(gistId, fileName, content) {
    const body = {
      files: {
        [fileName]: { content }
      }
    };
    return this._request('PATCH', `https://api.github.com/gists/${gistId}`, body);
  }

  /**
   * 测试连接：尝试获取 Gist 信息
   */
  async testConnection(gistId) {
    try {
      await this.getGist(gistId);
      return true;
    } catch (e) {
      console.error('Gist 连接测试失败', e);
      return false;
    }
  }
};