// extensions-sync.js - 扩展状态同步（备份/恢复启用/禁用状态）
self.ExtensionsSync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, getSyncStorage, setSyncStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  // 默认扩展同步设置
  const DEFAULT_EXTENSIONS_SETTINGS = {
    deviceSuffix: 'default',
    autoBackupEnabled: false,
    autoBackupInterval: 24,
    notifyOnBackup: false,
    lastBackupTime: 0,
    lastSyncStatus: null
  };

  async function getExtensionsSettings() {
    const settings = await getSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS);
    return settings || DEFAULT_EXTENSIONS_SETTINGS;
  }

  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) {
      throw new Error('请先配置 WebDAV 参数');
    }
    return new WebDAVClient(url, user, pass);
  }

  // 生成备份文件名（带设备标识）
  async function getBackupFileName() {
    const settings = await getExtensionsSettings();
    let suffix = (settings.deviceSuffix || 'default').replace(/[^a-zA-Z0-9_-]/g, '');
    return `extensions-backup_${suffix || 'default'}.json`;
  }

  // 获取当前扩展快照
  async function takeSnapshot() {
    const exts = await chrome.management.getAll();
    return exts.filter(ext => ext.type === 'extension').map(ext => ({
      id: ext.id,
      name: ext.name,
      enabled: ext.enabled,
      version: ext.version,
      installType: ext.installType
    }));
  }

  // 上传快照到 WebDAV
  async function uploadSnapshot(snapshot) {
    const client = await getWebDAVClient();
    const fileName = await getBackupFileName();
    const jsonStr = JSON.stringify(snapshot, null, 2);
    await client.putFile(fileName, jsonStr);
  }

  // 从 WebDAV 下载快照
  async function downloadSnapshot() {
    const client = await getWebDAVClient();
    const fileName = await getBackupFileName();
    const content = await client.getFile(fileName);
    if (!content) throw new Error('远程备份文件不存在');
    return JSON.parse(content);
  }

  // ---------- 手动备份 ----------
  async function backup() {
    try {
      const snapshot = await takeSnapshot();
      await uploadSnapshot(snapshot);
      const now = Date.now();
      const settings = await getExtensionsSettings();
      settings.lastBackupTime = now;
      settings.lastSyncStatus = { success: true, time: now, count: snapshot.length };
      await setSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS, settings);
      showNotification('扩展备份', `已备份 ${snapshot.length} 个扩展`);
      return { success: true, message: `备份成功，${snapshot.length} 个扩展`, count: snapshot.length };
    } catch (err) {
      showNotification('扩展备份失败', err.message);
      return { success: false, message: err.message };
    }
  }

  // ---------- 手动恢复 ----------
  async function restore() {
    try {
      const remoteSnapshot = await downloadSnapshot();
      const localExts = await chrome.management.getAll();
      const localMap = new Map(localExts.map(e => [e.id, e]));
      let changed = 0;
      const missing = [];

      for (const r of remoteSnapshot) {
        const local = localMap.get(r.id);
        if (!local) {
          missing.push(r);
          continue;
        }
        if (local.enabled !== r.enabled) {
          try {
            await chrome.management.setEnabled(r.id, r.enabled);
            changed++;
          } catch (e) {
            console.warn(`无法设置扩展 ${r.id} 状态:`, e);
          }
        }
      }

      let message = `恢复完成，调整 ${changed} 个扩展。`;
      if (missing.length) {
        message += ` 缺失 ${missing.length} 个扩展。`;
      }

      const settings = await getExtensionsSettings();
      settings.lastSyncStatus = { success: true, time: Date.now(), changed, missingCount: missing.length };
      await setSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS, settings);

      showNotification('扩展恢复', message);
      return {
        success: true,
        message,
        changed,
        missing: missing.map(m => ({ id: m.id, name: m.name }))
      };
    } catch (err) {
      showNotification('扩展恢复失败', err.message);
      return { success: false, message: err.message };
    }
  }

  // ---------- 自动备份（由 background 闹钟触发）----------
  async function performAutoBackup() {
    const settings = await getExtensionsSettings();
    if (!settings.autoBackupEnabled) return;

    try {
      const snapshot = await takeSnapshot();
      await uploadSnapshot(snapshot);
      const now = Date.now();
      settings.lastBackupTime = now;
      settings.lastSyncStatus = { success: true, time: now, count: snapshot.length };
      await setSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS, settings);

      if (settings.notifyOnBackup) {
        showNotification('扩展自动备份', `已备份 ${snapshot.length} 个扩展`);
      }
      console.log('[ExtensionsSync] 自动备份成功');
    } catch (err) {
      console.error('[ExtensionsSync] 自动备份失败:', err);
      settings.lastSyncStatus = { success: false, time: Date.now(), error: err.message };
      await setSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS, settings);
      showNotification('扩展自动备份失败', err.message);
    }
  }

  // ---------- 获取统计信息（用于弹窗显示）----------
  async function getStats() {
    try {
      const exts = await chrome.management.getAll();
      const extensions = exts.filter(e => e.type === 'extension');
      const enabled = extensions.filter(e => e.enabled).length;
      const total = extensions.length;
      const settings = await getExtensionsSettings();
      return {
        total,
        enabled,
        disabled: total - enabled,
        lastBackupTime: settings.lastBackupTime || 0,
        lastStatus: settings.lastSyncStatus
      };
    } catch {
      return { total: 0, enabled: 0, disabled: 0, lastBackupTime: 0 };
    }
  }

  // 暴露给 background 用于设置闹钟
  async function setupAlarm() {
    const settings = await getExtensionsSettings();
    await chrome.alarms.clear('extensionsAutoBackup');
    if (settings.autoBackupEnabled && settings.autoBackupInterval > 0) {
      chrome.alarms.create('extensionsAutoBackup', {
        periodInMinutes: settings.autoBackupInterval * 60,
        delayInMinutes: 1
      });
      console.log(`[ExtensionsSync] 自动备份闹钟已设置，间隔 ${settings.autoBackupInterval} 小时`);
    }
  }

  // ---------- 获取缺失扩展列表（对比远程备份与本地安装）----------
  async function getMissingExtensions() {
    try {
      const remoteSnapshot = await downloadSnapshot();
      const localExts = await chrome.management.getAll();
      const localExtensions = localExts.filter(e => e.type === 'extension');
      const localIdSet = new Set(localExtensions.map(e => e.id));
      const missing = remoteSnapshot.filter(r => !localIdSet.has(r.id)).map(r => ({
        id: r.id,
        name: r.name
      }));
      return { success: true, missing };
    } catch (err) {
      console.error('[ExtensionsSync] 获取缺失扩展失败', err);
      return { success: false, error: err.message };
    }
  }

  return {
    backup,
    restore,
    performAutoBackup,
    setupAlarm,
    getStats,
    getMissingExtensions
  };
})();