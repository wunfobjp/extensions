// webdav-client.js - 增强版，支持MKCOL和更好的路径处理
self.WebDAVClient = class WebDAVClient {
  constructor(baseUrl, username, password) {
    this.baseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
    this.username = username;
    this.password = password;
  }

  _getAuthHeader() {
    const credentials = btoa(`${this.username}:${this.password}`);
    return `Basic ${credentials}`;
  }

  async _request(path, method, body = null, headers = {}) {
    const normalizedPath = path.startsWith('/') ? path : '/' + path;
    const url = `${this.baseUrl}${normalizedPath}`;
    const options = {
      method,
      headers: {
        'Authorization': this._getAuthHeader(),
        ...headers
      }
    };
    if (body) options.body = body;
    const response = await fetch(url, options);
    if (!response.ok && response.status !== 404) {
      throw new Error(`WebDAV请求失败: ${response.status} ${response.statusText}`);
    }
    return response;
  }

  async getFile(remotePath) {
    const response = await this._request(remotePath, 'GET');
    if (response.status === 404) return null;
    return await response.text();
  }

  async putFile(remotePath, content, contentType = 'application/json') {
    try {
      const response = await this._request(remotePath, 'PUT', content, {
        'Content-Type': contentType
      });
      if (response.ok) return true;
      if (response.status === 409) {
        const lastSlash = remotePath.lastIndexOf('/');
        if (lastSlash > 0) {
          const dirPath = remotePath.substring(0, lastSlash);
          await this._createDirectory(dirPath);
          return this.putFile(remotePath, content, contentType);
        }
      }
      return false;
    } catch (e) {
      if (e.message.includes('409') || e.message.includes('Conflict')) {
        const lastSlash = remotePath.lastIndexOf('/');
        if (lastSlash > 0) {
          const dirPath = remotePath.substring(0, lastSlash);
          await this._createDirectory(dirPath);
          return this.putFile(remotePath, content, contentType);
        }
      }
      throw e;
    }
  }

  async _createDirectory(dirPath) {
    const response = await this._request(dirPath, 'MKCOL');
    if (response.status === 200 || response.status === 201 || response.status === 405 || response.status === 409) {
      return true;
    }
    if (!response.ok) throw new Error(`创建目录失败: ${response.status}`);
    return true;
  }

  async testConnection(backupFileName = 'history_backup.json') {
    try {
      const response = await this._request(backupFileName, 'GET');
      return response.status === 200 || response.status === 404;
    } catch (e) {
      console.error('连接测试失败', e);
      return false;
    }
  }
};