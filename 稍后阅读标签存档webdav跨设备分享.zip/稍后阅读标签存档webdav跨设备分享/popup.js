document.addEventListener('DOMContentLoaded', () => {
    // ----- DOM 元素 -----
    const listEl = document.getElementById('list');
    const searchInput = document.getElementById('searchInput');
    const saveBtn = document.getElementById('saveBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const sharePageBtn = document.getElementById('sharePageBtn');
    const shareGroupBtn = document.getElementById('shareGroupBtn');
    const configBtn = document.getElementById('configBtn');
    const settingsSection = document.getElementById('settingsSection');
    const readFolderSelect = document.getElementById('readFolderSelect');
    const archiveFolderSelect = document.getElementById('archiveFolderSelect');
    const webdavUrl = document.getElementById('webdavUrl');
    const webdavUser = document.getElementById('webdavUser');
    const webdavPass = document.getElementById('webdavPass');
    const webdavFile = document.getElementById('webdavFile');
    const saveSettingsBtn = document.getElementById('saveSettingsBtn');
    const viewReadBtn = document.getElementById('viewReadBtn');
    const viewArchiveBtn = document.getElementById('viewArchiveBtn');
    const viewSharedBtn = document.getElementById('viewSharedBtn');
    const navBar = document.getElementById('navBar');
    const backBtn = document.getElementById('backBtn');
    const currentPathSpan = document.getElementById('currentPath');

    // ----- 状态 -----
    let currentMode = 'read';         // 'read' | 'archive' | 'shared'
    let readFolderId = null;
    let archiveFolderId = null;
    let currentFolderId = null;
    let folderStack = [];
    let isSearchMode = false;
    const DEFAULT_READ_FOLDER = 'Readlist';
    const DEFAULT_ARCHIVE_FOLDER = 'TabGroup';

    // WebDAV 配置
    let webdavConfig = {
        url: '',
        username: '',
        password: '',
        filename: 'shared_links.json'
    };
    let sharedItemsCache = [];

    // ----- 辅助函数 -----
    function getCleanTitle(title) {
        return title.replace(/^[🔵⚪]\s*/, '');
    }

    function isUnread(title) {
        return title.startsWith('🔵');
    }

    function getRootFolderId() {
        return currentMode === 'read' ? readFolderId : archiveFolderId;
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m]);
    }

    // ----- 文件夹路径工具（跨设备）-----
    async function findFolderByPath(path) {
        if (!path) return null;
        const parts = path.split('/').map(p => p.trim());
        const tree = await chrome.bookmarks.getTree();
        async function search(nodes, depth) {
            for (const node of nodes) {
                if (node.title === parts[depth]) {
                    if (depth === parts.length - 1) return node.id;
                    if (node.children) {
                        const found = await search(node.children, depth + 1);
                        if (found) return found;
                    }
                }
            }
            return null;
        }
        return search(tree, 0);
    }

    async function getFolderPathById(folderId) {
        const pathParts = [];
        let currentId = folderId;
        while (currentId && currentId !== '0') {
            const nodes = await chrome.bookmarks.get(currentId);
            if (!nodes || !nodes.length) break;
            pathParts.unshift(nodes[0].title);
            currentId = nodes[0].parentId;
        }
        return pathParts.join('/');
    }

    async function findFolderByName(folderName) {
        const tree = await chrome.bookmarks.getTree();
        const bookmarkBar = tree[0].children.find(c => c.id === '1' || c.title === '书签栏');
        if (!bookmarkBar) return null;
        async function searchInNode(node) {
            if (node.title === folderName && !node.url) return node.id;
            if (node.children) {
                for (const child of node.children) {
                    const found = await searchInNode(child);
                    if (found) return found;
                }
            }
            return null;
        }
        return searchInNode(bookmarkBar);
    }

    async function ensureDefaultFolder(folderName) {
        let id = await findFolderByName(folderName);
        if (id) return id;
        const tree = await chrome.bookmarks.getTree();
        const bookmarkBar = tree[0].children.find(c => c.id === '1' || c.title === '书签栏');
        if (!bookmarkBar) throw new Error('未找到书签栏');
        const newFolder = await chrome.bookmarks.create({ parentId: bookmarkBar.id, title: folderName });
        return newFolder.id;
    }

    // ----- 加载/保存文件夹 ID（带路径）-----
    async function saveFolderIds() {
        const readPath = readFolderId ? await getFolderPathById(readFolderId) : null;
        const archivePath = archiveFolderId ? await getFolderPathById(archiveFolderId) : null;
        await chrome.storage.local.set({ readFolderId, archiveFolderId, readFolderPath: readPath, archiveFolderPath: archivePath });
    }

    async function loadFolderIds() {
        const res = await chrome.storage.local.get(['readFolderId','archiveFolderId','folderId','readFolderPath','archiveFolderPath']);
        const isValid = async (id) => { try { await chrome.bookmarks.get(id); return true; } catch { return false; } };

        if (res.readFolderPath) { const id = await findFolderByPath(res.readFolderPath); if (id) readFolderId = id; }
        if (res.archiveFolderPath) { const id = await findFolderByPath(res.archiveFolderPath); if (id) archiveFolderId = id; }

        if (!readFolderId && res.readFolderId && await isValid(res.readFolderId)) readFolderId = res.readFolderId;
        if (!archiveFolderId && res.archiveFolderId && await isValid(res.archiveFolderId)) archiveFolderId = res.archiveFolderId;

        if (res.folderId && !readFolderId && !archiveFolderId) {
            if (await isValid(res.folderId)) { readFolderId = res.folderId; archiveFolderId = res.folderId; }
        }

        // 自动发现/创建默认文件夹
        if (!readFolderId || !(await isValid(readFolderId))) {
            const found = await findFolderByName(DEFAULT_READ_FOLDER);
            if (found) readFolderId = found;
            else readFolderId = await ensureDefaultFolder(DEFAULT_READ_FOLDER);
        }
        if (!archiveFolderId || !(await isValid(archiveFolderId))) {
            const found = await findFolderByName(DEFAULT_ARCHIVE_FOLDER);
            if (found) archiveFolderId = found;
            else archiveFolderId = await ensureDefaultFolder(DEFAULT_ARCHIVE_FOLDER);
        }

        await saveFolderIds();
    }

    // ----- 书签渲染（文件夹内容）-----
    async function renderFolderContents(query = '') {
        if (!currentFolderId) {
            const rootId = getRootFolderId();
            if (!rootId) {
                listEl.innerHTML = `<li style="border:none; color:#666;">请设置${currentMode==='read'?'稍后阅读':'标签存档'}文件夹</li>`;
                navBar.style.display = 'none';
                return;
            } else {
                currentFolderId = rootId;
                folderStack = [];
                await updateNavBar(rootId);
            }
        }
        try {
            await chrome.bookmarks.get(currentFolderId);
        } catch {
            listEl.innerHTML = '<li style="border:none; color:#666;">文件夹已被删除，请重新设置</li>';
            navBar.style.display = 'none';
            return;
        }
        try {
            const children = await chrome.bookmarks.getChildren(currentFolderId);
            let filtered = children;
            if (query) {
                const q = query.toLowerCase();
                filtered = children.filter(item => getCleanTitle(item.title).toLowerCase().includes(q));
            }
            filtered = filtered.reverse();
            listEl.innerHTML = '';
            for (const item of filtered) {
                const li = document.createElement('li');
                const isFolder = !item.url;
                const unread = !isFolder && isUnread(item.title);
                const displayTitle = getCleanTitle(item.title);
                li.innerHTML = `
                    <button class="del-btn">✕</button>
                    <div class="status-icon" style="cursor:pointer;">${isFolder ? '📁' : (unread ? '🔵' : '⚪')}</div>
                    <div class="item-info">
                        <a href="${isFolder ? '#' : item.url}" class="title ${!unread && !isFolder ? 'read-text' : ''}" target="_blank">${escapeHtml(displayTitle)}</a>
                    </div>
                `;
                const titleLink = li.querySelector('.title');
                const iconBtn = li.querySelector('.status-icon');
                if (isFolder) {
                    const handler = e => { e.preventDefault(); openFolder(item.id, item.title); };
                    titleLink.onclick = handler;
                    iconBtn.onclick = handler;
                } else {
                    titleLink.onclick = async e => {
                        if (unread) {
                            await chrome.bookmarks.update(item.id, { title: item.title.replace('🔵', '⚪') });
                            renderFolderContents(searchInput.value);
                        }
                    };
                    iconBtn.onclick = async () => {
                        const newTitle = unread ? item.title.replace('🔵', '⚪') : '🔵 ' + item.title.replace(/^⚪\s*/, '');
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                        renderFolderContents(searchInput.value);
                    };
                }
                li.querySelector('.del-btn').onclick = async () => {
                    if (isFolder) {
                        await chrome.bookmarks.removeTree(item.id);
                        if (item.id === currentFolderId || folderStack.some(f => f.id === item.id)) await resetNavigation();
                        else renderFolderContents(searchInput.value);
                    } else {
                        await chrome.bookmarks.remove(item.id);
                        renderFolderContents(searchInput.value);
                    }
                };
                listEl.appendChild(li);
            }
            if (filtered.length === 0) listEl.innerHTML = '<li style="border:none; color:#999;">暂无内容</li>';
        } catch (e) {
            listEl.innerHTML = '<li style="border:none;">加载失败</li>';
        }
    }

    // 搜索
    async function searchBookmarks(folderId, query) {
        const results = [];
        const q = query.toLowerCase();
        async function traverse(id) {
            const children = await chrome.bookmarks.getChildren(id);
            for (const child of children) {
                if (child.url) {
                    if (getCleanTitle(child.title).toLowerCase().includes(q) || child.url.toLowerCase().includes(q)) results.push(child);
                } else await traverse(child.id);
            }
        }
        await traverse(folderId);
        return results;
    }

    async function renderSearchResults(query) {
        const rootId = getRootFolderId();
        if (!rootId) { listEl.innerHTML = '<li>请先设置文件夹</li>'; return; }
        listEl.innerHTML = '<li>搜索中...</li>';
        const results = await searchBookmarks(rootId, query);
        if (!results.length) { listEl.innerHTML = '<li>未找到匹配</li>'; return; }
        listEl.innerHTML = '';
        for (const item of results) {
            const li = document.createElement('li');
            const unread = isUnread(item.title);
            li.innerHTML = `
                <button class="del-btn">✕</button>
                <div class="status-icon" style="cursor:pointer;">${unread ? '🔵' : '⚪'}</div>
                <div class="item-info"><a href="${item.url}" class="title ${!unread?'read-text':''}" target="_blank">${escapeHtml(getCleanTitle(item.title))}</a></div>
            `;
            li.querySelector('.title').onclick = async e => { if(unread){ await chrome.bookmarks.update(item.id,{title:item.title.replace('🔵','⚪')}); renderSearchResults(query); } };
            li.querySelector('.status-icon').onclick = async () => {
                const newTitle = unread ? item.title.replace('🔵','⚪') : '🔵 '+item.title.replace(/^⚪\s*/,'');
                await chrome.bookmarks.update(item.id,{title:newTitle});
                renderSearchResults(query);
            };
            li.querySelector('.del-btn').onclick = async () => { await chrome.bookmarks.remove(item.id); renderSearchResults(query); };
            listEl.appendChild(li);
        }
    }

    // 导航
    async function updateNavBar(folderId) {
        if (!folderId) { navBar.style.display = 'none'; return; }
        const rootId = getRootFolderId();
        if (folderId === rootId && folderStack.length === 0) { navBar.style.display = 'none'; return; }
        navBar.style.display = 'flex';
        try {
            const node = await chrome.bookmarks.get(folderId);
            currentPathSpan.textContent = node[0]?.title || '文件夹';
        } catch { currentPathSpan.textContent = '文件夹'; }
    }

    async function openFolder(folderId) {
        if (!folderId) return;
        if (currentFolderId) {
            let title = '根目录';
            try { title = (await chrome.bookmarks.get(currentFolderId))[0].title; } catch {}
            folderStack.push({ id: currentFolderId, title });
        }
        currentFolderId = folderId;
        await updateNavBar(folderId);
        searchInput.value = '';
        isSearchMode = false;
        renderFolderContents('');
    }

    async function goBack() {
        if (folderStack.length === 0) {
            const rootId = getRootFolderId();
            if (rootId) { currentFolderId = rootId; folderStack = []; await updateNavBar(rootId); searchInput.value = ''; isSearchMode = false; renderFolderContents(''); }
        } else {
            const parent = folderStack.pop();
            currentFolderId = parent.id;
            await updateNavBar(parent.id);
            searchInput.value = '';
            isSearchMode = false;
            renderFolderContents('');
        }
    }

    async function resetNavigation() {
        const rootId = getRootFolderId();
        if (rootId) {
            currentFolderId = rootId;
            folderStack = [];
            await updateNavBar(rootId);
            searchInput.value = '';
            isSearchMode = false;
            renderFolderContents('');
        } else {
            listEl.innerHTML = '<li>请重新设置文件夹</li>';
            navBar.style.display = 'none';
        }
    }

    backBtn.onclick = goBack;

    // 搜索输入
    let searchTimer;
    function onSearchInput() {
        clearTimeout(searchTimer);
        const query = searchInput.value;
        if (query.trim()) {
            isSearchMode = true;
            navBar.style.display = 'none';
            listEl.innerHTML = '<li>搜索中...</li>';
            searchTimer = setTimeout(() => renderSearchResults(query), 250);
        } else {
            isSearchMode = false;
            navBar.style.display = (currentFolderId && currentFolderId !== getRootFolderId()) ? 'flex' : 'none';
            renderFolderContents('');
        }
    }
    searchInput.oninput = onSearchInput;

    // 保存单页/存档标签
    saveBtn.onclick = async () => {
        if (!readFolderId) { alert('请先设置稍后阅读文件夹'); return; }
        try { await chrome.bookmarks.get(readFolderId); } catch { alert('文件夹不存在'); return; }
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.bookmarks.create({ parentId: readFolderId, title: '🔵 ' + tab.title, url: tab.url });
        if (currentMode === 'read') await resetNavigation(); else alert('已保存');
    };

    archiveBtn.onclick = async () => {
        if (!archiveFolderId) { alert('请先设置标签存档文件夹'); return; }
        try { await chrome.bookmarks.get(archiveFolderId); } catch { alert('文件夹不存在'); return; }
        const tabs = await chrome.tabs.query({ currentWindow: true });
        const timestamp = new Date().toLocaleString('zh-CN', { hour12: false }).replace(/:/g, '-');
        const newFolder = await chrome.bookmarks.create({ parentId: archiveFolderId, title: timestamp });
        for (const tab of tabs) {
            if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://'))
                await chrome.bookmarks.create({ parentId: newFolder.id, title: '🔵 ' + tab.title, url: tab.url });
        }
        if (currentMode === 'archive') await resetNavigation(); else alert('已存档');
    };

    // ----- WebDAV 功能 -----
    function getAuthHeader() {
        if (!webdavConfig.username || !webdavConfig.password) return null;
        return 'Basic ' + btoa(`${webdavConfig.username}:${webdavConfig.password}`);
    }

    async function webdavRequest(method, path, body = null) {
        const baseUrl = webdavConfig.url.replace(/\/$/, '');
        const url = `${baseUrl}/${path.replace(/^\//, '')}`;
        const headers = { 'Content-Type': 'application/json' };
        const auth = getAuthHeader();
        if (auth) headers['Authorization'] = auth;
        const res = await fetch(url, { method, headers, body });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res;
    }

    async function loadSharedItems() {
        try {
            const res = await webdavRequest('GET', webdavConfig.filename);
            const text = await res.text();
            return text ? JSON.parse(text) : [];
        } catch (e) {
            if (e.message.includes('404')) return [];
            throw e;
        }
    }

    async function saveSharedItems(items) {
        await webdavRequest('PUT', webdavConfig.filename, JSON.stringify(items, null, 2));
    }

    async function addSharedItem(type, data) {
        const items = await loadSharedItems();
        const newItem = { id: Date.now() + '-' + Math.random().toString(36).substr(2,6), type, timestamp: new Date().toISOString(), ...data };
        items.push(newItem);
        await saveSharedItems(items);
        sharedItemsCache = items;
        return newItem;
    }

    async function deleteSharedItem(id) {
        let items = await loadSharedItems();
        items = items.filter(i => i.id !== id);
        await saveSharedItems(items);
        sharedItemsCache = items;
    }

    async function shareCurrentPage() {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await addSharedItem('page', { title: tab.title, url: tab.url });
        alert('已分享当前页面');
        if (currentMode === 'shared') renderSharedList();
    }

    async function shareCurrentWindowGroup() {
        const tabs = await chrome.tabs.query({ currentWindow: true });
        const validTabs = tabs.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'));
        if (!validTabs.length) { alert('无可分享标签'); return; }
        await addSharedItem('group', { name: `标签组 ${new Date().toLocaleString('zh-CN',{hour12:false})}`, tabs: validTabs.map(t=>({title:t.title,url:t.url})) });
        alert(`已分享 ${validTabs.length} 个标签`);
        if (currentMode === 'shared') renderSharedList();
    }

    async function renderSharedList() {
        listEl.innerHTML = '<li class="loading">加载中...</li>';
        try {
            sharedItemsCache = await loadSharedItems();
            if (!sharedItemsCache.length) { listEl.innerHTML = '<li style="border:none;color:#999;">暂无分享</li>'; return; }
            const sorted = [...sharedItemsCache].reverse();
            listEl.innerHTML = '';
            for (const item of sorted) {
                const li = document.createElement('li');
                li.className = 'shared-item';
                const isGroup = item.type === 'group';
                const icon = isGroup ? '📁' : '🔗';
                const timeStr = new Date(item.timestamp).toLocaleString('zh-CN', { hour12: false });
                let titleHtml = isGroup ? `${escapeHtml(item.name)} (${item.tabs.length}个标签)` : `<a href="${item.url}" target="_blank" style="color:#1a1a1a;">${escapeHtml(item.title)}</a>`;
                li.innerHTML = `
                    <div class="shared-icon">${icon}</div>
                    <div class="shared-content"><div class="shared-title">${titleHtml}</div><div class="shared-meta"><span>${timeStr}</span>${!isGroup?`<span>${escapeHtml(item.url.substring(0,40))}…</span>`:''}</div></div>
                    <div class="shared-actions"><button class="open-shared" data-id="${item.id}" data-type="${item.type}">打开</button><button class="delete-shared" data-id="${item.id}">删除</button></div>
                `;
                listEl.appendChild(li);
            }
            document.querySelectorAll('.open-shared').forEach(btn => {
                btn.addEventListener('click', async e => {
                    const { id, type } = e.target.dataset;
                    const item = sharedItemsCache.find(i => i.id === id);
                    if (!item) return;
                    if (type === 'page') chrome.tabs.create({ url: item.url });
                    else if (type === 'group') for (const t of item.tabs) chrome.tabs.create({ url: t.url, active: false });
                });
            });
            document.querySelectorAll('.delete-shared').forEach(btn => {
                btn.addEventListener('click', async e => { await deleteSharedItem(e.target.dataset.id); renderSharedList(); });
            });
        } catch (e) {
            listEl.innerHTML = `<li class="error-message">加载失败: ${e.message}<br>请检查 WebDAV 配置</li>`;
        }
    }

    // ----- 设置面板 -----
    async function populateFolderSelects() {
        const tree = await chrome.bookmarks.getTree();
        const walk = (nodes, depth, select) => {
            nodes.forEach(n => {
                if (!n.url) {
                    const opt = document.createElement('option');
                    opt.value = n.id;
                    opt.textContent = '\u00A0'.repeat(depth*2) + (n.title || '书签栏');
                    select.appendChild(opt);
                    if (n.children) walk(n.children, depth+1, select);
                }
            });
        };
        readFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        archiveFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        walk(tree, 0, readFolderSelect);
        walk(tree, 0, archiveFolderSelect);
        if (readFolderId) readFolderSelect.value = readFolderId;
        if (archiveFolderId) archiveFolderSelect.value = archiveFolderId;
    }

    async function loadWebDAVSettings() {
        const stored = await chrome.storage.local.get(['webdavUrl','webdavUser','webdavPass','webdavFile']);
        if (stored.webdavUrl) webdavUrl.value = stored.webdavUrl;
        if (stored.webdavUser) webdavUser.value = stored.webdavUser;
        if (stored.webdavPass) webdavPass.value = stored.webdavPass;
        if (stored.webdavFile) webdavFile.value = stored.webdavFile;
        webdavConfig = {
            url: stored.webdavUrl || '',
            username: stored.webdavUser || '',
            password: stored.webdavPass || '',
            filename: stored.webdavFile || 'shared_links.json'
        };
    }

    async function saveAllSettings() {
        // 保存文件夹选择
        const newRead = readFolderSelect.value;
        const newArchive = archiveFolderSelect.value;
        if (newRead && newArchive) {
            readFolderId = newRead;
            archiveFolderId = newArchive;
            await saveFolderIds();
        }
        // 保存 WebDAV
        webdavConfig.url = webdavUrl.value.trim();
        webdavConfig.username = webdavUser.value.trim();
        webdavConfig.password = webdavPass.value;
        webdavConfig.filename = webdavFile.value.trim() || 'shared_links.json';
        await chrome.storage.local.set({
            webdavUrl: webdavConfig.url,
            webdavUser: webdavConfig.username,
            webdavPass: webdavConfig.password,
            webdavFile: webdavConfig.filename
        });
        alert('设置已保存');
    }

    // ----- 模式切换 -----
    function setMode(mode) {
        currentMode = mode;
        viewReadBtn.classList.remove('active');
        viewArchiveBtn.classList.remove('active');
        viewSharedBtn.classList.remove('active');
        if (mode === 'read') viewReadBtn.classList.add('active');
        else if (mode === 'archive') viewArchiveBtn.classList.add('active');
        else if (mode === 'shared') viewSharedBtn.classList.add('active');
        searchInput.value = '';
        isSearchMode = false;
        navBar.style.display = 'none';
        if (mode === 'shared') renderSharedList();
        else {
            const rootId = getRootFolderId();
            if (rootId) { currentFolderId = rootId; folderStack = []; renderFolderContents(''); }
            else listEl.innerHTML = `<li>请设置${mode==='read'?'稍后阅读':'标签存档'}文件夹</li>`;
        }
    }

    // ----- 事件绑定 -----
    viewReadBtn.onclick = () => setMode('read');
    viewArchiveBtn.onclick = () => setMode('archive');
    viewSharedBtn.onclick = () => setMode('shared');

    configBtn.onclick = async () => {
        await loadWebDAVSettings();
        await populateFolderSelects();
        settingsSection.style.display = settingsSection.style.display === 'none' ? 'block' : 'none';
    };

    saveSettingsBtn.onclick = async () => {
        await saveAllSettings();
        settingsSection.style.display = 'none';
        if (currentMode !== 'shared') setMode(currentMode);
    };

    sharePageBtn.onclick = async () => {
        if (!webdavConfig.url) { alert('请先配置 WebDAV'); return; }
        try { await shareCurrentPage(); } catch (e) { alert('分享失败: ' + e.message); }
    };

    shareGroupBtn.onclick = async () => {
        if (!webdavConfig.url) { alert('请先配置 WebDAV'); return; }
        try { await shareCurrentWindowGroup(); } catch (e) { alert('分享失败: ' + e.message); }
    };

    // ----- 初始化 -----
    async function init() {
        await loadFolderIds();        // 自动发现/创建 Readlist 和 TabGroup
        await loadWebDAVSettings();
        setMode('read');
    }
    init();
});