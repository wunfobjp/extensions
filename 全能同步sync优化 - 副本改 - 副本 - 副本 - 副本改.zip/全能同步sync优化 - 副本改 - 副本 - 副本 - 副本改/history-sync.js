// history-sync.js - 历史记录同步（完整版：进度、保护、静默、备份）
self.HistorySync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  // 进度回调（通过 storage 广播）
  let progressCallback = null;

  function setProgressCallback(cb) {
    progressCallback = cb;
  }

  // 节流：确保两次进度写入至少间隔 200ms
  let lastProgressWrite = 0;
  async function updateProgress(phase, current, total, message) {
    const now = Date.now();
    if (now - lastProgressWrite < 200 && phase !== 'done' && phase !== 'error') {
      return;
    }
    lastProgressWrite = now;
    const progress = { phase, current, total, message, timestamp: now };
    await chrome.storage.local.set({ sync_progress: progress });
    if (progressCallback) progressCallback(progress);
  }

  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) throw new Error('请先在设置中配置 WebDAV 参数');
    return new WebDAVClient(url, user, pass);
  }

  /**
   * 获取远程备份，同时返回记录和原始总数（用于数据保护）
   */
  async function getRemoteBackup(client) {
    const content = await client.getFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`);
    if (!content) return { records: [], count: 0 };

    try {
      const data = JSON.parse(content);
      // 支持 [url, title, time, count] 格式或原始对象格式
      if (Array.isArray(data) && data.length && Array.isArray(data[0])) {
        const records = data.map(r => ({
          url: r[0],
          title: r[1] || '',
          lastVisitTime: r[2],
          visitCount: r[3] || 1
        }));
        return { records, count: data.length };
      }
      if (Array.isArray(data)) {
        return { records: data, count: data.length };
      }
      return { records: [], count: 0 };
    } catch (e) {
      console.error('[HistorySync] 解析远程备份失败:', e);
      return { records: [], count: 0 };
    }
  }

  /**
   * 安全上传：压缩格式 + 空数据拦截 + 数量减少保护 + 远程备份
   */
  async function putRemoteBackup(client, records, previousCount) {
    if (!records || records.length === 0) {
      console.warn('[HistorySync] 拦截空数据上传，跳过写入');
      return;
    }

    // 1. 数量骤降比例保护（只对增量合并有效，全量跳过）
    if (typeof previousCount === 'number' && previousCount > 0) {
      if (records.length < previousCount) {
        const reduction = ((previousCount - records.length) / previousCount) * 100;
        // 允许少量减少（例如某些记录确实被本地清理），但超过 50% 拒绝
        if (reduction > 50) {
          throw new Error(
            `合并后记录数减少 ${reduction.toFixed(0)}% (${previousCount}→${records.length})，拒绝上传`
          );
        }
        console.warn(`[HistorySync] 记录数减少 ${reduction.toFixed(1)}%，仍在可接受范围`);
      }
    }

    // 2. 上传前备份现有远程记录到本地存储（以防网络错误或上传失败）
    const currentBackup = await getRemoteBackup(client);
    if (currentBackup.records.length > 0) {
      await setStorage('history_remote_backup', currentBackup.records);
      console.log('[HistorySync] 已备份当前远程记录');
    }

    // 3. 压缩并上传
    const compressed = records.map(r => [
      r.url,
      r.title || '',
      r.lastVisitTime,
      r.visitCount || 1
    ]);
    const jsonStr = JSON.stringify(compressed);
    try {
      await client.putFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`, jsonStr);
      // 上传成功，清除备份
      await setStorage('history_remote_backup', null);
      console.log('[HistorySync] 上传成功，本地备份已清除');
    } catch (uploadErr) {
      console.error('[HistorySync] 上传失败，远程数据可能不完整，已保留本地备份');
      throw uploadErr;
    }
  }

  async function getHistorySince(startTime) {
    const allItems = [];
    let currentStart = startTime || 0;
    let hasMore = true;
    const MAX_RESULTS_PER_PAGE = 10000;
    let iteration = 0;
    const MAX_ITERATIONS = 100;

    while (hasMore && iteration++ < MAX_ITERATIONS) {
      const results = await new Promise((resolve) => {
        chrome.history.search({
          text: '',
          startTime: currentStart,
          endTime: Date.now(),
          maxResults: MAX_RESULTS_PER_PAGE,
        }, resolve);
      });

      if (results.length === 0) break;

      const items = results.map(item => ({
        url: item.url,
        title: item.title || '',
        lastVisitTime: item.lastVisitTime,
        visitCount: item.visitCount
      }));
      allItems.push(...items);

      if (results.length === MAX_RESULTS_PER_PAGE) {
        const lastTime = results[results.length - 1].lastVisitTime;
        // 保护：防止死循环（极少情况时间戳相同或回退）
        if (lastTime <= currentStart) {
          console.warn('[HistorySync] 分页时间戳未推进，停止分页');
          hasMore = false;
        } else {
          currentStart = lastTime + 1;
        }
      } else {
        hasMore = false;
      }
    }

    // 去重并取最大 visitCount
    const uniqueMap = new Map();
    for (const item of allItems) {
      const key = `${item.url}|${item.lastVisitTime}`;
      const existing = uniqueMap.get(key);
      if (!existing || item.visitCount > existing.visitCount) {
        uniqueMap.set(key, item);
      }
    }
    return Array.from(uniqueMap.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
  }

  /**
   * 合并记录时取最大 visitCount，保留较新的 title（如果有）
   */
  function mergeHistoryRecords(existing, incoming) {
    const map = new Map();
    existing.forEach(rec => map.set(`${rec.url}|${rec.lastVisitTime}`, rec));
    incoming.forEach(rec => {
      const key = `${rec.url}|${rec.lastVisitTime}`;
      if (map.has(key)) {
        const old = map.get(key);
        old.visitCount = Math.max(old.visitCount, rec.visitCount);
        // 如果新记录的标题非空且更新，则替换
        if (rec.title && rec.title !== old.title) {
          old.title = rec.title;
        }
      } else {
        map.set(key, rec);
      }
    });
    return Array.from(map.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
  }

  /**
   * 高性能写入 + 重试 + 节流进度
   * 注意：chrome.history.addUrl 无法设置访问时间，所有导入记录的时间会变为“现在”
   */
  async function addHistoryWithLimit(records, concurrency = 8, maxRetries = 2) {
    let addedCount = 0;
    const failedUrls = [];
    let index = 0;
    const total = records.length;

    async function worker() {
      while (index < total) {
        const i = index++;
        const record = records[i];
        if (!record || !record.url || !record.url.startsWith('http')) continue;

        let success = false;
        for (let retry = 0; retry <= maxRetries; retry++) {
          try {
            await new Promise((resolve, reject) => {
              chrome.history.addUrl({ url: record.url }, () => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve();
              });
            });
            addedCount++;
            success = true;
            break;
          } catch (err) {
            if (retry === maxRetries) failedUrls.push(record.url);
            await new Promise(r => setTimeout(r, 100 * (retry + 1)));
          }
        }

        // 每 500 条更新一次进度，并受节流限制
        if (i % 500 === 0 || i === total - 1) {
          await updateProgress('downloading', i + 1, total, `已导入 ${addedCount} 条`);
        }
      }
    }

    const workers = Array(concurrency).fill().map(() => worker());
    await Promise.all(workers);
    return { addedCount, failedUrls };
  }

  // ---------- 统一增量备份 ----------
  async function performIncrementalBackup(silent = false) {
    try {
      const lastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      const newHistory = await getHistorySince(lastSync);

      if (newHistory.length === 0) {
        if (!silent) showNotification('合并上传', '本地无新增记录');
        console.log('[HistorySync] 无新增记录');
        return { success: true, message: '无新增记录' };
      }

      const client = await getWebDAVClient();
      const { records: remoteRecords, count: remoteCount } = await getRemoteBackup(client);
      console.log(`[HistorySync] 本地新增 ${newHistory.length} 条，远程现有 ${remoteCount} 条`);

      const merged = mergeHistoryRecords(remoteRecords, newHistory);
      console.log(`[HistorySync] 合并后 ${merged.length} 条`);

      // 关键保护：合并后的记录数不得少于远程原有数量
      if (merged.length < remoteCount) {
        console.error(`[HistorySync] 严重错误：合并后记录数 ${merged.length} < 远程原始 ${remoteCount}，拒绝上传`);
        throw new Error('合并后记录数异常减少，已阻止上传以保护数据');
      }

      // 上传（内含远程备份保护）
      await putRemoteBackup(client, merged, remoteCount);

      const maxTime = Math.max(...newHistory.map(r => r.lastVisitTime));
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);

      if (!silent) {
        showNotification('合并上传完成', `新增 ${newHistory.length} 条，云端总计 ${merged.length} 条`);
        await updateProgress('done', 1, 1, `完成，新增 ${newHistory.length} 条`);
      } else {
        console.log(`[HistorySync] 自动同步完成，新增 ${newHistory.length} 条，云端总计 ${merged.length} 条`);
      }
      return { success: true, message: `已合并上传 ${newHistory.length} 条` };
    } catch (err) {
      if (!silent) {
        showNotification('合并上传失败', err.message);
        await updateProgress('error', 0, 1, err.message);
      }
      console.error('[HistorySync] 增量备份失败:', err);
      return { success: false, message: err.message };
    }
  }

  // 手动增量备份（带通知和进度）
  async function incrementalBackup() {
    await updateProgress('uploading', 0, 1, '正在获取本地新增记录...');
    return performIncrementalBackup(false);
  }

  // 静默增量备份（用于自动同步）
  async function silentIncrementalBackup() {
    return performIncrementalBackup(true);
  }

  // 全量下载
  async function fullDownload() {
    await updateProgress('downloading', 0, 2, '正在下载云端备份...');
    try {
      const client = await getWebDAVClient();
      const { records: remoteRecords } = await getRemoteBackup(client);

      if (remoteRecords.length === 0) {
        showNotification('全量下载', '远程无数据');
        await updateProgress('done', 1, 1, '远程无数据');
        return { success: false, message: '无远程数据' };
      }

      await updateProgress('downloading', 1, 2, `正在导入 ${remoteRecords.length} 条记录...`);
      const { addedCount, failedUrls } = await addHistoryWithLimit(remoteRecords, 8, 2);

      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, Date.now());
      const msg = `成功导入 ${addedCount} 条，失败 ${failedUrls.length} 条。⚠️ 注意：导入的历史时间将重置为“现在”。`;
      showNotification('全量下载完成', msg);
      await updateProgress('done', 1, 1, msg);
      return { success: true, message: msg, failedUrls };
    } catch (err) {
      showNotification('全量下载失败', err.message);
      await updateProgress('error', 0, 1, err.message);
      return { success: false, message: err.message };
    }
  }

  // 全量上传
  async function fullBackup() {
    await updateProgress('uploading', 0, 2, '正在收集全部历史记录...');
    try {
      const allHistory = await getHistorySince(0);
      const totalCount = allHistory.length;

      if (totalCount > 40000) {
        showNotification('全量上传', `正在备份 ${totalCount} 条，请勿关闭浏览器`);
      }

      await updateProgress('uploading', 1, 2, `正在上传 ${totalCount} 条记录...`);
      const client = await getWebDAVClient();
      // 全量上传时不检测骤降（传入 null）
      await putRemoteBackup(client, allHistory, null);

      const maxTime = allHistory.length > 0
        ? Math.max(...allHistory.map(r => r.lastVisitTime))
        : Date.now();
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);

      showNotification('全量上传完成', `已备份全部 ${totalCount} 条历史`);
      await updateProgress('done', 1, 1, `完成，共 ${totalCount} 条`);
      return { success: true, message: `全量上传 ${totalCount} 条` };
    } catch (err) {
      showNotification('全量上传失败', err.message);
      await updateProgress('error', 0, 1, err.message);
      return { success: false, message: err.message };
    }
  }

  return {
    incrementalBackup,
    silentIncrementalBackup,
    fullDownload,
    fullBackup,
    setProgressCallback
  };
})();