// history-viewer.js - 历史记录备份查看器（完整版，支持远程修复）
const { STORAGE_KEYS, getStorage } = self.Common;
const WebDAVClient = self.WebDAVClient;

const CACHE_KEY = 'history_viewer_cache';
const CACHE_TIME_KEY = 'history_viewer_cache_time';
const CACHE_DURATION = 30 * 60 * 1000; // 远程缓存 30 分钟

let allRecords = [];          // 合并后的完整数据
let filteredRecords = [];
let currentPage = 0;
const PAGE_SIZE = 100;
let sortField = 'lastVisitTime';
let sortDir = 'desc';
let sourceFilter = 'all';    // 'all' | 'local' | 'remote' | 'both'

// DOM 元素
const searchInput = document.getElementById('searchInput');
const reloadBtn = document.getElementById('reloadBtn');
const exportCSVBtn = document.getElementById('exportCSVBtn');
const infoStatus = document.getElementById('infoStatus');
const tableContainer = document.getElementById('tableContainer');
const sourceSelect = document.getElementById('sourceSelect');
const repairBtn = document.getElementById('repairBtn');

let searchTimer;

// ---------- 工具函数 ----------
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[m]);
}

// ---------- 获取全部本地历史记录（分页游标）----------
async function getLocalHistory() {
  const allItems = [];
  let currentStart = 0;
  let hasMore = true;
  const MAX_RESULTS_PER_PAGE = 10000;
  let iteration = 0;
  const MAX_ITERATIONS = 100;

  while (hasMore && iteration++ < MAX_ITERATIONS) {
    const results = await new Promise((resolve) => {
      chrome.history.search({
        text: '',
        startTime: currentStart,
        endTime: Date.now(),
        maxResults: MAX_RESULTS_PER_PAGE,
      }, resolve);
    });

    if (results.length === 0) break;

    const items = results.map(item => ({
      url: item.url,
      title: item.title || '',
      lastVisitTime: item.lastVisitTime,
      visitCount: item.visitCount
    }));
    allItems.push(...items);

    if (results.length === MAX_RESULTS_PER_PAGE) {
      const lastTime = results[results.length - 1].lastVisitTime;
      if (lastTime <= currentStart) {
        hasMore = false;
      } else {
        currentStart = lastTime + 1;
      }
    } else {
      hasMore = false;
    }
  }

  // 本地去重（同 url+timestamp 取最大 visitCount）
  const uniqueMap = new Map();
  for (const item of allItems) {
    const key = `${item.url}|${item.lastVisitTime}`;
    const existing = uniqueMap.get(key);
    if (!existing || item.visitCount > existing.visitCount) {
      uniqueMap.set(key, item);
    }
  }
  return Array.from(uniqueMap.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
}

// ---------- 远程缓存操作 ----------
async function getCachedData() {
  const cached = await chrome.storage.local.get([CACHE_KEY, CACHE_TIME_KEY]);
  if (cached[CACHE_KEY] && cached[CACHE_TIME_KEY]) {
    const age = Date.now() - cached[CACHE_TIME_KEY];
    if (age < CACHE_DURATION) {
      return cached[CACHE_KEY];
    }
  }
  return null;
}

async function setCache(data) {
  await chrome.storage.local.set({
    [CACHE_KEY]: data,
    [CACHE_TIME_KEY]: Date.now()
  });
}

// ---------- 合并远程与本地记录 ----------
function mergeRecords(remoteRecords, localRecords) {
  const map = new Map(); // key: `${url}|${lastVisitTime}`

  // 先加入远程记录
  for (const rec of remoteRecords) {
    const key = `${rec.url}|${rec.lastVisitTime}`;
    map.set(key, { ...rec, source: 'remote' });
  }

  // 合并本地记录
  for (const rec of localRecords) {
    const key = `${rec.url}|${rec.lastVisitTime}`;
    const existing = map.get(key);
    if (existing) {
      // 记录已存在（远程也有）
      existing.source = 'both';
      // 标题优先保留非空且更新（优先本地标题，若本地无标题则保留远程）
      if (rec.title && (!existing.title || existing.title === existing.url)) {
        existing.title = rec.title;
      }
      // 访问次数取最大值
      existing.visitCount = Math.max(existing.visitCount, rec.visitCount);
    } else {
      // 纯本地记录
      map.set(key, { ...rec, source: 'local' });
    }
  }

  return Array.from(map.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
}

// ---------- 加载数据（远程+本地合并）----------
async function loadBackup(forceRefresh = false) {
  tableContainer.innerHTML = '<div class="loading">正在读取数据，请稍候...</div>';

  try {
    // 1. 获取远程数据（优先缓存）
    let remoteRecords = [];
    if (!forceRefresh) {
      const cached = await getCachedData();
      if (cached) {
        remoteRecords = cached;
        tableContainer.innerHTML = '<div class="loading">正在获取本地历史记录...</div>';
      }
    }

    if (remoteRecords.length === 0 || forceRefresh) {
      tableContainer.innerHTML = '<div class="loading">正在从云端拉取备份...</div>';
      const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
      const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
      const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
      if (!url || !user || !pass) throw new Error('请先在选项页配置 WebDAV');

      const client = new WebDAVClient(url, user, pass);
      const fileName = STORAGE_KEYS.HISTORY_BACKUP_FILE || 'history_backup.json';
      const content = await client.getFile(fileName);
      if (!content) throw new Error('云端无备份文件');

      // 安全的 JSON 解析
      let raw;
      try {
        raw = JSON.parse(content);
      } catch (parseErr) {
        console.error('JSON 解析失败，远程文件可能已损坏', parseErr);
        throw new Error(`远程备份文件损坏（${parseErr.message}），请点击“修复远程文件”按钮进行修复。`);
      }

      if (Array.isArray(raw) && raw.length && Array.isArray(raw[0])) {
        remoteRecords = raw.map(r => ({
          url: r[0],
          title: r[1] || '',
          lastVisitTime: r[2],
          visitCount: r[3] || 1
        }));
      } else if (Array.isArray(raw)) {
        remoteRecords = raw.map(r => ({
          ...r,
          title: r.title || ''
        }));
      } else {
        throw new Error('远程数据格式不正确，请修复远程文件');
      }
      await setCache(remoteRecords);
    }

    // 2. 获取本地历史记录（每次都实时获取）
    tableContainer.innerHTML = '<div class="loading">正在读取本地历史记录...</div>';
    const localRecords = await getLocalHistory();

    // 3. 合并
    allRecords = mergeRecords(remoteRecords, localRecords);

    updateInfo();
    applyFilters();
  } catch (err) {
    tableContainer.innerHTML = `<div class="error">加载失败：${err.message}<br>
      <button id="retryBtn" style="margin-top:10px;">重试</button>
      <button id="repairInlineBtn" style="margin-left:8px; background:#e67e22; color:white;">修复远程文件</button>
    </div>`;
    bindRetryButtons();
    infoStatus.textContent = '';
  }
}

function bindRetryButtons() {
  const retryBtn = document.getElementById('retryBtn');
  const repairInlineBtn = document.getElementById('repairInlineBtn');
  if (retryBtn) retryBtn.addEventListener('click', () => loadBackup(true));
  if (repairInlineBtn) repairInlineBtn.addEventListener('click', repairRemoteFile);
}

// ---------- 修复远程文件（执行全量上传）----------
async function repairRemoteFile() {
  if (!confirm('确定要用本地历史记录覆盖远程备份吗？这将修复损坏的文件。')) return;
  repairBtn.disabled = true;
  repairBtn.textContent = '修复中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'fullBackup' });
    if (result.success) {
      alert('远程文件已修复，即将重新加载。');
      loadBackup(true);
    } else {
      alert('修复失败：' + result.message);
    }
  } catch (e) {
    alert('修复过程出错：' + e.message);
  } finally {
    repairBtn.disabled = false;
    repairBtn.textContent = '修复远程文件';
  }
}

function updateInfo() {
  const total = allRecords.length;
  const remote = allRecords.filter(r => r.source === 'remote').length;
  const local = allRecords.filter(r => r.source === 'local').length;
  const both = allRecords.filter(r => r.source === 'both').length;
  infoStatus.textContent = `共 ${total} 条（远程 ${remote} / 本地 ${local} / 两者 ${both}）`;
}

// ---------- 过滤与排序 ----------
function applyFilters() {
  const query = searchInput.value.trim().toLowerCase();

  // 来源筛选 + 搜索
  filteredRecords = allRecords.filter(r => {
    if (sourceFilter !== 'all' && r.source !== sourceFilter) return false;
    if (!query) return true;
    return (r.title || '').toLowerCase().includes(query) ||
           (r.url || '').toLowerCase().includes(query);
  });

  // 排序
  filteredRecords.sort((a, b) => {
    let valA = a[sortField] || '';
    let valB = b[sortField] || '';
    if (sortField === 'lastVisitTime' || sortField === 'visitCount') {
      valA = Number(valA);
      valB = Number(valB);
    }
    if (valA < valB) return sortDir === 'asc' ? -1 : 1;
    if (valA > valB) return sortDir === 'asc' ? 1 : -1;
    return 0;
  });

  currentPage = 0;
  renderPage();
}

function renderPage() {
  const start = currentPage * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  const pageData = filteredRecords.slice(start, end);

  if (pageData.length === 0) {
    tableContainer.innerHTML = '<div class="loading">无匹配记录</div>';
    return;
  }

  let html = '<table><thead><tr>';
  const headers = [
    { label: '来源', field: 'source' },
    { label: '访问时间', field: 'lastVisitTime' },
    { label: '标题 / URL', field: 'title' },
    { label: '访问次数', field: 'visitCount' }
  ];
  headers.forEach(h => {
    html += `<th data-sort="${h.field}">${h.label} ${sortField === h.field ? (sortDir === 'asc' ? '▲' : '▼') : ''}</th>`;
  });
  html += '</tr></thead><tbody>';

  pageData.forEach(r => {
    const timeStr = r.lastVisitTime ? new Date(r.lastVisitTime).toLocaleString() : '';
    const displayTitle = r.title || '';
    const titleHtml = displayTitle
      ? `<a href="${r.url}" target="_blank" title="${escapeHtml(r.url)}">${escapeHtml(displayTitle)}</a>`
      : `<a href="${r.url}" target="_blank" style="color:#999; font-style:italic;" title="${escapeHtml(r.url)}">${escapeHtml(r.url)}</a>`;

    let sourceBadge = '';
    if (r.source === 'local') sourceBadge = '<span style="background:#e8f0fe; padding:2px 6px; border-radius:4px; font-size:11px;">本地</span>';
    else if (r.source === 'remote') sourceBadge = '<span style="background:#fef7e0; padding:2px 6px; border-radius:4px; font-size:11px;">远程</span>';
    else sourceBadge = '<span style="background:#e6f4ea; padding:2px 6px; border-radius:4px; font-size:11px;">两者</span>';

    html += `<tr>
      <td>${sourceBadge}</td>
      <td>${timeStr}</td>
      <td class="url-col">${titleHtml}</td>
      <td>${r.visitCount}</td>
    </tr>`;
  });
  html += '</tbody></table>';

  const totalPages = Math.ceil(filteredRecords.length / PAGE_SIZE);
  html += '<div class="pagination">';
  html += `<button id="prevPage" ${currentPage === 0 ? 'disabled' : ''}>上一页</button>`;
  html += `<span>${currentPage + 1} / ${totalPages || 1}</span>`;
  html += `<button id="nextPage" ${currentPage >= totalPages - 1 ? 'disabled' : ''}>下一页</button>`;
  html += '</div>';

  tableContainer.innerHTML = html;
}

// ---------- 事件委托 ----------
tableContainer.addEventListener('click', (e) => {
  const th = e.target.closest('th[data-sort]');
  if (th) {
    const field = th.dataset.sort;
    if (sortField === field) {
      sortDir = sortDir === 'asc' ? 'desc' : 'asc';
    } else {
      sortField = field;
      sortDir = 'desc';
    }
    applyFilters();
    return;
  }
  if (e.target.id === 'prevPage') {
    if (currentPage > 0) {
      currentPage--;
      renderPage();
    }
  }
  if (e.target.id === 'nextPage') {
    const totalPages = Math.ceil(filteredRecords.length / PAGE_SIZE);
    if (currentPage < totalPages - 1) {
      currentPage++;
      renderPage();
    }
  }
});

// ---------- 导出 CSV（含来源）----------
function exportCSV() {
  if (filteredRecords.length === 0) {
    alert('没有数据可导出');
    return;
  }
  const csvContent = [
    '"来源","访问时间","标题","URL","访问次数"',
    ...filteredRecords.map(r =>
      `"${r.source}","${new Date(r.lastVisitTime).toLocaleString()}","${(r.title || '').replace(/"/g, '""')}","${r.url || ''}","${r.visitCount}"`
    )
  ].join('\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'history_backup_export.csv';
  a.click();
  URL.revokeObjectURL(url);
}

// ---------- 事件绑定 ----------
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(applyFilters, 300);
});

reloadBtn.addEventListener('click', () => loadBackup(true));
exportCSVBtn.addEventListener('click', exportCSV);
repairBtn.addEventListener('click', repairRemoteFile);

if (sourceSelect) {
  sourceSelect.addEventListener('change', () => {
    sourceFilter = sourceSelect.value;
    applyFilters();
  });
}

// 启动
loadBackup(false);