// 导入公共模块和同步模块
importScripts(
  'common.js',
  'webdav-client.js',
  'gist-client.js',
  'bookmarks-sync.js',
  'history-sync.js',
  'extensions-sync.js'
);

// ---------- 书签同步互斥标志 ----------
let isBookmarkSyncInProgress = false;

// ---------- 书签变化提醒 ----------
function setBookmarkChangeBadge() {
  chrome.action.setBadgeText({ text: '!' });
  chrome.action.setBadgeBackgroundColor({ color: '#FF5722' });
}

function clearBookmarkChangeBadge() {
  chrome.action.setBadgeText({ text: '' });
}

// ---------- 自动同步变量 ----------
let eventSyncTimer = null;  // 用于防抖

// 移除旧闹钟
async function clearBookmarksAutoAlarm() {
  await chrome.alarms.clear('bookmarksAutoSync');
}

// 设置闹钟（间隔 > 0 时使用）
async function setupBookmarksAutoAlarm(intervalMinutes) {
  await clearBookmarksAutoAlarm();
  if (intervalMinutes > 0) {
    chrome.alarms.create('bookmarksAutoSync', {
      periodInMinutes: intervalMinutes,
      delayInMinutes: 1
    });
    console.log(`[Background] 书签自动同步闹钟已设置，间隔 ${intervalMinutes} 分钟`);
  }
}

// 事件触发的自动同步（30秒防抖）
async function scheduleEventAutoSync() {
  if (eventSyncTimer) clearTimeout(eventSyncTimer);
  eventSyncTimer = setTimeout(async () => {
    if (isBookmarkSyncInProgress) return;
    
    const enabled = await self.Common.getStorage(self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC);
    if (!enabled) return;

    isBookmarkSyncInProgress = true;
    try {
      const result = await self.BookmarksSync.silentUploadBookmarks();
      if (result.success) {
        clearBookmarkChangeBadge();
      }
    } finally {
      isBookmarkSyncInProgress = false;
    }
  }, 30000); // 30秒防抖
}

// 重新配置书签自动同步（根据设置选择闹钟或事件触发）
async function configureBookmarksAutoSync() {
  const enabled = await self.Common.getStorage(self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC);
  const interval = (await self.Common.getStorage(self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC_INTERVAL)) ?? 5;

  // 清除旧闹钟
  await clearBookmarksAutoAlarm();

  if (!enabled) {
    // 禁用时清除任何待处理的定时器
    if (eventSyncTimer) clearTimeout(eventSyncTimer);
    return;
  }

  if (interval > 0) {
    // 启用闹钟模式
    await setupBookmarksAutoAlarm(interval);
    if (eventSyncTimer) clearTimeout(eventSyncTimer); // 停止事件触发
  } else {
    // 间隔为0：使用事件触发（30秒防抖），不设置闹钟
    console.log('[Background] 书签自动同步：事件触发模式（30秒防抖）');
    // 闹钟已清除，后续由 onBookmarkChange 调用 scheduleEventAutoSync
  }
}

// 监听书签变化：设置提醒，并根据配置调度自动同步
function onBookmarkChange() {
  if (isBookmarkSyncInProgress) return; // 同步过程中忽略自身变化

  setBookmarkChangeBadge();

  // 读取配置
  (async () => {
    const enabled = await self.Common.getStorage(self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC);
    if (!enabled) return;

    const interval = (await self.Common.getStorage(self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC_INTERVAL)) ?? 5;

    if (interval === 0) {
      // 事件触发模式，30秒防抖
      scheduleEventAutoSync();
    }
    // 若 interval > 0，由闹钟负责，此处不额外调度
  })();
}

chrome.bookmarks.onCreated.addListener(onBookmarkChange);
chrome.bookmarks.onRemoved.addListener(onBookmarkChange);
chrome.bookmarks.onChanged.addListener(onBookmarkChange);
chrome.bookmarks.onMoved.addListener(onBookmarkChange);
chrome.bookmarks.onChildrenReordered.addListener(onBookmarkChange);

// ---------- 历史自动同步闹钟（分钟）----------
async function setupHistoryAutoSyncAlarm() {
  const defaultSettings = { enabled: false, intervalMinutes: 60 };
  let settings = await self.Common.getSyncStorage(self.Common.STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS);
  if (settings && typeof settings.intervalHours === 'number') {
    settings.intervalMinutes = settings.intervalHours * 60;
    delete settings.intervalHours;
    await self.Common.setSyncStorage(self.Common.STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS, settings);
  }
  settings = settings || defaultSettings;
  
  await chrome.alarms.clear('historyAutoSync');
  if (settings.enabled && settings.intervalMinutes > 0) {
    chrome.alarms.create('historyAutoSync', {
      periodInMinutes: settings.intervalMinutes,   // 直接使用分钟
      delayInMinutes: 1
    });
    console.log(`[Background] 历史自动同步闹钟已设置，间隔 ${settings.intervalMinutes} 分钟`);
  }
}

async function initialize() {
  await self.ExtensionsSync.setupAlarm();
  await setupHistoryAutoSyncAlarm();
  await configureBookmarksAutoSync();
  console.log('[Background] 初始化完成');
}

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Background] 扩展安装/更新:', details.reason);
  await initialize();
  const extSettings = await self.Common.getSyncStorage(self.Common.STORAGE_KEYS.EXTENSIONS_SETTINGS);
  if (extSettings?.autoBackupEnabled) {
    self.ExtensionsSync.performAutoBackup();
  }
  const histSettings = await self.Common.getSyncStorage(self.Common.STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS) || {};
  if (histSettings.enabled) {
    self.HistorySync.silentIncrementalBackup();
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await initialize();
  const histSettings = await self.Common.getSyncStorage(self.Common.STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS) || {};
  if (histSettings.enabled) {
    self.HistorySync.silentIncrementalBackup();
  }
});

// 闹钟监听
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'extensionsAutoBackup') {
    self.ExtensionsSync.performAutoBackup();
  } else if (alarm.name === 'historyAutoSync') {
    self.HistorySync.silentIncrementalBackup();
  } else if (alarm.name === 'bookmarksAutoSync') {
    // 闹钟触发的书签自动同步
    if (!isBookmarkSyncInProgress) {
      isBookmarkSyncInProgress = true;
      self.BookmarksSync.silentUploadBookmarks().then(result => {
        if (result.success) clearBookmarkChangeBadge();
      }).finally(() => {
        isBookmarkSyncInProgress = false;
      });
    }
  }
});

// 存储变化监听
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync') {
    if (changes[self.Common.STORAGE_KEYS.EXTENSIONS_SETTINGS]) {
      self.ExtensionsSync.setupAlarm();
    }
    if (changes[self.Common.STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS]) {
      setupHistoryAutoSyncAlarm();
    }
  }
  // 书签自动同步设置变化时重新配置
  if (areaName === 'local') {
    if (changes[self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC] || changes[self.Common.STORAGE_KEYS.BOOKMARKS_AUTO_SYNC_INTERVAL]) {
      configureBookmarksAutoSync();
    }
  }
});

// ---------- 消息路由 ----------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { action } = message;

  // 书签同步（统一为双向同步）
  if (action === 'bookmarksUpload') {
    isBookmarkSyncInProgress = true;
    self.BookmarksSync.uploadBookmarks().then(result => {
      isBookmarkSyncInProgress = false;
      clearBookmarkChangeBadge();
      sendResponse(result);
    }).catch(err => {
      isBookmarkSyncInProgress = false;
      sendResponse({ success: false, message: err.message });
    });
    return true;
  }

  if (action === 'bookmarksDownload') {
    isBookmarkSyncInProgress = true;
    self.BookmarksSync.downloadBookmarks().then(result => {
      isBookmarkSyncInProgress = false;
      clearBookmarkChangeBadge();
      sendResponse(result);
    }).catch(err => {
      isBookmarkSyncInProgress = false;
      sendResponse({ success: false, message: err.message });
    });
    return true;
  }

  if (action === 'bookmarksClear') {
    isBookmarkSyncInProgress = true;
    self.BookmarksSync.clearAllBookmarks().then(result => {
      isBookmarkSyncInProgress = false;
      clearBookmarkChangeBadge();
      sendResponse(result);
    }).catch(err => {
      isBookmarkSyncInProgress = false;
      sendResponse({ success: false, message: err.message });
    });
    return true;
  }

  if (action === 'getBookmarkStats') {
    self.BookmarksSync.getStats().then(sendResponse);
    return true;
  }

  // 历史记录相关
  if (action === 'incrementalBackup') {
    self.HistorySync.incrementalBackup().then(sendResponse);
    return true;
  }
  if (action === 'fullDownload') {
    self.HistorySync.fullDownload().then(sendResponse);
    return true;
  }
  if (action === 'fullBackup') {
    self.HistorySync.fullBackup().then(sendResponse);
    return true;
  }

  // 扩展同步相关
  if (action === 'extensionsBackup') {
    self.ExtensionsSync.backup().then(sendResponse);
    return true;
  }
  if (action === 'extensionsRestore') {
    self.ExtensionsSync.restore().then(sendResponse);
    return true;
  }
  if (action === 'getExtensionsStats') {
    self.ExtensionsSync.getStats().then(sendResponse);
    return true;
  }
  if (action === 'performAutoBackup') {
    self.ExtensionsSync.performAutoBackup().then(() => sendResponse({ success: true }));
    return true;
  }
  if (action === 'getMissingExtensions') {
    self.ExtensionsSync.getMissingExtensions().then(sendResponse);
    return true;
  }
  if (action === 'clearBadge') {
    clearBookmarkChangeBadge();
    sendResponse({ success: true });
    return true;
  }

  return false;
});