// common.js - 公共工具函数和存储键常量
self.Common = (function() {
  const STORAGE_KEYS = {
    // WebDAV 通用配置（存储在 chrome.storage.local）
    WEBDAV_URL: 'webdav_url',
    WEBDAV_USER: 'webdav_user',
    WEBDAV_PASS: 'webdav_pass',

    // 历史记录专用（存储在 chrome.storage.local）
    LAST_SYNC_TIME: 'last_sync_time',
    HISTORY_BACKUP_FILE: 'history_backup.json',

    // 书签专用（存储在 chrome.storage.sync 和 chrome.storage.local）
    BOOKMARKS_SETTINGS: 'bookmarks_settings',   // sync: { remotePath, swapBookmarkMobile, lastSync }
    BOOKMARKS_META: 'bookmarksMeta',            // local: 元数据（GUID映射等）
    BOOKMARKS_SNAPSHOT: 'bookmarks_snapshot',   // local: 上次同步后的本地镜像（与远程格式相同）

    // 扩展同步专用（存储在 chrome.storage.sync）
    EXTENSIONS_SETTINGS: 'extensions_settings',

    // GitHub Gist 专用（存储在 chrome.storage.local）
    GIST_TOKEN: 'gist_token',
    GIST_ID: 'gist_id',
    GIST_FILENAME: 'gist_filename',
    BOOKMARKS_SYNC_BACKEND: 'bookmarks_sync_backend',

    // 同步进度（临时存储，用于 UI 反馈）
    SYNC_PROGRESS: 'sync_progress',

    // 书签自动同步开关（存储在 chrome.storage.local）
    BOOKMARKS_AUTO_SYNC: 'bookmarks_auto_sync',
    // 书签自动同步间隔（分钟，存储在 chrome.storage.local）
    BOOKMARKS_AUTO_SYNC_INTERVAL: 'bookmarks_auto_sync_interval',

    // 历史自动同步设置（存储在 chrome.storage.sync）{ enabled, intervalMinutes }
    HISTORY_AUTO_SYNC_SETTINGS: 'history_auto_sync_settings'
  };

  async function getStorage(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }

  async function setStorage(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  async function getSyncStorage(key) {
    const result = await chrome.storage.sync.get(key);
    return result[key];
  }

  async function setSyncStorage(key, value) {
    await chrome.storage.sync.set({ [key]: value });
  }

  function showNotification(title, message, type = 'basic') {
    chrome.notifications.create({
      type: type,
      iconUrl: 'icons/icon48.png',
      title: title,
      message: message,
      priority: 2
    }).catch(() => {});
  }

  return {
    STORAGE_KEYS,
    getStorage,
    setStorage,
    getSyncStorage,
    setSyncStorage,
    showNotification
  };
})();