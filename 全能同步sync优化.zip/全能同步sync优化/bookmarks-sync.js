// bookmarks-sync.js - 书签同步（支持文件夹位置同步）
self.BookmarksSync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, getSyncStorage, setSyncStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;
  const GistClient = self.GistClient;

  const DEFAULT_BOOKMARKS_SETTINGS = {
    remotePath: '/bookmarks.json',
    swapBookmarkMobile: false,
    lastSync: 0
  };

  const ROOT_GUIDS = {
    bookmarkBar: 'root-bookmarkBar',
    other: 'root-other',
    mobile: 'root-mobile'
  };
  const ROOT_GUID_TO_KEY = Object.fromEntries(
    Object.entries(ROOT_GUIDS).map(([k, v]) => [v, k])
  );

  const SPECIAL_FOLDERS = ['Readlist', 'TabGroup'];

  // ---------- 设置与后端 ----------
  async function getBookmarksSettings() {
    const settings = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS);
    return settings || DEFAULT_BOOKMARKS_SETTINGS;
  }
  async function getSyncBackend() {
    const backend = await getStorage(STORAGE_KEYS.BOOKMARKS_SYNC_BACKEND);
    return backend || 'webdav';
  }
  async function getBookmarksClient() {
    const backend = await getSyncBackend();
    if (backend === 'gist') {
      const token = await getStorage(STORAGE_KEYS.GIST_TOKEN);
      if (!token) throw new Error('请先在选项页配置 GitHub Token');
      return { type: 'gist', client: new GistClient(token) };
    } else {
      const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
      const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
      const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
      if (!url || !user || !pass) throw new Error('请先在选项页配置 WebDAV 参数');
      return { type: 'webdav', client: new WebDAVClient(url, user, pass) };
    }
  }
  async function fetchRemoteBookmarks() {
    const { type, client } = await getBookmarksClient();
    const settings = await getBookmarksSettings();
    let content;
    if (type === 'gist') {
      const gistId = await getStorage(STORAGE_KEYS.GIST_ID);
      const fileName = await getStorage(STORAGE_KEYS.GIST_FILENAME) || 'bookmarks.json';
      if (!gistId) throw new Error('请配置 Gist ID');
      content = await client.getFileContent(gistId, fileName);
    } else {
      content = await client.getFile(settings.remotePath);
    }
    if (!content) return null;
    return JSON.parse(content);
  }
  async function uploadRemoteBookmarks(data) {
    const { type, client } = await getBookmarksClient();
    const settings = await getBookmarksSettings();
    const jsonStr = JSON.stringify(data);
    if (type === 'gist') {
      const gistId = await getStorage(STORAGE_KEYS.GIST_ID);
      const fileName = await getStorage(STORAGE_KEYS.GIST_FILENAME) || 'bookmarks.json';
      if (!gistId) throw new Error('请配置 Gist ID');
      await client.updateFile(gistId, fileName, jsonStr);
    } else {
      await client.putFile(settings.remotePath, jsonStr);
    }
  }

  // ---------- 标准文件夹 ID（保留 Quetta 交换）----------
  async function getStandardFolderIds() {
    const children = await chrome.bookmarks.getChildren('0');
    const folders = { bookmarkBar: null, other: null, mobile: null };
    const tryGet = async (id) => { try { await chrome.bookmarks.get(id); return id; } catch { return null; } };
    folders.bookmarkBar = await tryGet('1');
    folders.other = await tryGet('2');
    folders.mobile = await tryGet('3');
    for (const node of children) {
      const t = (node.title || '').toLowerCase();
      if (!folders.bookmarkBar && (t.includes('bookmark bar') || t.includes('书签栏') || t.includes('桌面书签'))) {
        folders.bookmarkBar = node.id;
      } else if (!folders.other && (t.includes('other bookmarks') || t.includes('其他书签'))) {
        folders.other = node.id;
      } else if (!folders.mobile && (t.includes('mobile bookmarks') || t.includes('移动设备书签') || t.includes('移动书签'))) {
        folders.mobile = node.id;
      }
    }
    if (!folders.bookmarkBar && !folders.other && !folders.mobile && children.length === 1) {
      folders.other = children[0].id;
    }
    const settings = await getBookmarksSettings();
    if (settings.swapBookmarkMobile) {
      [folders.bookmarkBar, folders.mobile] = [folders.mobile, folders.bookmarkBar];
    }
    return folders;
  }

  // ---------- GUID / 元数据 ----------
  function generateGUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  }
  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) hash = ((hash << 5) - hash) + str.charCodeAt(i) | 0;
    return hash.toString(16);
  }
  function computeNodeHash(node) {
    let str = (node.title || '') + (node.url || '') + (node.index || 0);
    if (node.children) {
      for (const c of node.children) str += computeNodeHash(c);
    }
    return simpleHash(str);
  }
  async function getMeta() {
    const meta = await getStorage(STORAGE_KEYS.BOOKMARKS_META);
    return meta || { guidMap: {}, lastModified: {}, hash: {}, deleted: [] };
  }
  async function saveMeta(meta) {
    await setStorage(STORAGE_KEYS.BOOKMARKS_META, meta);
  }
  async function getOrCreateGUID(localId, meta) {
    if (!meta.guidMap[localId]) meta.guidMap[localId] = generateGUID();
    return meta.guidMap[localId];
  }
  function isSpecialFolder(node) {
    return node && !node.url && SPECIAL_FOLDERS.includes(node.title);
  }

  // ---------- 导出书签树（带 index）----------
  async function exportBookmarks() {
    const folders = await getStandardFolderIds();
    const meta = await getMeta();
    const tree = [];
    for (const key of ['bookmarkBar', 'other', 'mobile']) {
      const id = folders[key];
      if (!id) continue;
      try {
        const root = { guid: ROOT_GUIDS[key], id: key, children: [] };
        const childNodes = await chrome.bookmarks.getChildren(id);
        for (let i = 0; i < childNodes.length; i++) {
          root.children.push(await processNode(childNodes[i], meta, i));
        }
        tree.push(root);
      } catch (e) { console.error(`导出 ${key} 失败`, e); }
    }
    await saveMeta(meta);
    return { version: 5, timestamp: Date.now(), tree };
  }

  async function processNode(node, meta, index) {
    const guid = await getOrCreateGUID(node.id, meta);
    let children = null;
    if (!node.url) {
      const childNodes = await chrome.bookmarks.getChildren(node.id);
      if (childNodes && childNodes.length) {
        children = [];
        for (let i = 0; i < childNodes.length; i++) {
          children.push(await processNode(childNodes[i], meta, i));
        }
      }
    }
    const nodeForHash = { title: node.title, url: node.url || '', index, children };
    const hashNow = computeNodeHash(nodeForHash);
    let lastModified = meta.lastModified[guid];
    if (meta.hash[guid] !== hashNow || !lastModified) {
      lastModified = Date.now();
      meta.lastModified[guid] = lastModified;
      meta.hash[guid] = hashNow;
    }
    const obj = { guid, title: node.title, url: node.url || undefined, lastModified, index };
    if (children) obj.children = children;
    return obj;
  }

  // ---------- 三方合并（含 index）----------
  function mergeTrees(base, local, remote) {
    if (!local && !remote) return base ? base.map(n => ({ ...n })) : [];
    function index(nodes) {
      const map = new Map();
      for (const n of (nodes || [])) map.set(n.guid, n);
      return map;
    }
    const baseIdx = index(base);
    const localIdx = index(local);
    const remoteIdx = index(remote);
    const allGuids = new Set([...baseIdx.keys(), ...localIdx.keys(), ...remoteIdx.keys()]);
    const merged = [];

    for (const guid of allGuids) {
      const b = baseIdx.get(guid);
      const l = localIdx.get(guid);
      const r = remoteIdx.get(guid);

      if (!l && !r) continue;
      if (!l && r) {
        if (b) {
          if (r.lastModified === b.lastModified && r.title === b.title && r.url === b.url && r.index === b.index) continue;
          else merged.push({ ...r });
        } else merged.push({ ...r });
        continue;
      }
      if (l && !r) {
        if (b) {
          if (l.lastModified === b.lastModified && l.title === b.title && l.url === b.url && l.index === b.index) continue;
          else merged.push({ ...l });
        } else merged.push({ ...l });
        continue;
      }

      const mergedNode = {
        guid,
        id: l.id || r.id || ROOT_GUID_TO_KEY[guid] || undefined,
        title: l.title,
        url: l.url,
        lastModified: l.lastModified,
        index: l.index
      };
      if (r.lastModified > l.lastModified) {
        mergedNode.title = r.title;
        mergedNode.url = r.url;
        mergedNode.lastModified = r.lastModified;
        mergedNode.index = r.index;
        if (r.id) mergedNode.id = r.id;
      }
      const mergedChildren = mergeTrees(
        b ? b.children : undefined,
        l ? l.children : undefined,
        r ? r.children : undefined
      );
      if (mergedChildren.length > 0) mergedNode.children = mergedChildren;
      merged.push(mergedNode);
    }
    merged.sort((a, b) => (a.index || 0) - (b.index || 0));
    return merged;
  }

  function treesEqual(a, b) {
    if (a.length !== b.length) return false;
    const map = new Map();
    for (const n of a) map.set(n.guid, n);
    for (const n of b) {
      const other = map.get(n.guid);
      if (!other || n.title !== other.title || n.url !== other.url || n.lastModified !== other.lastModified || n.index !== other.index) return false;
      if (!treesEqual(n.children || [], other.children || [])) return false;
    }
    return true;
  }

  // ---------- 应用树到本地（保证顺序）----------
  async function applyTreeToLocal(tree) {
    const folders = await getStandardFolderIds();
    const meta = await getMeta();
    const validGuids = new Set();
    function collectGuids(nodes) {
      for (const n of nodes) {
        validGuids.add(n.guid);
        if (n.children) collectGuids(n.children);
      }
    }
    collectGuids(tree);

    // 清空根下的非特殊文件夹 + 特殊文件夹内部
    for (const key of ['bookmarkBar', 'other', 'mobile']) {
      const rootId = folders[key];
      if (!rootId) continue;
      try {
        const children = await chrome.bookmarks.getChildren(rootId);
        for (const child of children) {
          if (isSpecialFolder(child)) {
            const subChildren = await chrome.bookmarks.getChildren(child.id);
            for (const sub of subChildren) await chrome.bookmarks.removeTree(sub.id);
          } else {
            await chrome.bookmarks.removeTree(child.id);
          }
        }
      } catch (e) { console.warn(`清空 ${key} 失败:`, e); }
    }

    const guidToIdMap = new Map();

    // 重建
    for (const root of tree) {
      const key = root.id || ROOT_GUID_TO_KEY[root.guid];
      if (!key) continue;
      const rootId = folders[key];
      if (!rootId) continue;
      const sorted = (root.children || []).slice().sort((a, b) => (a.index || 0) - (b.index || 0));
      for (const child of sorted) {
        await createOrUpdateChild(child, rootId, meta, guidToIdMap);
      }
    }

    // 修正所有节点的直接子节点顺序
    await fixChildrenOrder(guidToIdMap, tree);

    // 清理 GUID 映射
    const newGuidMap = {};
    for (const [id, guid] of Object.entries(meta.guidMap)) {
      if (validGuids.has(guid)) newGuidMap[id] = guid;
    }
    meta.guidMap = newGuidMap;
    await saveMeta(meta);
  }

  async function fixChildrenOrder(guidToIdMap, nodes) {
    for (const node of nodes) {
      const localId = guidToIdMap.get(node.guid);
      if (!localId) continue;
      const children = await chrome.bookmarks.getChildren(localId);
      const expectedOrder = [];
      if (node.children) {
        for (const child of node.children) {
          const childId = guidToIdMap.get(child.guid);
          if (childId) expectedOrder.push(childId);
        }
      }
      if (expectedOrder.length > 0) {
        for (let i = 0; i < expectedOrder.length; i++) {
          const currentChild = children.find(c => c.id === expectedOrder[i]);
          if (currentChild && currentChild.index !== i) {
            await chrome.bookmarks.move(expectedOrder[i], { index: i });
          }
        }
      }
      if (node.children && node.children.length > 0) {
        await fixChildrenOrder(guidToIdMap, node.children);
      }
    }
  }

  async function createOrUpdateChild(node, parentId, meta, guidToIdMap) {
    if (isSpecialFolder(node)) {
      const siblings = await chrome.bookmarks.getChildren(parentId);
      const existing = siblings.find(s => !s.url && s.title === node.title);
      if (existing) {
        const subChildren = await chrome.bookmarks.getChildren(existing.id);
        for (const sub of subChildren) await chrome.bookmarks.removeTree(sub.id);
        const sorted = (node.children || []).slice().sort((a, b) => (a.index || 0) - (b.index || 0));
        for (const sub of sorted) {
          await createTreeRecursive(sub, existing.id, meta, guidToIdMap);
        }
        if (meta && node.guid) {
          meta.guidMap[existing.id] = node.guid;
          meta.lastModified[node.guid] = node.lastModified || Date.now();
          guidToIdMap.set(node.guid, existing.id);
        }
      } else {
        const created = await chrome.bookmarks.create({ parentId, title: node.title });
        if (meta && node.guid) {
          meta.guidMap[created.id] = node.guid;
          meta.lastModified[node.guid] = node.lastModified || Date.now();
          guidToIdMap.set(node.guid, created.id);
        }
        const sorted = (node.children || []).slice().sort((a, b) => (a.index || 0) - (b.index || 0));
        for (const sub of sorted) {
          await createTreeRecursive(sub, created.id, meta, guidToIdMap);
        }
      }
    } else {
      await createTreeRecursive(node, parentId, meta, guidToIdMap);
    }
  }

  async function createTreeRecursive(node, parentId, meta, guidToIdMap) {
    if (!node || typeof node !== 'object') return;
    const title = node.title || '未命名';
    const url = node.url;
    let newId;
    if (url) {
      const created = await chrome.bookmarks.create({ parentId, title, url });
      newId = created.id;
    } else {
      const created = await chrome.bookmarks.create({ parentId, title });
      newId = created.id;
      const sorted = (node.children || []).slice().sort((a, b) => (a.index || 0) - (b.index || 0));
      for (const child of sorted) {
        await createTreeRecursive(child, newId, meta, guidToIdMap);
      }
    }
    if (meta && node.guid) {
      meta.guidMap[newId] = node.guid;
      meta.lastModified[node.guid] = node.lastModified || Date.now();
      guidToIdMap.set(node.guid, newId);
    }
  }

  // ---------- 核心同步 ----------
  async function syncBookmarks(silent = false) {
    try {
      const localData = await exportBookmarks();
      const localTree = localData.tree;

      const snapshot = await getStorage(STORAGE_KEYS.BOOKMARKS_SNAPSHOT);
      const snapshotTree = snapshot ? snapshot.tree : null;

      let remoteData;
      try { remoteData = await fetchRemoteBookmarks(); } catch (e) {
        if (!silent) throw e;
        else console.warn('[BookmarksSync] 远程获取失败', e);
      }
      let remoteTree = remoteData ? remoteData.tree : null;

      if (!snapshotTree) {
        let targetTree = remoteTree ? remoteTree : localTree;
        targetTree = targetTree.map(root => ({
          guid: root.guid,
          id: root.id || ROOT_GUID_TO_KEY[root.guid],
          children: root.children || []
        }));
        await applyTreeToLocal(targetTree);
        await uploadRemoteBookmarks({ version: 5, timestamp: Date.now(), tree: targetTree });
        await setStorage(STORAGE_KEYS.BOOKMARKS_SNAPSHOT, { version: 5, tree: targetTree });
        await updateLastSyncTime();
        if (!silent) showNotification('书签同步', '首次同步完成');
        return { success: true, message: '首次同步完成' };
      }

      const mergedTree = mergeTrees(snapshotTree, localTree, remoteTree || snapshotTree);
      const cleanTree = mergedTree.map(root => ({
        guid: root.guid,
        id: root.id || ROOT_GUID_TO_KEY[root.guid],
        children: root.children || []
      }));

      if (!treesEqual(cleanTree, localTree)) {
        await applyTreeToLocal(cleanTree);
      }

      await uploadRemoteBookmarks({ version: 5, timestamp: Date.now(), tree: cleanTree });
      await setStorage(STORAGE_KEYS.BOOKMARKS_SNAPSHOT, { version: 5, tree: cleanTree });
      await updateLastSyncTime();

      const msg = treesEqual(cleanTree, localTree) ? '已同步，无变化' : '已双向同步，本地已更新';
      if (!silent) showNotification('书签同步', msg);
      return { success: true, message: msg };
    } catch (err) {
      if (!silent) showNotification('书签同步失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function updateLastSyncTime() {
    const settings = await getBookmarksSettings();
    await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, { ...settings, lastSync: Date.now() });
  }

  // ---------- 公开接口 ----------
  async function uploadBookmarks() { return syncBookmarks(false); }
  async function downloadBookmarks() { return syncBookmarks(false); }
  async function silentUploadBookmarks() { return syncBookmarks(true); }

  async function clearAllBookmarks() {
    try {
      const folders = await getStandardFolderIds();
      for (const key of ['bookmarkBar', 'other', 'mobile']) {
        const id = folders[key];
        if (id) {
          const children = await chrome.bookmarks.getChildren(id);
          for (const c of children) await chrome.bookmarks.removeTree(c.id);
        }
      }
      await setStorage(STORAGE_KEYS.BOOKMARKS_META, null);
      await setStorage(STORAGE_KEYS.BOOKMARKS_SNAPSHOT, null);
      const settings = await getBookmarksSettings();
      await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, { ...settings, lastSync: 0 });
      showNotification('书签清空', '本地书签已清空');
      return { success: true, message: '清空成功' };
    } catch (err) {
      showNotification('清空失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function getStats() {
    async function countNodes(tree) {
      let c = 0;
      for (const n of tree) {
        if (n.url) c++;
        if (n.children) c += await countNodes(n.children);
      }
      return c;
    }
    const localData = await exportBookmarks();
    const local = await countNodes(localData.tree);
    let remote = null;
    try {
      const rd = await fetchRemoteBookmarks();
      if (rd) remote = await countNodes(rd.tree);
    } catch (e) {}
    return { local, remote };
  }

  return {
    uploadBookmarks,
    downloadBookmarks,
    silentUploadBookmarks,
    clearAllBookmarks,
    getStats
  };
})();