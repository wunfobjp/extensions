// history-sync.js - 历史记录同步（高性能优化版 + 进度反馈 + 静默上传）
self.HistorySync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  let progressCallback = null;

  function setProgressCallback(cb) {
    progressCallback = cb;
  }

  let lastProgressWrite = 0;
  async function updateProgress(phase, current, total, message) {
    const now = Date.now();
    if (now - lastProgressWrite < 200 && phase !== 'done' && phase !== 'error') return;
    lastProgressWrite = now;
    const progress = { phase, current, total, message, timestamp: now };
    await chrome.storage.local.set({ sync_progress: progress });
    if (progressCallback) progressCallback(progress);
  }

  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) throw new Error('请先在设置中配置 WebDAV 参数');
    return new WebDAVClient(url, user, pass);
  }

  async function getRemoteBackup(client) {
    const content = await client.getFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`);
    if (!content) return [];

    try {
      const data = JSON.parse(content);
      if (Array.isArray(data) && data.length && Array.isArray(data[0])) {
        return data.map(r => ({
          url: r[0],
          title: r[1] || '',
          lastVisitTime: r[2],
          visitCount: r[3] || 1
        }));
      }
      return Array.isArray(data) ? data : [];
    } catch (e) {
      console.error('解析远程备份失败:', e);
      return [];
    }
  }

  async function putRemoteBackup(client, records) {
    if (!records || records.length === 0) {
      console.warn('[HistorySync] 拦截空数据上传，跳过写入');
      return;
    }
    const compressed = records.map(r => [
      r.url,
      r.title || '',
      r.lastVisitTime,
      r.visitCount || 1
    ]);
    const jsonStr = JSON.stringify(compressed);
    return await client.putFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`, jsonStr);
  }

  async function getHistorySince(startTime) {
    const allItems = [];
    let currentStart = startTime || 0;
    let hasMore = true;
    const MAX_RESULTS_PER_PAGE = 10000;
    let iteration = 0;
    const MAX_ITERATIONS = 100;

    while (hasMore && iteration++ < MAX_ITERATIONS) {
      const results = await new Promise((resolve) => {
        chrome.history.search({
          text: '',
          startTime: currentStart,
          endTime: Date.now(),
          maxResults: MAX_RESULTS_PER_PAGE,
        }, resolve);
      });

      if (results.length === 0) break;

      const items = results.map(item => ({
        url: item.url,
        title: item.title || '',
        lastVisitTime: item.lastVisitTime,
        visitCount: item.visitCount
      }));
      allItems.push(...items);

      if (results.length === MAX_RESULTS_PER_PAGE) {
        const lastTime = results[results.length - 1].lastVisitTime;
        if (lastTime <= currentStart) {
          hasMore = false;
        } else {
          currentStart = lastTime + 1;
        }
      } else {
        hasMore = false;
      }
    }

    const uniqueMap = new Map();
    for (const item of allItems) {
      const key = `${item.url}|${item.lastVisitTime}`;
      const existing = uniqueMap.get(key);
      if (!existing || item.visitCount > existing.visitCount) {
        uniqueMap.set(key, item);
      }
    }
    return Array.from(uniqueMap.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
  }

  function mergeHistoryRecords(existing, incoming) {
    const map = new Map();
    existing.forEach(rec => map.set(`${rec.url}|${rec.lastVisitTime}`, rec));
    incoming.forEach(rec => {
      const key = `${rec.url}|${rec.lastVisitTime}`;
      if (map.has(key)) {
        const old = map.get(key);
        old.visitCount = Math.max(old.visitCount, rec.visitCount);
        if (rec.title && rec.title !== old.title) {
          old.title = rec.title;
        }
      } else {
        map.set(key, rec);
      }
    });
    return Array.from(map.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
  }

  async function addHistoryWithLimit(records, concurrency = 8, maxRetries = 2) {
    let addedCount = 0;
    const failedUrls = [];
    let index = 0;
    const total = records.length;

    async function worker() {
      while (index < total) {
        const i = index++;
        const record = records[i];
        if (!record || !record.url || !record.url.startsWith('http')) continue;

        let success = false;
        for (let retry = 0; retry <= maxRetries; retry++) {
          try {
            await new Promise((resolve, reject) => {
              chrome.history.addUrl({ url: record.url }, () => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve();
              });
            });
            addedCount++;
            success = true;
            break;
          } catch (err) {
            if (retry === maxRetries) failedUrls.push(record.url);
            await new Promise(r => setTimeout(r, 100 * (retry + 1)));
          }
        }
        if (i % 500 === 0 || i === total - 1) {
          await updateProgress('downloading', i + 1, total, `已导入 ${addedCount} 条`);
        }
      }
    }

    const workers = Array(concurrency).fill().map(() => worker());
    await Promise.all(workers);
    return { addedCount, failedUrls };
  }

  // ---------- 公开 API ----------

  // 手动增量备份（带通知）
  async function incrementalBackup() {
    await updateProgress('uploading', 0, 1, '正在获取本地新增记录...');
    try {
      const lastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      const newHistory = await getHistorySince(lastSync);

      if (newHistory.length === 0) {
        showNotification('合并上传', '本地无新增记录');
        await updateProgress('done', 1, 1, '无新增记录');
        return { success: true, message: '无新增记录' };
      }

      await updateProgress('uploading', 1, 3, '正在获取云端备份...');
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);

      await updateProgress('uploading', 2, 3, '正在合并数据...');
      const merged = mergeHistoryRecords(remoteRecords, newHistory);

      await updateProgress('uploading', 3, 3, '正在上传合并后的备份...');
      await putRemoteBackup(client, merged);

      const maxTime = Math.max(...newHistory.map(r => r.lastVisitTime));
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);

      showNotification('合并上传完成', `新增 ${newHistory.length} 条，云端总计 ${merged.length} 条`);
      await updateProgress('done', 1, 1, `完成，新增 ${newHistory.length} 条`);
      return { success: true, message: `已合并上传 ${newHistory.length} 条` };
    } catch (err) {
      showNotification('合并上传失败', err.message);
      await updateProgress('error', 0, 1, err.message);
      return { success: false, message: err.message };
    }
  }

  // 静默增量备份（用于自动同步，不弹系统通知）
  async function silentIncrementalBackup() {
    try {
      const lastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      const newHistory = await getHistorySince(lastSync);

      if (newHistory.length === 0) {
        console.log('[HistorySync] 自动同步：无新增记录');
        return { success: true, message: '无新增记录' };
      }

      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);
      const merged = mergeHistoryRecords(remoteRecords, newHistory);
      await putRemoteBackup(client, merged);

      const maxTime = Math.max(...newHistory.map(r => r.lastVisitTime));
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);

      console.log(`[HistorySync] 自动同步完成，新增 ${newHistory.length} 条，云端总计 ${merged.length} 条`);
      return { success: true, message: `自动同步 ${newHistory.length} 条` };
    } catch (err) {
      console.error('[HistorySync] 自动同步失败:', err);
      return { success: false, message: err.message };
    }
  }

  async function fullDownload() {
    await updateProgress('downloading', 0, 2, '正在下载云端备份...');
    try {
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);

      if (remoteRecords.length === 0) {
        showNotification('全量下载', '远程无数据');
        await updateProgress('done', 1, 1, '远程无数据');
        return { success: false, message: '无远程数据' };
      }

      await updateProgress('downloading', 1, 2, `正在导入 ${remoteRecords.length} 条记录...`);
      const { addedCount, failedUrls } = await addHistoryWithLimit(remoteRecords, 8, 2);

      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, Date.now());
      const msg = `成功导入 ${addedCount} 条，失败 ${failedUrls.length} 条。⚠️ 注意：导入的历史时间将重置为“现在”。`;
      showNotification('全量下载完成', msg);
      await updateProgress('done', 1, 1, msg);
      return { success: true, message: msg, failedUrls };
    } catch (err) {
      showNotification('全量下载失败', err.message);
      await updateProgress('error', 0, 1, err.message);
      return { success: false, message: err.message };
    }
  }

  async function fullBackup() {
    await updateProgress('uploading', 0, 2, '正在收集全部历史记录...');
    try {
      const allHistory = await getHistorySince(0);
      const totalCount = allHistory.length;

      if (totalCount > 40000) {
        showNotification('全量上传', `正在备份 ${totalCount} 条，请勿关闭浏览器`);
      }

      await updateProgress('uploading', 1, 2, `正在上传 ${totalCount} 条记录...`);
      const client = await getWebDAVClient();
      await putRemoteBackup(client, allHistory);

      const maxTime = allHistory.length > 0
        ? Math.max(...allHistory.map(r => r.lastVisitTime))
        : Date.now();
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);

      showNotification('全量上传完成', `已备份全部 ${totalCount} 条历史`);
      await updateProgress('done', 1, 1, `完成，共 ${totalCount} 条`);
      return { success: true, message: `全量上传 ${totalCount} 条` };
    } catch (err) {
      showNotification('全量上传失败', err.message);
      await updateProgress('error', 0, 1, err.message);
      return { success: false, message: err.message };
    }
  }

  return {
    incrementalBackup,
    silentIncrementalBackup,     // 新增：静默增量备份
    fullDownload,
    fullBackup,
    setProgressCallback
  };
})();