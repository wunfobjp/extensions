// ========== 全局依赖 ==========
const { STORAGE_KEYS, getStorage, showNotification } = self.Common;
const WebDAVClient = self.WebDAVClient;

// ========== 历史搜索器模块 ==========
const HistorySearch = (function() {
  const BATCH_SIZE = 500;
  const MAX_TOTAL = 10000;

  let mode = 'current';
  let currentDomain = '';
  let allItems = [];
  let oldestTime = 0;
  let isLoading = false;
  let hasMore = true;

  const tabCurrent = document.getElementById('histTabCurrent');
  const tabAll = document.getElementById('histTabAll');
  const searchInput = document.getElementById('historySearchInput');
  const resultsList = document.getElementById('historyResults');
  const emptyMsg = document.getElementById('historyEmpty');
  const loadMoreBtn = document.getElementById('historyLoadMore');

  function getDomain(url) { try { return new URL(url).hostname; } catch { return ''; } }
  function getFavicon(url) { const domain = getDomain(url); return domain ? `https://www.google.com/s2/favicons?domain=${domain}&sz=16` : ''; }
  function filterItems(items, query) {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(item => (item.title && item.title.toLowerCase().includes(q)) || (item.url && item.url.toLowerCase().includes(q)));
  }
  function domainFilter(items) {
    if (mode === 'current' && currentDomain) return items.filter(item => getDomain(item.url) === currentDomain);
    return items;
  }

  function render(items) {
    resultsList.innerHTML = '';
    if (items.length === 0) { emptyMsg.classList.add('visible'); return; }
    emptyMsg.classList.remove('visible');
    items.forEach(item => {
      const li = document.createElement('li');
      const favicon = document.createElement('img');
      favicon.className = 'favicon';
      favicon.src = getFavicon(item.url);
      favicon.onerror = () => { favicon.style.display = 'none'; };
      const textWrapper = document.createElement('div');
      textWrapper.className = 'text-wrapper';
      const link = document.createElement('a');
      link.href = item.url;
      link.textContent = item.title || item.url;
      link.target = '_blank';
      const timeSpan = document.createElement('span');
      timeSpan.className = 'time';
      timeSpan.textContent = new Date(item.lastVisitTime).toLocaleString();
      textWrapper.appendChild(link);
      textWrapper.appendChild(timeSpan);
      li.appendChild(favicon);
      li.appendChild(textWrapper);
      resultsList.appendChild(li);
    });
  }

  function updateLoadMoreButton() {
    if (!hasMore || allItems.length >= MAX_TOTAL || allItems.length === 0) {
      loadMoreBtn.style.display = 'none';
    } else {
      loadMoreBtn.style.display = 'inline-flex';
    }
    const btnText = loadMoreBtn.querySelector('.btn-text');
    const spinner = loadMoreBtn.querySelector('.spinner');
    if (isLoading) {
      btnText.textContent = '加载中…';
      spinner.style.display = 'inline-block';
      loadMoreBtn.disabled = true;
    } else {
      btnText.textContent = '加载更早记录';
      spinner.style.display = 'none';
      loadMoreBtn.disabled = false;
    }
  }

  async function fetchBatch(startTime, endTime, textFilter = '') {
    const query = { text: textFilter, startTime, endTime, maxResults: BATCH_SIZE };
    try { return await chrome.history.search(query); }
    catch (e) { console.error('搜索历史失败:', e); return []; }
  }

  async function loadInitial() {
    if (mode === 'current') {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        currentDomain = tab?.url ? getDomain(tab.url) : '';
      } catch { currentDomain = ''; }
    } else currentDomain = '';
    allItems = []; oldestTime = 0; hasMore = true; isLoading = false;
    const endTime = Date.now();
    const textFilter = (mode === 'current' && currentDomain) ? currentDomain : '';
    isLoading = true; updateUI();
    const batch = await fetchBatch(0, endTime, textFilter);
    isLoading = false;
    if (batch.length) {
      allItems = batch;
      oldestTime = Math.min(...batch.map(i => i.lastVisitTime));
      hasMore = batch.length >= BATCH_SIZE;
    } else hasMore = false;
    updateUI();
  }

  async function loadMore() {
    if (isLoading || !hasMore || allItems.length === 0) return;
    isLoading = true; updateUI();
    const textFilter = (mode === 'current' && currentDomain) ? currentDomain : '';
    const nextEnd = oldestTime - 1;
    const batch = await fetchBatch(0, nextEnd, textFilter);
    isLoading = false;
    if (batch.length) {
      allItems = allItems.concat(batch);
      oldestTime = Math.min(...batch.map(i => i.lastVisitTime));
      hasMore = batch.length >= BATCH_SIZE && allItems.length < MAX_TOTAL;
    } else hasMore = false;
    updateUI();
  }

  function updateUI() {
    const base = domainFilter(allItems);
    const displayed = filterItems(base, searchInput.value);
    render(displayed);
    updateLoadMoreButton();
  }

  async function switchMode(newMode) {
    if (mode === newMode) return;
    mode = newMode;
    tabCurrent.classList.toggle('active', mode === 'current');
    tabAll.classList.toggle('active', mode === 'all');
    await loadInitial();
  }

  tabCurrent.addEventListener('click', () => switchMode('current'));
  tabAll.addEventListener('click', () => switchMode('all'));
  searchInput.addEventListener('input', updateUI);
  loadMoreBtn.addEventListener('click', loadMore);

  async function init() { await switchMode('current'); }
  return { init };
})();

// ========== 同步 & 书签模块 ==========
let syncStatusDiv, bookmarkLocalSpan, bookmarkRemoteSpan, progressArea, progressBar, progressMessage, progressInterval;

function startProgressMonitoring() {
  progressArea.style.display = 'block';
  if (progressInterval) clearInterval(progressInterval);
  progressInterval = setInterval(async () => {
    const result = await chrome.storage.local.get('sync_progress');
    const prog = result.sync_progress;
    if (prog) {
      const percent = prog.total > 0 ? (prog.current / prog.total) * 100 : 0;
      progressBar.style.width = `${percent}%`;
      progressMessage.textContent = prog.message || `${prog.phase} ${prog.current}/${prog.total}`;
      if (prog.phase === 'done' || prog.phase === 'error') {
        clearInterval(progressInterval);
        setTimeout(() => { progressArea.style.display = 'none'; progressBar.style.width = '0%'; chrome.storage.local.remove('sync_progress'); }, 2000);
      }
    }
  }, 500);
}

async function sendMessage(action, loadingText) {
  if (!chrome.runtime?.id) { setStatus(syncStatusDiv, '扩展上下文失效，请重新打开', true); return { success: false }; }
  setStatus(syncStatusDiv, loadingText);
  startProgressMonitoring();
  try {
    const result = await chrome.runtime.sendMessage({ action });
    setStatus(syncStatusDiv, result.message, !result.success);
    return result;
  } catch (err) {
    setStatus(syncStatusDiv, '操作失败: ' + err.message, true);
    return { success: false, message: err.message };
  }
}

async function refreshBookmarkStats() {
  try {
    const stats = await chrome.runtime.sendMessage({ action: 'getBookmarkStats' });
    bookmarkLocalSpan.textContent = stats.local ?? '?';
    bookmarkRemoteSpan.textContent = stats.remote ?? '?';
  } catch { bookmarkLocalSpan.textContent = '?'; bookmarkRemoteSpan.textContent = '?'; }
}

// ========== 扩展管理模块 ==========
let extTotalSpan, extEnabledSpan, extDisabledSpan, extBackupTimeSpan, extGrid, extSearch, extStatusDiv;
let currentExtensions = [], missingExtensions = [];

async function loadExtensions() {
  try {
    const exts = await chrome.management.getAll();
    currentExtensions = exts.filter(ext => ext.type === 'extension');
    applyExtFilter(); updateMissingAfterInstall();
  } catch (err) { setStatus(extStatusDiv, '加载扩展失败: ' + err.message, true); extGrid.innerHTML = '<div>加载失败</div>'; }
}

function updateMissingAfterInstall() {
  if (!missingExtensions.length) return;
  const installedIds = new Set(currentExtensions.map(e => e.id));
  missingExtensions = missingExtensions.filter(e => !installedIds.has(e.id));
  renderMissingExtensions();
}

function applyExtFilter() {
  const term = extSearch.value.trim().toLowerCase();
  const filtered = currentExtensions.filter(e => e.name.toLowerCase().includes(term));
  renderExtGrid(filtered); updateExtStats();
}

function renderExtGrid(extensions) {
  if (!extensions.length) { extGrid.innerHTML = '<div style="text-align:center; padding:20px;">未找到扩展</div>'; return; }
  let html = '';
  for (const ext of extensions) {
    const enabled = ext.enabled, name = escapeHtml(ext.name), version = ext.version || '?', extId = ext.id, hasOptions = !!ext.optionsUrl;
    const storeUrl = `https://chrome.google.com/webstore/detail/${extId}`;
    html += `
      <div class="ext-card">
        <div class="ext-name">
          <span title="${name} (${extId})">${name}</span>
          <label class="toggle-switch">
            <input type="checkbox" class="ext-toggle" data-id="${extId}" ${enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="ext-version">v${version}</div>
        <div class="ext-controls">
          <div>
            ${hasOptions ? `<button class="ext-options-btn" data-optionsurl="${escapeHtml(ext.optionsUrl)}">⚙️ 选项</button>` : ''}
            <button class="ext-store-btn" data-storeurl="${storeUrl}">🛒 商店</button>
          </div>
          <span style="font-size:11px;">${enabled ? '●启用' : '○禁用'}</span>
        </div>
      </div>`;
  }
  extGrid.innerHTML = html;

  document.querySelectorAll('.ext-toggle').forEach(toggle => {
    toggle.addEventListener('change', async (e) => {
      e.stopPropagation();
      const id = toggle.dataset.id, newState = toggle.checked;
      try {
        await chrome.management.setEnabled(id, newState);
        const ext = currentExtensions.find(e => e.id === id);
        if (ext) ext.enabled = newState;
        applyExtFilter();
      } catch (err) { setStatus(extStatusDiv, `失败: ${err.message}`, true); toggle.checked = !newState; }
    });
  });
  document.querySelectorAll('.ext-options-btn').forEach(btn => { btn.addEventListener('click', () => chrome.tabs.create({ url: btn.dataset.optionsurl })); });
  document.querySelectorAll('.ext-store-btn').forEach(btn => { btn.addEventListener('click', () => chrome.tabs.create({ url: btn.dataset.storeurl })); });
}

function updateExtStats() {
  const total = currentExtensions.length, enabled = currentExtensions.filter(e => e.enabled).length;
  extTotalSpan.textContent = total; extEnabledSpan.textContent = enabled; extDisabledSpan.textContent = total - enabled;
}

function renderMissingExtensions() {
  if (!missingExtensions.length) { extStatusDiv.textContent = '所有扩展状态已同步'; return; }
  const items = missingExtensions.map(e => `<a href="https://chrome.google.com/webstore/detail/${e.id}" target="_blank">${escapeHtml(e.name)}</a>`).join(', ');
  extStatusDiv.innerHTML = `⚠️ 缺失 ${missingExtensions.length} 个扩展：${items}`;
}

async function refreshExtensionsBackupInfo() {
  try {
    const stats = await chrome.runtime.sendMessage({ action: 'getExtensionsStats' });
    extBackupTimeSpan.textContent = stats.lastBackupTime ? `上次备份: ${new Date(stats.lastBackupTime).toLocaleString()}` : '暂无备份';
  } catch { extBackupTimeSpan.textContent = ''; }
}

// ========== 稍后阅读模块 ==========
let listEl, searchInput, saveBtn, archiveBtn, sharePageBtn, shareGroupBtn, configBtn, settingsSection;
let readFolderSelect, archiveFolderSelect, saveSettingsBtn, viewReadBtn, viewArchiveBtn, viewSharedBtn;
let navBar, backBtn, currentPathSpan, readingStatusDiv;
let currentReadingMode = 'read', readFolderId = null, archiveFolderId = null, currentFolderId = null, folderStack = [], isSearchMode = false;
const DEFAULT_READ_FOLDER = 'Readlist', DEFAULT_ARCHIVE_FOLDER = 'TabGroup';
let sharedItemsCache = [], webdavConfig = { url: '', username: '', password: '' }, sharedFileName = 'shared_links.json';

function getCleanTitle(title) { return title.replace(/^[🔵⚪]\s*/, ''); }
function isUnread(title) { return title.startsWith('🔵'); }
function getRootFolderId() { return currentReadingMode === 'read' ? readFolderId : archiveFolderId; }
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
}

// ===== 书签路径工具 =====
async function findFolderByPath(path) {
  if (!path) return null;
  const parts = path.split('/').map(p => p.trim());
  const tree = await chrome.bookmarks.getTree();
  async function search(nodes, depth) {
    for (const node of nodes) {
      if (node.title === parts[depth]) {
        if (depth === parts.length - 1) return node.id;
        if (node.children) {
          const found = await search(node.children, depth + 1);
          if (found) return found;
        }
      }
    }
    return null;
  }
  return search(tree, 0);
}

async function getFolderPathById(folderId) {
  const parts = [];
  let cur = folderId;
  while (cur && cur !== '0') {
    const nodes = await chrome.bookmarks.get(cur);
    if (!nodes || !nodes.length) break;
    parts.unshift(nodes[0].title);
    cur = nodes[0].parentId;
  }
  return parts.join('/');
}

async function findFolderByName(name) {
  const tree = await chrome.bookmarks.getTree();
  const bar = tree[0].children.find(c => c.id === '1' || c.title === '书签栏');
  if (!bar) return null;
  async function search(node) {
    if (node.title === name && !node.url) return node.id;
    if (node.children) for (const child of node.children) { const r = await search(child); if (r) return r; }
    return null;
  }
  return search(bar);
}

async function ensureDefaultFolder(name) {
  let id = await findFolderByName(name);
  if (id) return id;
  const tree = await chrome.bookmarks.getTree();
  const bar = tree[0].children.find(c => c.id === '1' || c.title === '书签栏');
  if (!bar) throw new Error('未找到书签栏');
  const f = await chrome.bookmarks.create({ parentId: bar.id, title: name });
  return f.id;
}

async function saveFolderIds() {
  const rPath = readFolderId ? await getFolderPathById(readFolderId) : null;
  const aPath = archiveFolderId ? await getFolderPathById(archiveFolderId) : null;
  await chrome.storage.local.set({ readFolderId, archiveFolderId, readFolderPath: rPath, archiveFolderPath: aPath });
}

async function loadFolderIds() {
  const res = await chrome.storage.local.get(['readFolderId','archiveFolderId','readFolderPath','archiveFolderPath']);
  const isValid = async (id) => { try { await chrome.bookmarks.get(id); return true; } catch { return false; } };
  if (res.readFolderPath) { const id = await findFolderByPath(res.readFolderPath); if (id) readFolderId = id; }
  if (res.archiveFolderPath) { const id = await findFolderByPath(res.archiveFolderPath); if (id) archiveFolderId = id; }
  if (!readFolderId && res.readFolderId && await isValid(res.readFolderId)) readFolderId = res.readFolderId;
  if (!archiveFolderId && res.archiveFolderId && await isValid(res.archiveFolderId)) archiveFolderId = res.archiveFolderId;
  if (!readFolderId || !(await isValid(readFolderId))) {
    const found = await findFolderByName(DEFAULT_READ_FOLDER);
    readFolderId = found || await ensureDefaultFolder(DEFAULT_READ_FOLDER);
  }
  if (!archiveFolderId || !(await isValid(archiveFolderId))) {
    const found = await findFolderByName(DEFAULT_ARCHIVE_FOLDER);
    archiveFolderId = found || await ensureDefaultFolder(DEFAULT_ARCHIVE_FOLDER);
  }
  await saveFolderIds();
}

// ===== 书签渲染 =====
async function renderFolderContents(query = '') {
  if (!currentFolderId) {
    const rootId = getRootFolderId();
    if (!rootId) { listEl.innerHTML = `<li style="border:none; color:#666;">请设置${currentReadingMode==='read'?'稍后阅读':'标签存档'}文件夹</li>`; navBar.style.display = 'none'; return; }
    currentFolderId = rootId; folderStack = []; await updateNavBar(rootId);
  }
  try { await chrome.bookmarks.get(currentFolderId); } catch { listEl.innerHTML = '<li style="border:none; color:#666;">文件夹已被删除，请重新设置</li>'; navBar.style.display = 'none'; return; }
  try {
    const children = await chrome.bookmarks.getChildren(currentFolderId);
    let filtered = children;
    if (query) { const q = query.toLowerCase(); filtered = children.filter(item => getCleanTitle(item.title).toLowerCase().includes(q)); }
    filtered = filtered.reverse();
    listEl.innerHTML = '';
    for (const item of filtered) {
      const li = document.createElement('li');
      const isFolder = !item.url, unread = !isFolder && isUnread(item.title);
      li.innerHTML = `
        <button class="del-btn">✕</button>
        <div class="status-icon" style="cursor:pointer;">${isFolder ? '📁' : (unread ? '🔵' : '⚪')}</div>
        <div class="item-info">
          <a href="${isFolder ? '#' : item.url}" class="title ${!unread && !isFolder ? 'read-text' : ''}" target="_blank">${escapeHtml(getCleanTitle(item.title))}</a>
        </div>`;
      const titleLink = li.querySelector('.title'), iconBtn = li.querySelector('.status-icon');
      if (isFolder) {
        const handler = e => { e.preventDefault(); openFolder(item.id, item.title); };
        titleLink.onclick = handler; iconBtn.onclick = handler;
      } else {
        titleLink.onclick = async e => { if(unread){ await chrome.bookmarks.update(item.id,{title:item.title.replace('🔵','⚪')}); renderFolderContents(searchInput.value); } };
        iconBtn.onclick = async () => {
          const newTitle = unread ? item.title.replace('🔵','⚪') : '🔵 '+item.title.replace(/^⚪\s*/,'');
          await chrome.bookmarks.update(item.id,{title:newTitle}); renderFolderContents(searchInput.value);
        };
      }
      li.querySelector('.del-btn').onclick = async () => {
        if (isFolder) { await chrome.bookmarks.removeTree(item.id); if (item.id===currentFolderId||folderStack.some(f=>f.id===item.id)) await resetNavigation(); else renderFolderContents(searchInput.value); }
        else { await chrome.bookmarks.remove(item.id); renderFolderContents(searchInput.value); }
      };
      listEl.appendChild(li);
    }
    if (filtered.length === 0) listEl.innerHTML = '<li style="border:none; color:#999;">暂无内容</li>';
  } catch (e) { listEl.innerHTML = '<li style="border:none;">加载失败</li>'; }
}

async function searchBookmarks(folderId, query) {
  const results = [], q = query.toLowerCase();
  async function traverse(id) {
    const children = await chrome.bookmarks.getChildren(id);
    for (const child of children) {
      if (child.url) { if (getCleanTitle(child.title).toLowerCase().includes(q)||child.url.toLowerCase().includes(q)) results.push(child); }
      else await traverse(child.id);
    }
  }
  await traverse(folderId); return results;
}

async function renderSearchResults(query) {
  const rootId = getRootFolderId();
  if (!rootId) { listEl.innerHTML = '<li>请先设置文件夹</li>'; return; }
  listEl.innerHTML = '<li>搜索中...</li>';
  const results = await searchBookmarks(rootId, query);
  if (!results.length) { listEl.innerHTML = '<li>未找到匹配</li>'; return; }
  listEl.innerHTML = '';
  for (const item of results) {
    const li = document.createElement('li'), unread = isUnread(item.title);
    li.innerHTML = `<button class="del-btn">✕</button><div class="status-icon" style="cursor:pointer;">${unread?'🔵':'⚪'}</div><div class="item-info"><a href="${item.url}" class="title ${!unread?'read-text':''}" target="_blank">${escapeHtml(getCleanTitle(item.title))}</a></div>`;
    li.querySelector('.title').onclick = async e => { if(unread){ await chrome.bookmarks.update(item.id,{title:item.title.replace('🔵','⚪')}); renderSearchResults(query); } };
    li.querySelector('.status-icon').onclick = async () => { const newTitle = unread ? item.title.replace('🔵','⚪') : '🔵 '+item.title.replace(/^⚪\s*/,''); await chrome.bookmarks.update(item.id,{title:newTitle}); renderSearchResults(query); };
    li.querySelector('.del-btn').onclick = async () => { await chrome.bookmarks.remove(item.id); renderSearchResults(query); };
    listEl.appendChild(li);
  }
}

async function updateNavBar(folderId) {
  if (!folderId) { navBar.style.display = 'none'; return; }
  const rootId = getRootFolderId();
  if (folderId === rootId && folderStack.length === 0) { navBar.style.display = 'none'; return; }
  navBar.style.display = 'flex';
  try { currentPathSpan.textContent = (await chrome.bookmarks.get(folderId))[0]?.title || '文件夹'; } catch { currentPathSpan.textContent = '文件夹'; }
}

async function openFolder(folderId) {
  if (!folderId) return;
  if (currentFolderId) { let title = '根目录'; try { title = (await chrome.bookmarks.get(currentFolderId))[0].title; } catch {}; folderStack.push({id:currentFolderId,title}); }
  currentFolderId = folderId; await updateNavBar(folderId); searchInput.value = ''; isSearchMode = false; renderFolderContents('');
}

async function goBack() {
  if (folderStack.length === 0) {
    const rootId = getRootFolderId();
    if (rootId) { currentFolderId = rootId; folderStack = []; await updateNavBar(rootId); searchInput.value = ''; isSearchMode = false; renderFolderContents(''); }
  } else {
    const parent = folderStack.pop(); currentFolderId = parent.id; await updateNavBar(parent.id); searchInput.value = ''; isSearchMode = false; renderFolderContents('');
  }
}

async function resetNavigation() {
  const rootId = getRootFolderId();
  if (rootId) { currentFolderId = rootId; folderStack = []; await updateNavBar(rootId); searchInput.value = ''; isSearchMode = false; renderFolderContents(''); }
  else { listEl.innerHTML = '<li>请重新设置文件夹</li>'; navBar.style.display = 'none'; }
}

let searchTimer;
function onReadingSearchInput() {
  clearTimeout(searchTimer);
  const query = searchInput.value;
  if (query.trim()) { isSearchMode = true; navBar.style.display = 'none'; listEl.innerHTML = '<li>搜索中...</li>'; searchTimer = setTimeout(() => renderSearchResults(query), 250); }
  else { isSearchMode = false; navBar.style.display = (currentFolderId && currentFolderId !== getRootFolderId()) ? 'flex' : 'none'; renderFolderContents(''); }
}

// ===== 分享功能 =====
async function loadWebDAVConfig() {
  webdavConfig.url = await getStorage(STORAGE_KEYS.WEBDAV_URL) || '';
  webdavConfig.username = await getStorage(STORAGE_KEYS.WEBDAV_USER) || '';
  webdavConfig.password = await getStorage(STORAGE_KEYS.WEBDAV_PASS) || '';
  sharedFileName = (await getStorage('webdavFile')) || 'shared_links.json';
}

function getWebDAVClientInstance() {
  if (!webdavConfig.url || !webdavConfig.username || !webdavConfig.password) throw new Error('请先在选项页配置 WebDAV');
  return new WebDAVClient(webdavConfig.url, webdavConfig.username, webdavConfig.password);
}

async function loadSharedItems() {
  try { const client = getWebDAVClientInstance(); const text = await client.getFile(sharedFileName); return text ? JSON.parse(text) : []; }
  catch(e) { if(e.message.includes('404')) return []; throw e; }
}

async function saveSharedItems(items) { const client = getWebDAVClientInstance(); await client.putFile(sharedFileName, JSON.stringify(items, null, 2)); }

async function addSharedItem(type, data) {
  const items = await loadSharedItems();
  const newItem = { id: Date.now()+'-'+Math.random().toString(36).substr(2,6), type, timestamp: new Date().toISOString(), ...data };
  items.push(newItem); await saveSharedItems(items); sharedItemsCache = items; return newItem;
}

async function deleteSharedItem(id) {
  let items = await loadSharedItems(); items = items.filter(i=>i.id!==id); await saveSharedItems(items); sharedItemsCache = items;
}

async function shareCurrentPage() {
  const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
  await addSharedItem('page', {title:tab.title, url:tab.url});
  alert('已分享当前页面'); if (currentReadingMode==='shared') renderSharedList();
}

async function shareCurrentWindowGroup() {
  const tabs = await chrome.tabs.query({currentWindow:true});
  const valid = tabs.filter(t=>t.url&&!t.url.startsWith('chrome://')&&!t.url.startsWith('chrome-extension://'));
  if (!valid.length) { alert('无可分享标签'); return; }
  await addSharedItem('group', {name:`标签组 ${new Date().toLocaleString('zh-CN',{hour12:false})}`, tabs:valid.map(t=>({title:t.title,url:t.url}))});
  alert(`已分享 ${valid.length} 个标签`); if (currentReadingMode==='shared') renderSharedList();
}

async function renderSharedList() {
  listEl.innerHTML = '<li>加载中...</li>';
  try {
    sharedItemsCache = await loadSharedItems();
    if (!sharedItemsCache.length) { listEl.innerHTML = '<li>暂无分享</li>'; return; }
    const sorted = [...sharedItemsCache].reverse();
    listEl.innerHTML = '';
    for (const item of sorted) {
      const li = document.createElement('li'); li.className = 'shared-item';
      const isGroup = item.type==='group', icon = isGroup?'📁':'🔗';
      const timeStr = new Date(item.timestamp).toLocaleString('zh-CN',{hour12:false});
      const titleHtml = isGroup?`${escapeHtml(item.name)} (${item.tabs.length}个标签)`:`<a href="${item.url}" target="_blank" style="color:#1a1a1a;">${escapeHtml(item.title)}</a>`;
      li.innerHTML = `<div class="shared-icon">${icon}</div><div class="shared-content"><div class="shared-title">${titleHtml}</div><div class="shared-meta"><span>${timeStr}</span>${!isGroup?`<span>${escapeHtml(item.url.substring(0,40))}…</span>`:''}</div></div><div class="shared-actions"><button class="open-shared" data-id="${item.id}" data-type="${item.type}">打开</button><button class="delete-shared" data-id="${item.id}">删除</button></div>`;
      listEl.appendChild(li);
    }
    document.querySelectorAll('.open-shared').forEach(btn=>{ btn.addEventListener('click', async e=>{ const {id,type}=e.target.dataset; const item=sharedItemsCache.find(i=>i.id===id); if(!item)return; if(type==='page')chrome.tabs.create({url:item.url}); else if(type==='group') for(const t of item.tabs) chrome.tabs.create({url:t.url, active:false}); }); });
    document.querySelectorAll('.delete-shared').forEach(btn=>{ btn.addEventListener('click', async e=>{ await deleteSharedItem(e.target.dataset.id); renderSharedList(); }); });
  } catch(e) { listEl.innerHTML = `<li class="error-message">加载失败: ${e.message}<br>请检查 WebDAV 配置</li>`; }
}

function setReadingMode(mode) {
  currentReadingMode = mode;
  viewReadBtn.classList.remove('active'); viewArchiveBtn.classList.remove('active'); viewSharedBtn.classList.remove('active');
  if (mode==='read') viewReadBtn.classList.add('active'); else if (mode==='archive') viewArchiveBtn.classList.add('active'); else if (mode==='shared') viewSharedBtn.classList.add('active');
  searchInput.value = ''; isSearchMode = false; navBar.style.display = 'none';
  if (mode==='shared') renderSharedList();
  else { const rootId = getRootFolderId(); if(rootId){ currentFolderId = rootId; folderStack = []; renderFolderContents(''); } else listEl.innerHTML = `<li>请设置${mode==='read'?'稍后阅读':'标签存档'}文件夹</li>`; }
}

async function populateFolderSelects() {
  const tree = await chrome.bookmarks.getTree();
  function walk(nodes, depth, select) {
    nodes.forEach(n => { if(!n.url){ const opt = document.createElement('option'); opt.value = n.id; opt.textContent = '\u00A0'.repeat(depth*2)+(n.title||'书签栏'); select.appendChild(opt); if(n.children)walk(n.children,depth+1,select); } });
  }
  readFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>'; archiveFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
  walk(tree, 0, readFolderSelect); walk(tree, 0, archiveFolderSelect);
  if(readFolderId) readFolderSelect.value = readFolderId; if(archiveFolderId) archiveFolderSelect.value = archiveFolderId;
}

async function saveFolderSettings() {
  const r = readFolderSelect.value, a = archiveFolderSelect.value;
  if(r && a){ readFolderId = r; archiveFolderId = a; await saveFolderIds(); }
}

// ========== 通用辅助 ==========
function setStatus(el, text, isError = false) {
  el.textContent = text; el.className = isError ? 'status error' : 'status';
  setTimeout(() => { if (el.textContent === text) { el.textContent = '就绪'; el.className = 'status'; } }, 4000);
}

// ========== 缓存所有稍后阅读及通用 DOM 元素 ==========
function cacheDom() {
  syncStatusDiv = document.getElementById('syncStatus');
  bookmarkLocalSpan = document.getElementById('bookmarkLocal');
  bookmarkRemoteSpan = document.getElementById('bookmarkRemote');
  progressArea = document.getElementById('progressArea');
  progressBar = document.getElementById('progressBar');
  progressMessage = document.getElementById('progressMessage');
  extTotalSpan = document.getElementById('extTotal');
  extEnabledSpan = document.getElementById('extEnabled');
  extDisabledSpan = document.getElementById('extDisabled');
  extBackupTimeSpan = document.getElementById('extBackupTime');
  extGrid = document.getElementById('extGrid');
  extSearch = document.getElementById('extSearch');
  extStatusDiv = document.getElementById('extStatus');
  listEl = document.getElementById('list');
  searchInput = document.getElementById('searchInput');
  saveBtn = document.getElementById('saveBtn');
  archiveBtn = document.getElementById('archiveBtn');
  sharePageBtn = document.getElementById('sharePageBtn');
  shareGroupBtn = document.getElementById('shareGroupBtn');
  configBtn = document.getElementById('configBtn');
  settingsSection = document.getElementById('settingsSection');
  readFolderSelect = document.getElementById('readFolderSelect');
  archiveFolderSelect = document.getElementById('archiveFolderSelect');
  saveSettingsBtn = document.getElementById('saveSettingsBtn');
  viewReadBtn = document.getElementById('viewReadBtn');
  viewArchiveBtn = document.getElementById('viewArchiveBtn');
  viewSharedBtn = document.getElementById('viewSharedBtn');
  navBar = document.getElementById('navBar');
  backBtn = document.getElementById('backBtn');
  currentPathSpan = document.getElementById('currentPath');
  readingStatusDiv = document.getElementById('readingStatus');
}

// ========== 初始化 ==========
async function init() {
  cacheDom(); // 所有 DOM 元素就绪

  // 同步 & 书签按钮
  document.getElementById('bookmarksUpload').addEventListener('click', async () => { await sendMessage('bookmarksUpload','书签上传中...'); await refreshBookmarkStats(); });
  document.getElementById('bookmarksDownload').addEventListener('click', async () => { await sendMessage('bookmarksDownload','书签下载中...'); await refreshBookmarkStats(); });
  document.getElementById('bookmarksClear').addEventListener('click', async () => { if(!confirm('确定清空所有书签吗？'))return; await sendMessage('bookmarksClear','清空书签中...'); await refreshBookmarkStats(); });
  document.getElementById('historyIncremental').addEventListener('click', () => sendMessage('incrementalBackup','合并上传中...'));
  document.getElementById('historyDownload').addEventListener('click', () => sendMessage('fullDownload','全量下载中...'));
  document.getElementById('historyFullBackup').addEventListener('click', () => sendMessage('fullBackup','全量上传中...'));
  document.getElementById('historyViewBtn').addEventListener('click', () => chrome.tabs.create({ url: 'history-viewer.html' }));

  // 扩展管理按钮
  document.getElementById('extensionsBackup').addEventListener('click', async () => { await sendMessage('extensionsBackup','备份扩展状态中...'); await refreshExtensionsBackupInfo(); });
  document.getElementById('extensionsRestore').addEventListener('click', async () => {
    const result = await sendMessage('extensionsRestore','恢复扩展状态中...');
    if(result.success){ await loadExtensions(); if(result.missing){ missingExtensions=result.missing; renderMissingExtensions(); } }
    await refreshExtensionsBackupInfo();
  });
  document.getElementById('manageBtn').addEventListener('click', () => chrome.tabs.create({ url: 'manage.html' }));
  document.getElementById('btnSettings').addEventListener('click', () => { if(chrome.runtime?.openOptionsPage) chrome.runtime.openOptionsPage(); else setStatus(extStatusDiv,'无法打开设置页',true); });
  extSearch.addEventListener('input', applyExtFilter);

  // 稍后阅读按钮（全部移至此处，修复 undefined 问题）
  saveBtn.addEventListener('click', async () => {
    if (!readFolderId) { alert('请先设置稍后阅读文件夹'); return; }
    try { await chrome.bookmarks.get(readFolderId); } catch { alert('文件夹不存在'); return; }
    const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
    await chrome.bookmarks.create({parentId:readFolderId, title:'🔵 '+tab.title, url:tab.url});
    if (currentReadingMode==='read') await resetNavigation(); else alert('已保存');
  });

  archiveBtn.addEventListener('click', async () => {
    if (!archiveFolderId) { alert('请先设置标签存档文件夹'); return; }
    try { await chrome.bookmarks.get(archiveFolderId); } catch { alert('文件夹不存在'); return; }
    const tabs = await chrome.tabs.query({currentWindow:true});
    const timestamp = new Date().toLocaleString('zh-CN',{hour12:false}).replace(/:/g,'-');
    const newFolder = await chrome.bookmarks.create({parentId:archiveFolderId, title:timestamp});
    for (const tab of tabs) {
      if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://'))
        await chrome.bookmarks.create({parentId:newFolder.id, title:'🔵 '+tab.title, url:tab.url});
    }
    if (currentReadingMode==='archive') await resetNavigation(); else alert('已存档');
  });

  sharePageBtn.addEventListener('click', async () => {
    try { await shareCurrentPage(); } catch(e) { alert('分享失败: '+e.message); }
  });
  shareGroupBtn.addEventListener('click', async () => {
    try { await shareCurrentWindowGroup(); } catch(e) { alert('分享失败: '+e.message); }
  });
  configBtn.addEventListener('click', async () => {
    await populateFolderSelects();
    settingsSection.style.display = settingsSection.style.display==='none'?'block':'none';
  });
  saveSettingsBtn.addEventListener('click', async () => {
    await saveFolderSettings();
    settingsSection.style.display = 'none';
    if (currentReadingMode !== 'shared') setReadingMode(currentReadingMode);
  });

  viewReadBtn.addEventListener('click', () => setReadingMode('read'));
  viewArchiveBtn.addEventListener('click', () => setReadingMode('archive'));
  viewSharedBtn.addEventListener('click', () => setReadingMode('shared'));
  backBtn.addEventListener('click', goBack);
  searchInput.addEventListener('input', onReadingSearchInput);

  // 扩展事件监听
  chrome.management.onInstalled.addListener(info => { if(info.type==='extension') loadExtensions(); });
  chrome.management.onUninstalled.addListener(() => loadExtensions());
  chrome.management.onEnabled.addListener(() => loadExtensions());
  chrome.management.onDisabled.addListener(() => loadExtensions());

  // 选项卡切换
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(target).classList.add('active');
      if (target === 'tab-extensions') loadExtensions();
      if (target === 'tab-reading') setReadingMode(currentReadingMode);
      if (target === 'tab-history-search') HistorySearch.init();
    });
  });

  // 各模块数据初始化
  refreshBookmarkStats();
  loadExtensions();
  refreshExtensionsBackupInfo();
  await loadFolderIds();
  await loadWebDAVConfig();
  setReadingMode('read');
  HistorySearch.init();
}

document.addEventListener('DOMContentLoaded', init);