const statusDiv = document.getElementById('status');
const bookmarkLocalSpan = document.getElementById('bookmarkLocal');
const bookmarkRemoteSpan = document.getElementById('bookmarkRemote');
const extTotalSpan = document.getElementById('extTotal');
const extEnabledSpan = document.getElementById('extEnabled');
const extDisabledSpan = document.getElementById('extDisabled');
const extBackupTimeSpan = document.getElementById('extBackupTime');
const extGrid = document.getElementById('extGrid');
const searchInput = document.getElementById('searchInput');
const extStatusDiv = document.getElementById('extStatus');

let currentExtensions = [];
let filteredExtensions = [];

// ---------- 辅助函数 ----------
function setStatus(text, isError = false) {
  statusDiv.textContent = text;
  statusDiv.className = isError ? 'status error' : 'status';
  setTimeout(() => {
    if (statusDiv.textContent === text) {
      statusDiv.textContent = '就绪';
      statusDiv.className = 'status';
    }
  }, 4000);
}

function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

async function sendMessage(action, loadingText) {
  if (!chrome.runtime?.id) {
    setStatus('扩展上下文失效，请重新打开', true);
    return { success: false };
  }
  setStatus(loadingText);
  try {
    const result = await chrome.runtime.sendMessage({ action });
    setStatus(result.message, !result.success);
    return result;
  } catch (err) {
    setStatus('操作失败: ' + err.message, true);
    return { success: false, message: err.message };
  }
}

// ---------- 加载扩展列表 ----------
async function loadExtensions() {
  try {
    const exts = await chrome.management.getAll();
    currentExtensions = exts.filter(ext => ext.type === 'extension');
    applyFilterAndRender();
  } catch (err) {
    setStatus('加载扩展失败: ' + err.message, true);
    extGrid.innerHTML = '<div>加载失败</div>';
  }
}

function applyFilterAndRender() {
  const searchTerm = searchInput.value.trim().toLowerCase();
  filteredExtensions = currentExtensions.filter(ext =>
    ext.name.toLowerCase().includes(searchTerm)
  );
  renderGrid();
  updateStats();
}

function renderGrid() {
  if (!filteredExtensions.length) {
    extGrid.innerHTML = '<div style="text-align:center; padding:20px;">未找到扩展</div>';
    return;
  }
  let html = '';
  for (const ext of filteredExtensions) {
    const enabled = ext.enabled;
    const name = escapeHtml(ext.name);
    const version = ext.version || '?';
    const extId = ext.id;
    const hasOptions = ext.optionsUrl ? true : false;
    const storeUrl = `https://chrome.google.com/webstore/detail/${extId}`;
    html += `
      <div class="ext-card" data-id="${extId}">
        <div class="ext-name">
          <span title="${name} (${extId})">${name}</span>
          <label class="toggle-switch">
            <input type="checkbox" class="ext-toggle" data-id="${extId}" ${enabled ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="ext-version">v${version}</div>
        <div class="ext-controls">
          <div>
            ${hasOptions ? `<button class="ext-options-btn" data-id="${extId}" data-optionsurl="${escapeHtml(ext.optionsUrl)}">⚙️ 选项</button>` : ''}
            <button class="ext-store-btn" data-storeurl="${storeUrl}">🛒 商店</button>
          </div>
          <span style="font-size:11px;">${enabled ? '●启用' : '○禁用'}</span>
        </div>
      </div>
    `;
  }
  extGrid.innerHTML = html;

  // 绑定切换开关事件
  document.querySelectorAll('.ext-toggle').forEach(toggle => {
    toggle.addEventListener('change', async (e) => {
      e.stopPropagation();
      const id = toggle.getAttribute('data-id');
      const newState = toggle.checked;
      try {
        await chrome.management.setEnabled(id, newState);
        const ext = currentExtensions.find(e => e.id === id);
        if (ext) ext.enabled = newState;
        applyFilterAndRender();
        setStatus(`已${newState ? '启用' : '禁用'} ${ext.name}`);
      } catch (err) {
        setStatus(`失败: ${err.message}`, true);
        toggle.checked = !newState;
      }
    });
  });

  // 选项按钮
  document.querySelectorAll('.ext-options-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-optionsurl');
      if (url) chrome.tabs.create({ url });
      else setStatus('无选项页');
    });
  });

  // 商店按钮
  document.querySelectorAll('.ext-store-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-storeurl');
      chrome.tabs.create({ url });
    });
  });
}

function updateStats() {
  const total = currentExtensions.length;
  const enabled = currentExtensions.filter(e => e.enabled).length;
  extTotalSpan.textContent = total;
  extEnabledSpan.textContent = enabled;
  extDisabledSpan.textContent = total - enabled;
}

// ---------- 刷新书签统计 ----------
async function refreshBookmarkStats() {
  try {
    const stats = await chrome.runtime.sendMessage({ action: 'getBookmarkStats' });
    bookmarkLocalSpan.textContent = stats.local ?? '?';
    bookmarkRemoteSpan.textContent = stats.remote ?? '?';
  } catch {
    bookmarkLocalSpan.textContent = '?';
    bookmarkRemoteSpan.textContent = '?';
  }
}

// ---------- 刷新扩展备份时间 ----------
async function refreshExtensionsBackupInfo() {
  try {
    const stats = await chrome.runtime.sendMessage({ action: 'getExtensionsStats' });
    if (stats.lastBackupTime) {
      const d = new Date(stats.lastBackupTime).toLocaleString();
      extBackupTimeSpan.textContent = `上次备份: ${d}`;
    } else {
      extBackupTimeSpan.textContent = '暂无备份';
    }
  } catch {
    extBackupTimeSpan.textContent = '';
  }
}

// ---------- 初始化 ----------
async function init() {
  await loadExtensions();
  await refreshBookmarkStats();
  await refreshExtensionsBackupInfo();
}

// ---------- 事件绑定 ----------
document.getElementById('bookmarksUpload').addEventListener('click', async () => {
  await sendMessage('bookmarksUpload', '书签上传中...');
  await refreshBookmarkStats();
});

document.getElementById('bookmarksDownload').addEventListener('click', async () => {
  await sendMessage('bookmarksDownload', '书签下载中...');
  await refreshBookmarkStats();
  await loadExtensions();
});

document.getElementById('bookmarksClear').addEventListener('click', async () => {
  if (!confirm('确定清空所有书签吗？（书签栏、其他书签、移动书签将被完全清空）')) return;
  await sendMessage('bookmarksClear', '清空书签中...');
  await refreshBookmarkStats();
});

document.getElementById('historyIncremental').addEventListener('click', () => {
  sendMessage('incrementalBackup', '合并上传中...');
});

document.getElementById('historyDownload').addEventListener('click', () => {
  sendMessage('fullDownload', '全量下载中...');
});

document.getElementById('historyFullBackup').addEventListener('click', () => {
  sendMessage('fullBackup', '全量上传中...');
});

document.getElementById('extensionsBackup').addEventListener('click', async () => {
  await sendMessage('extensionsBackup', '备份扩展状态中...');
  await refreshExtensionsBackupInfo();
});

document.getElementById('extensionsRestore').addEventListener('click', async () => {
  const result = await sendMessage('extensionsRestore', '恢复扩展状态中...');
  if (result.success) {
    await loadExtensions();
    if (result.missing && result.missing.length > 0) {
      extStatusDiv.innerHTML = `⚠️ 缺失 ${result.missing.length} 个扩展：` +
        result.missing.map(e => `<span class="missing-item">${escapeHtml(e.name)}</span>`).join('');
    } else {
      extStatusDiv.textContent = '所有扩展状态已同步';
    }
  }
  await refreshExtensionsBackupInfo();
});

document.getElementById('manageBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'manage.html' });
});

document.getElementById('btnSettings').addEventListener('click', () => {
  if (chrome.runtime?.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    setStatus('无法打开设置页', true);
  }
});

searchInput.addEventListener('input', applyFilterAndRender);

// 启动
init();