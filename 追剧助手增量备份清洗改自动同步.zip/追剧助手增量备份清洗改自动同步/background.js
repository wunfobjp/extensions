/**
 * 追剧助手 - Background Service Worker (MV3)
 * 功能：
 * 1. 监听进度上报并写入 storage
 * 2. 协助 Iframe 获取父页面标题和 URL (解决跨域匹配问题)
 * 3. 管理图标状态反馈 (REC 角标)，增加节流防止频繁闪烁
 * 4. 自动 WebDAV 合并上传计划 (新增)
 */

// 记录每个标签页最后一次显示角标的时间戳
const lastBadgeTime = new Map();

// ======================= 消息处理（原有逻辑） =======================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // --- 逻辑 1：处理进度上报 (UPDATE_FAV) ---
    if (request.action === "UPDATE_FAV") {
        const { series, data } = { 
            series: request.data.series, 
            data: request.data 
        };

        chrome.storage.local.get(['favorites'], (res) => {
            let favs = res.favorites || {};
            const oldRecord = favs[series];
            const newRecord = {
                ...data,
                ts: Date.now()
            };
            
            let hasProgressChanged = true;
            if (oldRecord) {
                const timeDiff = Math.abs((oldRecord.time || 0) - (newRecord.time || 0));
                const epChanged = oldRecord.episode !== newRecord.episode;
                if (timeDiff < 2 && !epChanged) {
                    hasProgressChanged = false;
                }
            }
            
            favs[series] = newRecord;
            chrome.storage.local.set({ favorites: favs }, () => {
                if (hasProgressChanged && sender.tab && sender.tab.id) {
                    showBadgeWithThrottle(sender.tab.id);
                }
            });
        });
    }

    // --- 逻辑 2：解决跨域 Iframe 拿不到父页面标题的问题 (GET_TOP_INFO) ---
    if (request.action === "GET_TOP_INFO") {
        if (sender.tab) {
            sendResponse({
                title: sender.tab.title,
                url: sender.tab.url
            });
        } else {
            sendResponse(null);
        }
    }

    return true; 
});

// ======================= 角标显示（带节流） =======================
function showBadgeWithThrottle(tabId) {
    if (!tabId) return;
    
    const now = Date.now();
    const lastTime = lastBadgeTime.get(tabId) || 0;
    if (now - lastTime < 3000) {
        return;
    }
    lastBadgeTime.set(tabId, now);
    
    chrome.action.setBadgeText({ text: "REC", tabId: tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#00aeec", tabId: tabId });

    setTimeout(() => {
        chrome.tabs.get(tabId, (tab) => {
            if (!chrome.runtime.lastError && tab) {
                chrome.action.getBadgeText({ tabId: tabId }, (currentText) => {
                    if (currentText === "REC") {
                        chrome.action.setBadgeText({ text: "", tabId: tabId });
                    }
                });
            }
        });
    }, 2000);
}

// ======================= WebDAV 自动同步 =======================
// 合并函数（与 popup.js 保持一致）
function mergeFavorites(localFav, cloudFav) {
    const result = { ...cloudFav };
    for (const [key, localRecord] of Object.entries(localFav)) {
        if (!result[key]) {
            result[key] = localRecord;
        } else {
            if (localRecord.ts > result[key].ts) {
                result[key] = localRecord;
            }
        }
    }
    return result;
}

function mergeCollections(localColl, cloudColl) {
    const result = { ...cloudColl };
    for (const [folder, items] of Object.entries(localColl)) {
        if (!result[folder]) {
            result[folder] = [...items];
        } else {
            const merged = [...result[folder]];
            for (const item of items) {
                if (!merged.includes(item)) merged.push(item);
            }
            result[folder] = merged;
        }
    }
    return result;
}

function mergePresets(localPresets, cloudPresets) {
    const map = new Map();
    for (const p of cloudPresets) map.set(p.matchKey, p);
    for (const p of localPresets) map.set(p.matchKey, p);
    return Array.from(map.values());
}

async function davRequest(method, path = 'video_history.json', body = null, retryMkcol = true) {
    const config = await chrome.storage.local.get(['davUrl', 'davUser', 'davPass']);
    if (!config.davUrl || !config.davUser || !config.davPass) throw new Error('同步配置不完整');
    const auth = btoa(`${config.davUser}:${config.davPass}`);
    let baseUrl = config.davUrl.endsWith('/') ? config.davUrl : config.davUrl + '/';
    if (path.startsWith('/')) path = path.substring(1);
    const fullUrl = baseUrl + path;
    const options = {
        method,
        headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        }
    };
    if (body) options.body = JSON.stringify(body);
    const response = await fetch(fullUrl, options);
    if (method === 'PUT' && response.status === 409 && retryMkcol) {
        const dirPath = path.substring(0, path.lastIndexOf('/'));
        if (dirPath) {
            await davRequest('MKCOL', dirPath, null, false);
            return davRequest(method, path, body, false);
        }
    }
    if (!response.ok && method !== 'GET') throw new Error(`服务器返回: ${response.status}`);
    return response;
}

async function performAutoSync() {
    console.log('[追剧助手] 开始自动合并同步...');
    try {
        // 获取本地数据
        const localData = await chrome.storage.local.get(['favorites', 'collections', 'savedPresets']);
        const favData = localData.favorites || {};
        const collections = localData.collections || {};
        const savedPresets = localData.savedPresets || [];

        // 尝试从云端获取当前备份
        let cloudData = { favorites: {}, collections: {}, savedPresets: [] };
        try {
            const res = await davRequest('GET');
            if (res.status === 200) {
                cloudData = await res.json();
            } else if (res.status !== 404) {
                throw new Error(`获取云端数据失败: ${res.status}`);
            }
        } catch (e) {
            console.warn('[追剧助手] 获取云端数据异常，将视为空云端进行合并', e);
        }

        // 合并
        const mergedFav = mergeFavorites(favData, cloudData.favorites || {});
        const mergedColl = mergeCollections(collections, cloudData.collections || {});
        const mergedPresets = mergePresets(savedPresets, cloudData.savedPresets || []);

        const mergedBackup = {
            favorites: mergedFav,
            collections: mergedColl,
            savedPresets: mergedPresets
        };

        await davRequest('PUT', 'video_history.json', mergedBackup);
        console.log('[追剧助手] 自动合并同步完成');
    } catch (e) {
        console.error('[追剧助手] 自动合并同步失败:', e.message);
    }
}

// 监听 alarm 事件
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'auto-webdav-sync') {
        performAutoSync();
    }
});

// 扩展启动时检查 alarm 是否存在（应对浏览器重启等情况）
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(['autoSyncEnabled'], (items) => {
        if (items.autoSyncEnabled) {
            console.log('[追剧助手] 浏览器已启动，自动同步计划已就绪，将在下一个周期执行');
        }
    });
});

// 插件安装或更新时的初始化
chrome.runtime.onInstalled.addListener(() => {
    console.log("追剧助手已就绪！");
});