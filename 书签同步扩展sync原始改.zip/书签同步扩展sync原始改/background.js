// ---------- 默认配置 ----------
const DEFAULT_SETTINGS = {
  url: '',
  username: '',
  password: '',
  remotePath: '/bookmarks.json',
  swapBookmarkMobile: false,
  lastSync: 0
};

const META_STORAGE_KEY = 'bookmarksMeta';

// ---------- 获取配置 ----------
async function getSettings() {
  const result = await chrome.storage.sync.get('settings');
  return result.settings || DEFAULT_SETTINGS;
}

// ---------- 动态识别标准文件夹（针对移动端优化）----------
async function getStandardFolderIds() {
  const children = await chrome.bookmarks.getChildren('0');
  const folders = { bookmarkBar: null, other: null, mobile: null };

  // 1. 优先尝试使用 Chrome 标准固定 ID（最可靠）
  const tryGetById = async (id) => {
    try {
      await chrome.bookmarks.get(id);
      return id;
    } catch {
      return null;
    }
  };
  folders.bookmarkBar = await tryGetById('1');
  folders.other = await tryGetById('2');
  folders.mobile = await tryGetById('3');

  // 2. 如果标准 ID 失败，则通过标题关键词识别（覆盖多语言）
  for (const node of children) {
    const title = (node.title || '').toLowerCase();

    if (!folders.bookmarkBar) {
      if (title.includes('bookmark bar') || title.includes('书签栏') || title.includes('桌面书签') || title.includes('书签列')) {
        folders.bookmarkBar = node.id;
        continue;
      }
    }

    if (!folders.other) {
      if (title.includes('other bookmarks') || title.includes('其他书签') || title.includes('其它书签')) {
        folders.other = node.id;
        continue;
      }
    }

    if (!folders.mobile) {
      if (title.includes('mobile bookmarks') || title.includes('移动设备书签') || title.includes('移动书签') ||
          title.includes('手机书签') || title.includes('mobile') || title.includes('电话')) {
        folders.mobile = node.id;
        continue;
      }
    }
  }

  // 3. 兜底：如果只有一个根文件夹且未识别，则将其作为“其他书签”
  if (!folders.bookmarkBar && !folders.other && !folders.mobile && children.length === 1) {
    folders.other = children[0].id;
    console.warn('仅检测到一个根文件夹，已将其视为“其他书签”');
  }

  // 4. 处理交换选项
  const settings = await getSettings();
  if (settings.swapBookmarkMobile) {
    [folders.bookmarkBar, folders.mobile] = [folders.mobile, folders.bookmarkBar];
  }

  console.log('识别到的标准文件夹 ID:', folders);
  return folders;
}

// ---------- 工具函数 ----------
function generateGUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

function computeNodeHash(node) {
  let str = (node.title || '') + (node.url || '');
  if (node.children) {
    for (const child of node.children) {
      str += computeNodeHash(child);
    }
  }
  return simpleHash(str);
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return hash.toString(16);
}

async function getMeta() {
  const result = await chrome.storage.local.get(META_STORAGE_KEY);
  return result[META_STORAGE_KEY] || { guidMap: {}, lastModified: {}, hash: {}, deleted: [] };
}

async function saveMeta(meta) {
  await chrome.storage.local.set({ [META_STORAGE_KEY]: meta });
}

async function getOrCreateGUID(localId, meta) {
  if (!meta.guidMap[localId]) {
    meta.guidMap[localId] = generateGUID();
  }
  return meta.guidMap[localId];
}

// ---------- 导出书签 ----------
async function exportBookmarks() {
  const settings = await getSettings();
  const folders = await getStandardFolderIds();
  const meta = await getMeta();
  const exportTree = [];
  const order = ['bookmarkBar', 'other', 'mobile'];

  for (const key of order) {
    const id = folders[key];
    if (!id) continue;
    try {
      const nodes = await chrome.bookmarks.getSubTree(id);
      if (nodes && nodes[0]) {
        const root = nodes[0];
        const processedRoot = await processNodeForExport(root, meta, settings);
        processedRoot.id = key;
        exportTree.push(processedRoot);
      }
    } catch (e) {
      console.error(`导出文件夹 ${key} 失败:`, e);
    }
  }

  await saveMeta(meta);

  return {
    version: 4,
    timestamp: Date.now(),
    tree: exportTree,
    deleted: meta.deleted || []
  };
}

async function processNodeForExport(node, meta, settings) {
  const guid = await getOrCreateGUID(node.id, meta);
  const currentHash = computeNodeHash(node);
  const oldHash = meta.hash[guid];
  let lastModified = meta.lastModified[guid];

  if (oldHash !== currentHash || !lastModified) {
    lastModified = Date.now();
    meta.lastModified[guid] = lastModified;
    meta.hash[guid] = currentHash;
  }

  const exportNode = {
    guid,
    title: node.title,
    url: node.url || undefined,
    dateAdded: node.dateAdded,
    lastModified
  };

  if (node.children) {
    exportNode.children = [];
    for (const child of node.children) {
      exportNode.children.push(await processNodeForExport(child, meta, settings));
    }
  }

  return exportNode;
}

// ---------- 清空文件夹 ----------
async function clearFolder(folderId) {
  try {
    const children = await chrome.bookmarks.getChildren(folderId);
    for (const child of children) {
      await chrome.bookmarks.removeTree(child.id);
    }
  } catch (e) {
    console.warn(`清空文件夹 ${folderId} 失败:`, e);
  }
}

// ---------- 递归创建书签 ----------
async function createBookmarksRecursive(node, parentId, isRoot = false, meta = null) {
  if (!node || typeof node !== 'object') {
    console.warn('createBookmarksRecursive: 跳过无效节点', node);
    return;
  }

  if (isRoot) {
    for (const child of (node.children || [])) {
      await createBookmarksRecursive(child, parentId, false, meta);
    }
    return;
  }

  const title = node.title || '未命名';
  const url = node.url;

  let newId;
  if (url) {
    const created = await chrome.bookmarks.create({ parentId, title, url });
    newId = created.id;
  } else {
    const created = await chrome.bookmarks.create({ parentId, title });
    newId = created.id;
    for (const child of (node.children || [])) {
      await createBookmarksRecursive(child, newId, false, meta);
    }
  }

  if (meta && node.guid) {
    meta.guidMap[newId] = node.guid;
    meta.lastModified[node.guid] = node.lastModified || Date.now();
    try {
      const createdNode = (await chrome.bookmarks.get(newId))[0];
      meta.hash[node.guid] = computeNodeHash(createdNode);
    } catch (e) {}
  }
}

// ---------- 导入书签（仅用于“下载”模式，完全替换）----------
async function importBookmarks(remoteData) {
  if (!remoteData || !Array.isArray(remoteData.tree)) {
    throw new Error('远程数据格式错误：缺少 tree 数组');
  }

  const localFolders = await getStandardFolderIds();
  const settings = await getSettings();
  const meta = await getMeta();

  const remoteRoots = remoteData.tree
    .map(node => {
      if (!node || !node.id) return null;
      const targetId = localFolders[node.id];
      if (!targetId) {
        console.warn(`导入时本地无对应文件夹: ${node.id}，已跳过`);
        return null;
      }
      return { ...node, id: targetId };
    })
    .filter(n => n !== null);

  // 清空并重新创建（完全替换）
  for (const root of remoteRoots) {
    await clearFolder(root.id);
  }
  for (const root of remoteRoots) {
    await createBookmarksRecursive(root, root.id, true, meta);
  }
  meta.deleted = [];
  await saveMeta(meta);
}

// ---------- 统计书签数量（仅 URL 节点，排除根文件夹）----------
async function countBookmarksInTree(node, isRoot = false) {
  if (!node) return 0;
  let count = 0;
  if (!isRoot && node.url) {
    count = 1;
  }
  if (node.children) {
    for (const child of node.children) {
      count += await countBookmarksInTree(child, false);
    }
  }
  return count;
}

async function getLocalBookmarkCount() {
  const folders = await getStandardFolderIds();
  let total = 0;
  const counts = { bookmarkBar: 0, other: 0, mobile: 0 };

  for (const key of ['bookmarkBar', 'other', 'mobile']) {
    const id = folders[key];
    if (id) {
      try {
        const nodes = await chrome.bookmarks.getSubTree(id);
        if (nodes && nodes[0]) {
          const cnt = await countBookmarksInTree(nodes[0], true);
          counts[key] = cnt;
          total += cnt;
        }
      } catch (e) {
        console.warn(`统计 ${key} 失败:`, e);
      }
    }
  }

  if (total === 0 && !folders.bookmarkBar && !folders.other && !folders.mobile) {
    try {
      const rootNodes = await chrome.bookmarks.getTree();
      if (rootNodes && rootNodes[0]) {
        total = await countBookmarksInTree(rootNodes[0], true);
        console.warn('标准文件夹均未识别，改为统计全部书签树，总数:', total);
      }
    } catch (e) {
      console.error('统计全部书签失败:', e);
    }
  }

  console.log('各文件夹书签数量:', counts, '总计:', total);
  return total;
}

async function getRemoteBookmarkCount() {
  const settings = await getSettings();
  if (!settings.url) return null;
  try {
    await ensureRemotePath(settings);
    const response = await webdavRequest(settings, 'GET');
    if (response.status === 404) return 0;
    const data = await response.json();
    let count = 0;
    const countInNode = (node) => {
      if (!node) return;
      if (node.url) count++;
      for (const child of (node.children || [])) countInNode(child);
    };
    (data.tree || []).forEach(countInNode);
    return count;
  } catch {
    return null;
  }
}

// ---------- 清空所有书签 ----------
async function clearAllBookmarks() {
  const folders = await getStandardFolderIds();
  for (const key of ['bookmarkBar', 'other', 'mobile']) {
    const id = folders[key];
    if (id) await clearFolder(id);
  }
  await chrome.storage.local.remove(META_STORAGE_KEY);
}

// ---------- WebDAV 请求封装 ----------
async function webdavRequest(settings, method, body = null) {
  const headers = new Headers();
  if (settings.username && settings.password) {
    headers.append('Authorization', 'Basic ' + btoa(`${settings.username}:${settings.password}`));
  }

  const url = settings.url.replace(/\/$/, '') + settings.remotePath;
  const options = { method, headers };
  if (body) options.body = body;

  const response = await fetch(url, options);
  if (!response.ok && response.status !== 404) {
    throw new Error(`WebDAV 错误: ${response.status}`);
  }
  return response;
}

async function ensureRemotePath(settings) {
  try {
    await webdavRequest(settings, 'HEAD');
  } catch (e) {
    const pathParts = settings.remotePath.split('/').filter(p => p);
    let currentPath = settings.url.replace(/\/$/, '');
    for (let i = 0; i < pathParts.length - 1; i++) {
      currentPath += '/' + pathParts[i];
      try {
        await fetch(currentPath, {
          method: 'MKCOL',
          headers: new Headers({
            'Authorization': 'Basic ' + btoa(`${settings.username}:${settings.password}`)
          })
        });
      } catch (e) {}
    }
  }
}

// ---------- 消息处理（仅保留上传、下载、统计、清空）----------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const actions = {
    upload: async () => {
      const s = await getSettings();
      if (!s.url) throw new Error('未配置 WebDAV 地址');
      await ensureRemotePath(s);
      const data = await exportBookmarks();
      await webdavRequest(s, 'PUT', JSON.stringify(data));
      await chrome.storage.sync.set({ settings: { ...s, lastSync: Date.now() } });
    },
    download: async () => {
      const s = await getSettings();
      if (!s.url) throw new Error('未配置 WebDAV 地址');
      await ensureRemotePath(s);
      const resp = await webdavRequest(s, 'GET');
      if (resp.status === 404) throw new Error('远程文件不存在');
      const remoteData = await resp.json();
      await importBookmarks(remoteData);
      await chrome.storage.sync.set({ settings: { ...s, lastSync: Date.now() } });
    },
    getLocalBookmarkCount: async () => await getLocalBookmarkCount(),
    getRemoteBookmarkCount: async () => await getRemoteBookmarkCount(),
    clearAllBookmarks: async () => {
      await clearAllBookmarks();
      await chrome.storage.sync.set({ settings: { ...await getSettings(), lastSync: 0 } });
    }
  };

  const handler = actions[request.action];
  if (handler) {
    handler().then(result => sendResponse(result !== undefined ? result : { success: true }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }
});