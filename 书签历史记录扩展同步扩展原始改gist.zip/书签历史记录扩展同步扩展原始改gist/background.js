// 导入公共模块和同步模块
importScripts(
  'common.js',
  'webdav-client.js',
  'gist-client.js',
  'bookmarks-sync.js',
  'history-sync.js',
  'extensions-sync.js'
);

// ---------- 初始化 ----------
async function initialize() {
  // 设置扩展同步闹钟
  await self.ExtensionsSync.setupAlarm();
  console.log('[Background] 初始化完成');
}

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Background] 扩展安装/更新:', details.reason);
  await initialize();
  // 安装后立即执行一次自动备份（如果启用）
  const settings = await self.Common.getSyncStorage(self.Common.STORAGE_KEYS.EXTENSIONS_SETTINGS);
  if (settings?.autoBackupEnabled) {
    self.ExtensionsSync.performAutoBackup();
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await initialize();
});

// 闹钟监听
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'extensionsAutoBackup') {
    self.ExtensionsSync.performAutoBackup();
  }
});

// 存储变化监听（当扩展同步设置变化时重新配置闹钟）
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync') {
    if (changes[self.Common.STORAGE_KEYS.EXTENSIONS_SETTINGS]) {
      self.ExtensionsSync.setupAlarm();
    }
  }
});

// ---------- 消息路由 ----------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { action } = message;

  // 书签相关
  if (action === 'bookmarksUpload') {
    self.BookmarksSync.uploadBookmarks().then(sendResponse);
    return true;
  }
  if (action === 'bookmarksDownload') {
    self.BookmarksSync.downloadBookmarks().then(sendResponse);
    return true;
  }
  if (action === 'bookmarksClear') {
    self.BookmarksSync.clearAllBookmarks().then(sendResponse);
    return true;
  }
  if (action === 'getBookmarkStats') {
    self.BookmarksSync.getStats().then(sendResponse);
    return true;
  }

  // 历史记录相关
  if (action === 'incrementalBackup') {
    self.HistorySync.incrementalBackup().then(sendResponse);
    return true;
  }
  if (action === 'fullDownload') {
    self.HistorySync.fullDownload().then(sendResponse);
    return true;
  }
  if (action === 'fullBackup') {
    self.HistorySync.fullBackup().then(sendResponse);
    return true;
  }

  // 扩展同步相关
  if (action === 'extensionsBackup') {
    self.ExtensionsSync.backup().then(sendResponse);
    return true;
  }
  if (action === 'extensionsRestore') {
    self.ExtensionsSync.restore().then(sendResponse);
    return true;
  }
  if (action === 'getExtensionsStats') {
    self.ExtensionsSync.getStats().then(sendResponse);
    return true;
  }
  if (action === 'performAutoBackup') {
    self.ExtensionsSync.performAutoBackup().then(() => sendResponse({ success: true }));
    return true;
  }

  return false;
});