// history-sync.js - 历史记录同步（高性能优化版）
self.HistorySync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  /**
   * 初始化 WebDAV 客户端
   */
  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) {
      throw new Error('请先在设置中配置 WebDAV 参数');
    }
    return new WebDAVClient(url, user, pass);
  }

  /**
   * 获取远程备份文件并解析
   */
  async function getRemoteBackup(client) {
    const content = await client.getFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`);
    if (!content) return [];
    try {
      const data = JSON.parse(content);
      return Array.isArray(data) ? data : [];
    } catch (e) {
      console.error('解析远程备份失败:', e);
      return [];
    }
  }

  /**
   * 上传备份（移除 JSON 缩进以节省空间）
   */
  async function putRemoteBackup(client, records) {
    // 压缩 JSON 字符串，减少网络传输负担和 WebDAV 空间占用
    const jsonStr = JSON.stringify(records);
    return await client.putFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`, jsonStr);
  }

  /**
   * 分页获取本地历史记录
   */
  async function getHistorySince(startTime) {
    const allItems = [];
    let currentEnd = Date.now();
    const currentStart = startTime || 0;
    let hasMore = true;
    const MAX_RESULTS_PER_PAGE = 10000; // Chrome 单次查询上限
    let iteration = 0;
    const MAX_ITERATIONS = 100; // 防止无限循环安全阀

    while (hasMore && iteration++ < MAX_ITERATIONS) {
      const results = await new Promise((resolve) => {
        chrome.history.search({
          text: '',
          startTime: currentStart,
          endTime: currentEnd,
          maxResults: MAX_RESULTS_PER_PAGE,
        }, resolve);
      });

      if (results.length === 0) {
        hasMore = false;
        break;
      }

      // 只保留核心字段，减少存储体积
      const items = results.map(item => ({
        url: item.url,
        title: item.title || '',
        lastVisitTime: item.lastVisitTime,
        visitCount: item.visitCount
      }));
      allItems.push(...items);

      if (results.length === MAX_RESULTS_PER_PAGE) {
        // 以最后一条记录的时间作为下一页的终点
        const oldestTime = results[results.length - 1].lastVisitTime;
        currentEnd = oldestTime - 1;
        if (currentEnd <= currentStart) hasMore = false;
      } else {
        hasMore = false;
      }
    }

    // 利用 Map 按照 URL + 时间进行去重
    const uniqueMap = new Map();
    for (const item of allItems) {
      const key = `${item.url}|${item.lastVisitTime}`;
      if (!uniqueMap.has(key)) uniqueMap.set(key, item);
    }
    
    const uniqueItems = Array.from(uniqueMap.values());
    // 排序以保证合并逻辑的一致性
    return uniqueItems.sort((a, b) => a.lastVisitTime - b.lastVisitTime);
  }

  /**
   * 合并本地与远程记录
   */
  function mergeHistoryRecords(existing, incoming) {
    const map = new Map();
    // 填充现有数据
    existing.forEach(rec => map.set(`${rec.url}|${rec.lastVisitTime}`, rec));
    // 覆盖/补充新数据
    incoming.forEach(rec => map.set(`${rec.url}|${rec.lastVisitTime}`, rec));
    
    return Array.from(map.values()).sort((a, b) => a.lastVisitTime - b.lastVisitTime);
  }

  /**
   * 高性能并发限流写入历史记录
   */
  async function addHistoryWithLimit(records, concurrency = 5, delayMs = 50) {
    let addedCount = 0;
    let index = 0;

    async function worker() {
      while (index < records.length) {
        const i = index++; // 获取当前任务索引
        const record = records[i];
        
        // 过滤无效 URL (Chrome 不允许 addUrl 协议如 chrome://)
        if (!record || !record.url || !record.url.startsWith('http')) continue;

        await new Promise((resolve) => {
          chrome.history.addUrl({ url: record.url }, () => {
            if (!chrome.runtime.lastError) addedCount++;
            resolve();
          });
        });

        if (delayMs > 0) await new Promise(r => setTimeout(r, delayMs));
      }
    }

    // 启动多个并发 Worker
    const workers = Array(concurrency).fill().map(() => worker());
    await Promise.all(workers);
    return addedCount;
  }

  /**
   * 【增量备份】合并上传
   */
  async function incrementalBackup() {
    try {
      const lastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      const newHistory = await getHistorySince(lastSync);

      if (newHistory.length === 0) {
        showNotification('合并上传', '本地无新增记录');
        return { success: true, message: '无新增记录' };
      }

      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);
      const merged = mergeHistoryRecords(remoteRecords, newHistory);

      await putRemoteBackup(client, merged);
      
      // 更新同步时间为本次记录中最晚的时间点
      const maxTime = Math.max(...newHistory.map(r => r.lastVisitTime));
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);

      showNotification('合并上传完成', `新增 ${newHistory.length} 条，云端总计 ${merged.length} 条`);
      return { success: true, message: `已合并上传 ${newHistory.length} 条` };
    } catch (err) {
      showNotification('合并上传失败', err.message);
      return { success: false, message: err.message };
    }
  }

  /**
   * 【全量下载】将云端记录导入浏览器
   */
  async function fullDownload() {
    try {
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);

      if (remoteRecords.length === 0) {
        showNotification('全量下载', '远程无数据');
        return { success: false, message: '无远程数据' };
      }

      // 注意：chrome.history.addUrl 无法自定义时间戳，所有记录导入后会显示为“刚刚”
      const addedCount = await addHistoryWithLimit(remoteRecords, 5, 30);
      
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, Date.now());
      showNotification('全量下载完成', `成功导入 ${addedCount} 条记录`);
      return { success: true, message: `导入了 ${addedCount} 条` };
    } catch (err) {
      showNotification('全量下载失败', err.message);
      return { success: false, message: err.message };
    }
  }

  /**
   * 【全量上传】覆盖云端数据
   */
  async function fullBackup() {
    try {
      const allHistory = await getHistorySince(0);
      const totalCount = allHistory.length;

      if (totalCount > 40000) {
        showNotification('全量上传', `正在备份 ${totalCount} 条，请勿关闭浏览器`);
      }

      const client = await getWebDAVClient();
      await putRemoteBackup(client, allHistory);

      const maxTime = allHistory.length > 0 
        ? Math.max(...allHistory.map(r => r.lastVisitTime)) 
        : Date.now();
      
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);
      showNotification('全量上传完成', `已备份全部 ${totalCount} 条历史`);
      return { success: true, message: `全量上传 ${totalCount} 条` };
    } catch (err) {
      showNotification('全量上传失败', err.message);
      return { success: false, message: err.message };
    }
  }

  return {
    incrementalBackup,
    fullDownload,
    fullBackup
  };
})();