// common.js - 公共工具函数和存储键常量
self.Common = (function() {
  const STORAGE_KEYS = {
    // WebDAV 通用配置（存储在 chrome.storage.local）
    WEBDAV_URL: 'webdav_url',
    WEBDAV_USER: 'webdav_user',
    WEBDAV_PASS: 'webdav_pass',

    // 历史记录专用（存储在 chrome.storage.local）
    LAST_SYNC_TIME: 'last_sync_time',
    HISTORY_BACKUP_FILE: 'history_backup.json',

    // 书签专用（存储在 chrome.storage.sync 和 chrome.storage.local）
    BOOKMARKS_SETTINGS: 'bookmarks_settings',   // sync: { remotePath, swapBookmarkMobile, lastSync }
    BOOKMARKS_META: 'bookmarksMeta',            // local: 元数据（GUID映射等）

    // 扩展同步专用（存储在 chrome.storage.sync）
    EXTENSIONS_SETTINGS: 'extensions_settings', // { deviceSuffix, autoBackupEnabled, autoBackupInterval, notifyOnBackup, lastBackupTime, lastSyncStatus }

    // GitHub Gist 专用（存储在 chrome.storage.local）
    GIST_TOKEN: 'gist_token',
    GIST_ID: 'gist_id',
    GIST_FILENAME: 'gist_filename',
    BOOKMARKS_SYNC_BACKEND: 'bookmarks_sync_backend' // 'webdav' 或 'gist'
  };

  /**
   * 从 chrome.storage.local 获取值
   */
  async function getStorage(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }

  /**
   * 保存值到 chrome.storage.local
   */
  async function setStorage(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  /**
   * 从 chrome.storage.sync 获取值
   */
  async function getSyncStorage(key) {
    const result = await chrome.storage.sync.get(key);
    return result[key];
  }

  /**
   * 保存值到 chrome.storage.sync
   */
  async function setSyncStorage(key, value) {
    await chrome.storage.sync.set({ [key]: value });
  }

  /**
   * 显示系统通知
   */
  function showNotification(title, message, type = 'basic') {
    chrome.notifications.create({
      type: type,
      iconUrl: 'icons/icon48.png',
      title: title,
      message: message,
      priority: 2
    }).catch(() => {});
  }

  return {
    STORAGE_KEYS,
    getStorage,
    setStorage,
    getSyncStorage,
    setSyncStorage,
    showNotification
  };
})();