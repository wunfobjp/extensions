// 选项页逻辑
const { STORAGE_KEYS, getStorage, setStorage, getSyncStorage, setSyncStorage, showNotification } = self.Common;
const WebDAVClient = self.WebDAVClient;

// DOM 元素 - WebDAV
const urlInput = document.getElementById('webdavUrl');
const userInput = document.getElementById('webdavUser');
const passInput = document.getElementById('webdavPass');
const testBtn = document.getElementById('testBtn');
const saveWebDAVBtn = document.getElementById('saveWebDAVBtn');
const connectionStatusSpan = document.getElementById('connectionStatus');

// DOM 元素 - 书签
const bookmarksRemotePathInput = document.getElementById('bookmarksRemotePath');
const swapBookmarkMobileCheck = document.getElementById('swapBookmarkMobile');

// DOM 元素 - 扩展同步
const deviceSuffixInput = document.getElementById('deviceSuffix');
const autoBackupEnabledCheck = document.getElementById('autoBackupEnabled');
const autoBackupIntervalInput = document.getElementById('autoBackupInterval');
const notifyOnBackupCheck = document.getElementById('notifyOnBackup');
const saveExtensionsBtn = document.getElementById('saveExtensionsBtn');

// 默认设置
const DEFAULT_BOOKMARKS_SETTINGS = {
  remotePath: '/bookmarks.json',
  swapBookmarkMobile: false,
  lastSync: 0
};

const DEFAULT_EXTENSIONS_SETTINGS = {
  deviceSuffix: 'default',
  autoBackupEnabled: false,
  autoBackupInterval: 24,
  notifyOnBackup: false,
  lastBackupTime: 0,
  lastSyncStatus: null
};

// 加载所有设置
async function loadSettings() {
  // WebDAV 通用配置
  const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
  const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
  const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
  if (url) urlInput.value = url;
  if (user) userInput.value = user;
  if (pass) passInput.value = pass;

  // 书签设置
  const bookmarksSettings = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS) || DEFAULT_BOOKMARKS_SETTINGS;
  bookmarksRemotePathInput.value = bookmarksSettings.remotePath || '/bookmarks.json';
  swapBookmarkMobileCheck.checked = bookmarksSettings.swapBookmarkMobile || false;

  // 扩展同步设置
  const extSettings = await getSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS) || DEFAULT_EXTENSIONS_SETTINGS;
  deviceSuffixInput.value = extSettings.deviceSuffix || 'default';
  autoBackupEnabledCheck.checked = extSettings.autoBackupEnabled || false;
  autoBackupIntervalInput.value = extSettings.autoBackupInterval || 24;
  notifyOnBackupCheck.checked = extSettings.notifyOnBackup || false;

  await checkConnectionStatus();
}

// 保存 WebDAV 通用配置
async function saveWebDAVSettings() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    showNotification('设置', '请填写完整的 WebDAV 信息');
    return false;
  }
  await setStorage(STORAGE_KEYS.WEBDAV_URL, url);
  await setStorage(STORAGE_KEYS.WEBDAV_USER, user);
  await setStorage(STORAGE_KEYS.WEBDAV_PASS, pass);
  showNotification('设置', 'WebDAV 配置已保存');
  return true;
}

// 保存书签设置
async function saveBookmarksSettings() {
  const current = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS) || DEFAULT_BOOKMARKS_SETTINGS;
  const newSettings = {
    ...current,
    remotePath: bookmarksRemotePathInput.value.trim() || '/bookmarks.json',
    swapBookmarkMobile: swapBookmarkMobileCheck.checked
  };
  await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, newSettings);
}

// 保存扩展同步设置
async function saveExtensionsSettings() {
  const current = await getSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS) || DEFAULT_EXTENSIONS_SETTINGS;
  const newSettings = {
    ...current,
    deviceSuffix: deviceSuffixInput.value.trim() || 'default',
    autoBackupEnabled: autoBackupEnabledCheck.checked,
    autoBackupInterval: parseInt(autoBackupIntervalInput.value, 10) || 24,
    notifyOnBackup: notifyOnBackupCheck.checked
  };
  await setSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS, newSettings);
  showNotification('设置', '扩展同步设置已保存');
}

// 连接状态检测
async function checkConnectionStatus() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    connectionStatusSpan.textContent = '未连接';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
  const client = new WebDAVClient(url, user, pass);
  try {
    const ok = await client.testConnection('test_connection.tmp');
    if (ok) {
      connectionStatusSpan.textContent = '已连接';
      connectionStatusSpan.className = 'connected';
      return true;
    } else {
      connectionStatusSpan.textContent = '连接失败';
      connectionStatusSpan.className = 'disconnected';
      return false;
    }
  } catch (e) {
    connectionStatusSpan.textContent = '连接失败';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
}

// 事件绑定
testBtn.addEventListener('click', async () => {
  if (!(await saveWebDAVSettings())) return;
  await saveBookmarksSettings();
  await saveExtensionsSettings();
  connectionStatusSpan.textContent = '测试中...';
  const connected = await checkConnectionStatus();
  showNotification('WebDAV', connected ? '连接成功！' : '连接失败，请检查配置');
});

saveWebDAVBtn.addEventListener('click', async () => {
  await saveWebDAVSettings();
  await checkConnectionStatus();
});

saveExtensionsBtn.addEventListener('click', saveExtensionsSettings);

// 书签设置变化自动保存（简单处理）
bookmarksRemotePathInput.addEventListener('change', saveBookmarksSettings);
swapBookmarkMobileCheck.addEventListener('change', saveBookmarksSettings);

// 初始化
loadSettings();