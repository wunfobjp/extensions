const btnInc = document.getElementById('btnIncremental');
const btnDown = document.getElementById('btnFullDownload');
const btnFull = document.getElementById('btnFullBackup');
const btnSettings = document.getElementById('btnSettings');
const statusDiv = document.getElementById('status');

function setStatus(text, isError = false) {
  statusDiv.textContent = text;
  statusDiv.style.color = isError ? '#d32f2f' : '#2e7d32';
  setTimeout(() => {
    if (statusDiv.textContent === text) {
      statusDiv.style.color = '#555';
      statusDiv.textContent = '就绪';
    }
  }, 3000);
}

async function sendMessage(action, loadingText) {
  if (!chrome.runtime?.id) {
    setStatus('扩展已失效，请重新打开弹窗', true);
    return { success: false, message: '扩展上下文失效' };
  }
  setStatus(loadingText);
  try {
    const result = await chrome.runtime.sendMessage({ action });
    setStatus(result.message, !result.success);
    return result;
  } catch (err) {
    if (err.message.includes('Extension context invalidated')) {
      setStatus('扩展已更新，请关闭弹窗后重新打开', true);
    } else {
      setStatus('操作失败: ' + err.message, true);
    }
    return { success: false, message: err.message };
  }
}

btnInc.addEventListener('click', () => sendMessage('incrementalBackup', '合并上传中...'));
btnDown.addEventListener('click', () => sendMessage('fullDownload', '全量下载中...'));
btnFull.addEventListener('click', () => sendMessage('fullBackup', '全量上传中...'));
btnSettings.addEventListener('click', () => {
  if (chrome.runtime?.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    setStatus('无法打开设置页', true);
  }
});