// options.js
const { STORAGE_KEYS, getStorage, setStorage, showNotification } = window.Common;
const WebDAVClient = window.WebDAVClient;

const urlInput = document.getElementById('webdavUrl');
const userInput = document.getElementById('webdavUser');
const passInput = document.getElementById('webdavPass');
const testBtn = document.getElementById('testBtn');
const fullUploadBtn = document.getElementById('fullUploadBtn');
const fullDownloadBtn = document.getElementById('fullDownloadBtn');
const mergeUploadBtn = document.getElementById('mergeUploadBtn');
const connectionStatusSpan = document.getElementById('connectionStatus');

async function loadSettings() {
  const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
  const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
  const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
  if (url) urlInput.value = url;
  if (user) userInput.value = user;
  if (pass) passInput.value = pass;
  await checkConnectionStatus();
}

async function saveSettings() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    showNotification('WebDAV', '请填写完整信息');
    return false;
  }
  await setStorage(STORAGE_KEYS.WEBDAV_URL, url);
  await setStorage(STORAGE_KEYS.WEBDAV_USER, user);
  await setStorage(STORAGE_KEYS.WEBDAV_PASS, pass);
  return true;
}

async function checkConnectionStatus() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    connectionStatusSpan.textContent = '未连接';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
  const client = new WebDAVClient(url, user, pass);
  try {
    const ok = await client.testConnection(STORAGE_KEYS.BACKUP_FILE);
    if (ok) {
      connectionStatusSpan.textContent = '已连接';
      connectionStatusSpan.className = 'connected';
      return true;
    } else {
      connectionStatusSpan.textContent = '连接失败';
      connectionStatusSpan.className = 'disconnected';
      return false;
    }
  } catch (e) {
    console.error(e);
    connectionStatusSpan.textContent = '连接失败';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
}

testBtn.addEventListener('click', async () => {
  const saved = await saveSettings();
  if (!saved) return;
  connectionStatusSpan.textContent = '测试中...';
  connectionStatusSpan.className = '';
  const connected = await checkConnectionStatus();
  if (connected) {
    showNotification('WebDAV', '连接成功！', 'basic');
  } else {
    showNotification('WebDAV', '连接失败，请检查服务器地址、用户名和密码', 'basic');
  }
});

fullUploadBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  const connected = await checkConnectionStatus();
  if (!connected) {
    showNotification('全量上传', '请先成功连接WebDAV');
    return;
  }
  fullUploadBtn.disabled = true;
  fullUploadBtn.textContent = '上传中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'fullBackup' });
    showNotification('全量上传', result.message);
    if (result.success) await checkConnectionStatus();
  } finally {
    fullUploadBtn.disabled = false;
    fullUploadBtn.textContent = '全量上传';
  }
});

fullDownloadBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  const connected = await checkConnectionStatus();
  if (!connected) {
    showNotification('全量下载', '请先成功连接WebDAV');
    return;
  }
  fullDownloadBtn.disabled = true;
  fullDownloadBtn.textContent = '下载中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'fullDownload' });
    showNotification('全量下载', result.message);
    if (result.success) await checkConnectionStatus();
  } finally {
    fullDownloadBtn.disabled = false;
    fullDownloadBtn.textContent = '全量下载';
  }
});

mergeUploadBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  const connected = await checkConnectionStatus();
  if (!connected) {
    showNotification('合并上传', '请先成功连接WebDAV');
    return;
  }
  mergeUploadBtn.disabled = true;
  mergeUploadBtn.textContent = '合并中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'incrementalBackup' });
    showNotification('合并上传', result.message);
    if (result.success) await checkConnectionStatus();
  } finally {
    mergeUploadBtn.disabled = false;
    mergeUploadBtn.textContent = '合并上传';
  }
});

loadSettings();