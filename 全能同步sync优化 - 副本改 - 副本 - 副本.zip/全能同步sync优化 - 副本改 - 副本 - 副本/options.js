// 选项页逻辑
const { STORAGE_KEYS, getStorage, setStorage, getSyncStorage, setSyncStorage, showNotification } = self.Common;
const WebDAVClient = self.WebDAVClient;
const GistClient = self.GistClient;

// DOM 元素 - WebDAV
const urlInput = document.getElementById('webdavUrl');
const userInput = document.getElementById('webdavUser');
const passInput = document.getElementById('webdavPass');
const testBtn = document.getElementById('testBtn');
const saveWebDAVBtn = document.getElementById('saveWebDAVBtn');
const connectionStatusSpan = document.getElementById('connectionStatus');

// DOM 元素 - 书签
const bookmarksRemotePathInput = document.getElementById('bookmarksRemotePath');
const swapBookmarkMobileCheck = document.getElementById('swapBookmarkMobile');
const autoSyncBookmarksCheck = document.getElementById('autoSyncBookmarks');
const autoSyncBookmarksIntervalInput = document.getElementById('autoSyncBookmarksInterval');

// DOM 元素 - Gist
const gistTokenInput = document.getElementById('gistToken');
const gistIdInput = document.getElementById('gistId');
const gistFilenameInput = document.getElementById('gistFilename');
const useGistForBookmarksCheck = document.getElementById('useGistForBookmarks');
const testGistBtn = document.getElementById('testGistBtn');
const saveGistBtn = document.getElementById('saveGistBtn');
const gistStatusSpan = document.getElementById('gistStatus');

// DOM 元素 - 扩展同步
const deviceSuffixInput = document.getElementById('deviceSuffix');
const autoBackupEnabledCheck = document.getElementById('autoBackupEnabled');
const autoBackupIntervalInput = document.getElementById('autoBackupInterval');
const notifyOnBackupCheck = document.getElementById('notifyOnBackup');
const saveExtensionsBtn = document.getElementById('saveExtensionsBtn');

// DOM 元素 - 历史自动同步（分钟）
const autoSyncHistoryEnabledCheck = document.getElementById('autoSyncHistoryEnabled');
const autoSyncHistoryIntervalInput = document.getElementById('autoSyncHistoryInterval');
const saveHistoryAutoSyncBtn = document.getElementById('saveHistoryAutoSyncBtn');

// 默认设置
const DEFAULT_BOOKMARKS_SETTINGS = {
  remotePath: '/bookmarks.json',
  swapBookmarkMobile: false,
  lastSync: 0
};

const DEFAULT_EXTENSIONS_SETTINGS = {
  deviceSuffix: 'default',
  autoBackupEnabled: false,
  autoBackupInterval: 24,
  notifyOnBackup: false,
  lastBackupTime: 0,
  lastSyncStatus: null
};

const DEFAULT_HISTORY_AUTO_SYNC_SETTINGS = {
  enabled: false,
  intervalMinutes: 60   // 默认 60 分钟
};

// 加载所有设置
async function loadSettings() {
  // WebDAV 通用配置
  const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
  const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
  const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
  if (url) urlInput.value = url;
  if (user) userInput.value = user;
  if (pass) passInput.value = pass;

  // 书签设置
  const bookmarksSettings = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS) || DEFAULT_BOOKMARKS_SETTINGS;
  bookmarksRemotePathInput.value = bookmarksSettings.remotePath || '/bookmarks.json';
  swapBookmarkMobileCheck.checked = bookmarksSettings.swapBookmarkMobile || false;

  const autoSync = await getStorage(STORAGE_KEYS.BOOKMARKS_AUTO_SYNC);
  autoSyncBookmarksCheck.checked = !!autoSync;
  const interval = await getStorage(STORAGE_KEYS.BOOKMARKS_AUTO_SYNC_INTERVAL);
  autoSyncBookmarksIntervalInput.value = interval !== undefined ? interval : 5;

  // Gist 配置
  const gistToken = await getStorage(STORAGE_KEYS.GIST_TOKEN);
  const gistId = await getStorage(STORAGE_KEYS.GIST_ID);
  const gistFilename = await getStorage(STORAGE_KEYS.GIST_FILENAME);
  const bookmarksBackend = await getStorage(STORAGE_KEYS.BOOKMARKS_SYNC_BACKEND);
  if (gistToken) gistTokenInput.value = gistToken;
  if (gistId) gistIdInput.value = gistId;
  if (gistFilename) gistFilenameInput.value = gistFilename;
  useGistForBookmarksCheck.checked = (bookmarksBackend === 'gist');

  // 扩展同步设置
  const extSettings = await getSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS) || DEFAULT_EXTENSIONS_SETTINGS;
  deviceSuffixInput.value = extSettings.deviceSuffix || 'default';
  autoBackupEnabledCheck.checked = extSettings.autoBackupEnabled || false;
  autoBackupIntervalInput.value = extSettings.autoBackupInterval || 24;
  notifyOnBackupCheck.checked = extSettings.notifyOnBackup || false;

  // 历史自动同步设置（处理旧版 intervalHours 迁移）
  let historyAutoSettings = await getSyncStorage(STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS);
  if (historyAutoSettings && typeof historyAutoSettings.intervalHours === 'number') {
    // 迁移旧设置到分钟
    historyAutoSettings.intervalMinutes = historyAutoSettings.intervalHours * 60;
    delete historyAutoSettings.intervalHours;
    await setSyncStorage(STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS, historyAutoSettings);
  }
  historyAutoSettings = historyAutoSettings || DEFAULT_HISTORY_AUTO_SYNC_SETTINGS;
  autoSyncHistoryEnabledCheck.checked = historyAutoSettings.enabled || false;
  autoSyncHistoryIntervalInput.value = historyAutoSettings.intervalMinutes || 60;

  await checkConnectionStatus();
}

// 保存 WebDAV 通用配置
async function saveWebDAVSettings() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    showNotification('设置', '请填写完整的 WebDAV 信息');
    return false;
  }
  await setStorage(STORAGE_KEYS.WEBDAV_URL, url);
  await setStorage(STORAGE_KEYS.WEBDAV_USER, user);
  await setStorage(STORAGE_KEYS.WEBDAV_PASS, pass);
  showNotification('设置', 'WebDAV 配置已保存');
  return true;
}

// 保存书签设置
async function saveBookmarksSettings() {
  const current = await getSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS) || DEFAULT_BOOKMARKS_SETTINGS;
  const newSettings = {
    ...current,
    remotePath: bookmarksRemotePathInput.value.trim() || '/bookmarks.json',
    swapBookmarkMobile: swapBookmarkMobileCheck.checked
  };
  await setSyncStorage(STORAGE_KEYS.BOOKMARKS_SETTINGS, newSettings);
}

async function saveAutoSyncSetting() {
  await setStorage(STORAGE_KEYS.BOOKMARKS_AUTO_SYNC, autoSyncBookmarksCheck.checked);
  const interval = parseInt(autoSyncBookmarksIntervalInput.value, 10) || 0;
  await setStorage(STORAGE_KEYS.BOOKMARKS_AUTO_SYNC_INTERVAL, interval);
  showNotification('设置', `书签自动同步已${autoSyncBookmarksCheck.checked ? '启用' : '禁用'}，间隔 ${interval} 分钟`);
}

// 保存 Gist 配置
async function saveGistSettings() {
  const token = gistTokenInput.value.trim();
  const id = gistIdInput.value.trim();
  const filename = gistFilenameInput.value.trim() || 'bookmarks.json';
  if (!token || !id) {
    showNotification('设置', '请填写 Token 和 Gist ID');
    return;
  }
  await setStorage(STORAGE_KEYS.GIST_TOKEN, token);
  await setStorage(STORAGE_KEYS.GIST_ID, id);
  await setStorage(STORAGE_KEYS.GIST_FILENAME, filename);
  
  const backend = useGistForBookmarksCheck.checked ? 'gist' : 'webdav';
  await setStorage(STORAGE_KEYS.BOOKMARKS_SYNC_BACKEND, backend);
  
  showNotification('设置', `Gist 配置已保存，书签后端：${backend}`);
}

async function testGistConnection() {
  const token = gistTokenInput.value.trim();
  const id = gistIdInput.value.trim();
  if (!token || !id) {
    gistStatusSpan.textContent = '请填写 Token 和 Gist ID';
    gistStatusSpan.className = 'disconnected';
    return;
  }
  gistStatusSpan.textContent = '测试中...';
  const client = new GistClient(token);
  const ok = await client.testConnection(id);
  if (ok) {
    gistStatusSpan.textContent = '已连接';
    gistStatusSpan.className = 'connected';
    showNotification('Gist', '连接成功！');
  } else {
    gistStatusSpan.textContent = '连接失败';
    gistStatusSpan.className = 'disconnected';
    showNotification('Gist', '连接失败，请检查 Token 和 Gist ID');
  }
}

// 保存扩展同步设置
async function saveExtensionsSettings() {
  const current = await getSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS) || DEFAULT_EXTENSIONS_SETTINGS;
  const newSettings = {
    ...current,
    deviceSuffix: deviceSuffixInput.value.trim() || 'default',
    autoBackupEnabled: autoBackupEnabledCheck.checked,
    autoBackupInterval: parseInt(autoBackupIntervalInput.value, 10) || 24,
    notifyOnBackup: notifyOnBackupCheck.checked
  };
  await setSyncStorage(STORAGE_KEYS.EXTENSIONS_SETTINGS, newSettings);
  showNotification('设置', '扩展同步设置已保存');
}

// 保存历史自动同步设置（分钟）
async function saveHistoryAutoSyncSettings() {
  const newSettings = {
    enabled: autoSyncHistoryEnabledCheck.checked,
    intervalMinutes: parseInt(autoSyncHistoryIntervalInput.value, 10) || 60
  };
  await setSyncStorage(STORAGE_KEYS.HISTORY_AUTO_SYNC_SETTINGS, newSettings);
  showNotification('设置', `历史自动同步已${newSettings.enabled ? '启用，间隔 ' + newSettings.intervalMinutes + ' 分钟' : '禁用'}`);
}

// 连接状态检测（WebDAV）
async function checkConnectionStatus() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    connectionStatusSpan.textContent = '未连接';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
  const client = new WebDAVClient(url, user, pass);
  try {
    const ok = await client.testConnection('test_connection.tmp');
    if (ok) {
      connectionStatusSpan.textContent = '已连接';
      connectionStatusSpan.className = 'connected';
      return true;
    } else {
      connectionStatusSpan.textContent = '连接失败';
      connectionStatusSpan.className = 'disconnected';
      return false;
    }
  } catch (e) {
    connectionStatusSpan.textContent = '连接失败';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
}

// 事件绑定
testBtn.addEventListener('click', async () => {
  if (!(await saveWebDAVSettings())) return;
  await saveBookmarksSettings();
  await saveExtensionsSettings();
  await saveAutoSyncSetting();
  connectionStatusSpan.textContent = '测试中...';
  const connected = await checkConnectionStatus();
  showNotification('WebDAV', connected ? '连接成功！' : '连接失败，请检查配置');
});

saveWebDAVBtn.addEventListener('click', async () => {
  await saveWebDAVSettings();
  await checkConnectionStatus();
});

saveExtensionsBtn.addEventListener('click', saveExtensionsSettings);

bookmarksRemotePathInput.addEventListener('change', saveBookmarksSettings);
swapBookmarkMobileCheck.addEventListener('change', saveBookmarksSettings);
autoSyncBookmarksCheck.addEventListener('change', saveAutoSyncSetting);
autoSyncBookmarksIntervalInput.addEventListener('change', saveAutoSyncSetting);

saveGistBtn.addEventListener('click', saveGistSettings);
testGistBtn.addEventListener('click', testGistConnection);
useGistForBookmarksCheck.addEventListener('change', async () => {
  const backend = useGistForBookmarksCheck.checked ? 'gist' : 'webdav';
  await setStorage(STORAGE_KEYS.BOOKMARKS_SYNC_BACKEND, backend);
  showNotification('设置', `书签同步后端已切换为 ${backend}`);
});

// 历史自动同步设置保存按钮
saveHistoryAutoSyncBtn.addEventListener('click', saveHistoryAutoSyncSettings);

// 初始化
loadSettings();