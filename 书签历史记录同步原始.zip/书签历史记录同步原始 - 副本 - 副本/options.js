// options.js - 完整版（已移除清空书签功能）
const { STORAGE_KEYS, getStorage, setStorage, showNotification } = window.Common;
const WebDAVClient = window.WebDAVClient;

const urlInput = document.getElementById('webdavUrl');
const userInput = document.getElementById('webdavUser');
const passInput = document.getElementById('webdavPass');
const testBtn = document.getElementById('testBtn');
const fullUploadBtn = document.getElementById('fullUploadBtn');
const fullDownloadBtn = document.getElementById('fullDownloadBtn');
const mergeUploadBtn = document.getElementById('mergeUploadBtn');
const backupBookmarksBtn = document.getElementById('backupBookmarksBtn');
const restoreBookmarksBtn = document.getElementById('restoreBookmarksBtn');
const refreshStatsBtn = document.getElementById('refreshStatsBtn');
const connectionStatusSpan = document.getElementById('connectionStatus');

const localHistoryCountSpan = document.getElementById('localHistoryCount');
const remoteHistoryCountSpan = document.getElementById('remoteHistoryCount');
const localBookmarkCountSpan = document.getElementById('localBookmarkCount');
const remoteBookmarkCountSpan = document.getElementById('remoteBookmarkCount');

async function loadSettings() {
  const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
  const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
  const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
  if (url) urlInput.value = url;
  if (user) userInput.value = user;
  if (pass) passInput.value = pass;
  await checkConnectionStatus();
}

async function saveSettings() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    showNotification('WebDAV', '请填写完整信息');
    return false;
  }
  await setStorage(STORAGE_KEYS.WEBDAV_URL, url);
  await setStorage(STORAGE_KEYS.WEBDAV_USER, user);
  await setStorage(STORAGE_KEYS.WEBDAV_PASS, pass);
  return true;
}

async function checkConnectionStatus() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) {
    connectionStatusSpan.textContent = '未连接';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
  const client = new WebDAVClient(url, user, pass);
  try {
    const ok = await client.testConnection(STORAGE_KEYS.HISTORY_BACKUP_FILE);
    if (ok) {
      connectionStatusSpan.textContent = '已连接';
      connectionStatusSpan.className = 'connected';
      return true;
    } else {
      connectionStatusSpan.textContent = '连接失败';
      connectionStatusSpan.className = 'disconnected';
      return false;
    }
  } catch (e) {
    console.error(e);
    connectionStatusSpan.textContent = '连接失败';
    connectionStatusSpan.className = 'disconnected';
    return false;
  }
}

async function countLocalHistory() {
  return new Promise((resolve) => {
    chrome.history.search({
      text: '',
      startTime: 0,
      endTime: Date.now(),
      maxResults: 1000000
    }, (results) => {
      resolve(results.length);
    });
  });
}

async function countRemoteHistory() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) return null;
  const client = new WebDAVClient(url, user, pass);
  try {
    const content = await client.getFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`);
    if (!content) return 0;
    const data = JSON.parse(content);
    return Array.isArray(data) ? data.length : 0;
  } catch (e) {
    console.error('读取远程历史失败', e);
    return null;
  }
}

async function countLocalBookmarks() {
  if (!chrome.bookmarks) {
    console.error('chrome.bookmarks API 不可用，请检查权限');
    localBookmarkCountSpan.textContent = 'API不可用';
    return 0;
  }
  return new Promise((resolve) => {
    chrome.bookmarks.getTree((tree) => {
      let count = 0;
      function traverse(node) {
        if (node.url) count++;
        if (node.children) {
          for (const child of node.children) traverse(child);
        }
      }
      for (const root of tree) traverse(root);
      resolve(count);
    });
  });
}

function countBookmarksInData(data) {
  let count = 0;
  function traverse(node) {
    if (node.url) count++;
    if (node.children && Array.isArray(node.children)) {
      for (const child of node.children) traverse(child);
    }
  }
  if (Array.isArray(data)) {
    for (const item of data) traverse(item);
  }
  return count;
}

async function countRemoteBookmarks() {
  const url = urlInput.value.trim();
  const user = userInput.value.trim();
  const pass = passInput.value.trim();
  if (!url || !user || !pass) return null;
  const client = new WebDAVClient(url, user, pass);
  try {
    const content = await client.getFile(`/${STORAGE_KEYS.BOOKMARKS_BACKUP_FILE}`);
    if (!content) return 0;
    const data = JSON.parse(content);
    return countBookmarksInData(data);
  } catch (e) {
    console.error('读取远程书签失败', e);
    return null;
  }
}

async function refreshStats() {
  const localHistory = await countLocalHistory();
  localHistoryCountSpan.textContent = localHistory;
  const localBookmarks = await countLocalBookmarks();
  localBookmarkCountSpan.textContent = localBookmarks;

  const connected = await checkConnectionStatus();
  if (connected) {
    const remoteHistory = await countRemoteHistory();
    remoteHistoryCountSpan.textContent = (remoteHistory !== null) ? remoteHistory : '读取失败';
    const remoteBookmarks = await countRemoteBookmarks();
    remoteBookmarkCountSpan.textContent = (remoteBookmarks !== null) ? remoteBookmarks : '读取失败';
  } else {
    remoteHistoryCountSpan.textContent = '未连接';
    remoteBookmarkCountSpan.textContent = '未连接';
  }
}

testBtn.addEventListener('click', async () => {
  const saved = await saveSettings();
  if (!saved) return;
  connectionStatusSpan.textContent = '测试中...';
  connectionStatusSpan.className = '';
  const connected = await checkConnectionStatus();
  if (connected) {
    showNotification('WebDAV', '连接成功！', 'basic');
    await refreshStats();
  } else {
    showNotification('WebDAV', '连接失败，请检查服务器地址、用户名和密码', 'basic');
  }
});

fullUploadBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  if (!await checkConnectionStatus()) {
    showNotification('全量上传', '请先成功连接WebDAV');
    return;
  }
  fullUploadBtn.disabled = true;
  fullUploadBtn.textContent = '上传中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'fullBackup' });
    showNotification('全量上传', result.message);
    if (result.success) await refreshStats();
  } finally {
    fullUploadBtn.disabled = false;
    fullUploadBtn.textContent = '全量上传';
  }
});

fullDownloadBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  if (!await checkConnectionStatus()) {
    showNotification('全量下载', '请先成功连接WebDAV');
    return;
  }
  fullDownloadBtn.disabled = true;
  fullDownloadBtn.textContent = '下载中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'fullDownload' });
    showNotification('全量下载', result.message);
    if (result.success) await refreshStats();
  } finally {
    fullDownloadBtn.disabled = false;
    fullDownloadBtn.textContent = '全量下载';
  }
});

mergeUploadBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  if (!await checkConnectionStatus()) {
    showNotification('合并上传', '请先成功连接WebDAV');
    return;
  }
  mergeUploadBtn.disabled = true;
  mergeUploadBtn.textContent = '合并中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'incrementalBackup' });
    showNotification('合并上传', result.message);
    if (result.success) await refreshStats();
  } finally {
    mergeUploadBtn.disabled = false;
    mergeUploadBtn.textContent = '合并上传';
  }
});

backupBookmarksBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  if (!await checkConnectionStatus()) {
    showNotification('书签备份', '请先成功连接WebDAV');
    return;
  }
  backupBookmarksBtn.disabled = true;
  backupBookmarksBtn.textContent = '备份中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'backupBookmarks' });
    showNotification('书签备份', result.message);
    if (result.success) await refreshStats();
  } finally {
    backupBookmarksBtn.disabled = false;
    backupBookmarksBtn.textContent = '备份书签';
  }
});

restoreBookmarksBtn.addEventListener('click', async () => {
  if (!await saveSettings()) return;
  if (!await checkConnectionStatus()) {
    showNotification('书签恢复', '请先成功连接WebDAV');
    return;
  }
  restoreBookmarksBtn.disabled = true;
  restoreBookmarksBtn.textContent = '恢复中...';
  try {
    const result = await chrome.runtime.sendMessage({ action: 'restoreBookmarks' });
    showNotification('书签恢复', result.message);
    if (result.success) await refreshStats();
  } finally {
    restoreBookmarksBtn.disabled = false;
    restoreBookmarksBtn.textContent = '恢复书签';
  }
});

refreshStatsBtn.addEventListener('click', async () => {
  refreshStatsBtn.disabled = true;
  refreshStatsBtn.textContent = '刷新中...';
  await refreshStats();
  refreshStatsBtn.disabled = false;
  refreshStatsBtn.textContent = '刷新统计';
});

loadSettings().then(() => refreshStats());