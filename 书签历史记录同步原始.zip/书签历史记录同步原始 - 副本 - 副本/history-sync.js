// history-sync.js - 一次性获取所有历史记录（修复undefined文件错误）
self.HistorySync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) {
      throw new Error('请先配置WebDAV参数');
    }
    return new WebDAVClient(url, user, pass);
  }

  async function getRemoteBackup(client) {
    const content = await client.getFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`);
    if (!content) return [];
    try {
      const data = JSON.parse(content);
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }

  async function putRemoteBackup(client, records) {
    const jsonStr = JSON.stringify(records, null, 2);
    return await client.putFile(`/${STORAGE_KEYS.HISTORY_BACKUP_FILE}`, jsonStr);
  }

  async function getHistorySince(startTime) {
    const allItems = await new Promise((resolve) => {
      chrome.history.search({
        text: '',
        startTime: startTime || 0,
        endTime: Date.now(),
        maxResults: 1000000
      }, resolve);
    });
    const items = allItems.map(item => ({
      url: item.url,
      title: item.title || '',
      lastVisitTime: item.lastVisitTime,
      visitCount: item.visitCount,
      typedCount: item.typedCount || 0,
      id: item.id
    }));
    const uniqueMap = new Map();
    for (const item of items) {
      const key = `${item.url}|${item.lastVisitTime}`;
      if (!uniqueMap.has(key)) uniqueMap.set(key, item);
    }
    const uniqueItems = Array.from(uniqueMap.values());
    uniqueItems.sort((a, b) => a.lastVisitTime - b.lastVisitTime);
    return uniqueItems;
  }

  function mergeHistoryRecords(existing, incoming) {
    const map = new Map();
    for (const rec of existing) {
      const key = `${rec.url}|${rec.lastVisitTime}`;
      map.set(key, rec);
    }
    for (const rec of incoming) {
      const key = `${rec.url}|${rec.lastVisitTime}`;
      if (!map.has(key)) map.set(key, rec);
    }
    const merged = Array.from(map.values());
    merged.sort((a, b) => a.lastVisitTime - b.lastVisitTime);
    return merged;
  }

  async function incrementalBackup() {
    try {
      const lastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      const newHistory = await getHistorySince(lastSync);
      if (newHistory.length === 0) {
        showNotification('合并上传', '没有新的历史记录');
        return { success: true, message: '无新增记录' };
      }
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);
      const merged = mergeHistoryRecords(remoteRecords, newHistory);
      await putRemoteBackup(client, merged);
      const maxTime = Math.max(...newHistory.map(r => r.lastVisitTime), Date.now());
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);
      showNotification('合并上传完成', `新增 ${newHistory.length} 条`);
      return { success: true, message: `已合并上传 ${newHistory.length} 条` };
    } catch (err) {
      console.error('合并上传错误', err);
      const errorMsg = err.message || '未知错误';
      showNotification('合并上传失败', errorMsg);
      return { success: false, message: errorMsg };
    }
  }

  async function addHistoryWithLimit(records, concurrency = 5, delayMs = 100) {
    let addedCount = 0;
    const queue = [...records];
    async function worker() {
      while (queue.length) {
        const record = queue.shift();
        await new Promise((resolve) => {
          chrome.history.addUrl({ url: record.url }, () => {
            if (!chrome.runtime.lastError) addedCount++;
            resolve();
          });
        });
        if (delayMs > 0) await new Promise(r => setTimeout(r, delayMs));
      }
    }
    const workers = Array(concurrency).fill().map(() => worker());
    await Promise.all(workers);
    return addedCount;
  }

  async function fullDownload() {
    try {
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);
      if (remoteRecords.length === 0) {
        showNotification('全量下载', '远程无数据');
        return { success: false, message: '无远程数据' };
      }
      const addedCount = await addHistoryWithLimit(remoteRecords, 5, 100);
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, Date.now());
      showNotification('全量下载完成', `导入 ${addedCount} 条（已更新同步时间）`);
      return { success: true, message: `导入了 ${addedCount} 条` };
    } catch (err) {
      showNotification('全量下载失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function fullBackup() {
    try {
      const allHistory = await getHistorySince(0);
      const totalCount = allHistory.length;
      if (totalCount > 50000) {
        showNotification('全量上传', `警告：共 ${totalCount} 条记录，可能耗时较长`);
      }
      const client = await getWebDAVClient();
      await putRemoteBackup(client, allHistory);
      const maxTime = Math.max(...allHistory.map(r => r.lastVisitTime), Date.now());
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);
      showNotification('全量上传完成', `备份 ${totalCount} 条`);
      return { success: true, message: `全量上传 ${totalCount} 条` };
    } catch (err) {
      showNotification('全量上传失败', err.message);
      return { success: false, message: err.message };
    }
  }

  return {
    incrementalBackup,
    fullDownload,
    fullBackup
  };
})();