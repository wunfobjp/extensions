// bookmarks-sync.js - 书签全量备份与恢复（修复根文件夹不可修改问题）
self.BookmarksSync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) {
      throw new Error('请先配置WebDAV参数');
    }
    return new WebDAVClient(url, user, pass);
  }

  async function getRemoteBookmarks(client) {
    const content = await client.getFile(`/${STORAGE_KEYS.BOOKMARKS_BACKUP_FILE}`);
    if (!content) return null;
    try {
      return JSON.parse(content);
    } catch (e) {
      return null;
    }
  }

  async function putRemoteBookmarks(client, bookmarksData) {
    const jsonStr = JSON.stringify(bookmarksData, null, 2);
    return await client.putFile(`/${STORAGE_KEYS.BOOKMARKS_BACKUP_FILE}`, jsonStr);
  }

  async function getFullBookmarksTree() {
    const tree = await chrome.bookmarks.getTree();
    const root = tree[0];
    const topLevelFolders = root.children || [];
    function cleanNode(node) {
      const clean = {
        title: node.title,
        url: node.url || undefined,
        children: node.children ? node.children.map(child => cleanNode(child)) : undefined
      };
      return clean;
    }
    return topLevelFolders.map(folder => cleanNode(folder));
  }

  async function createBookmarkTree(nodes, parentId) {
    for (const node of nodes) {
      if (node.url) {
        await new Promise((resolve) => {
          chrome.bookmarks.create({
            parentId: parentId,
            title: node.title,
            url: node.url
          }, resolve);
        });
      } else {
        const newFolder = await new Promise((resolve) => {
          chrome.bookmarks.create({
            parentId: parentId,
            title: node.title
          }, resolve);
        });
        if (node.children && node.children.length) {
          await createBookmarkTree(node.children, newFolder.id);
        }
      }
    }
  }

  async function clearFolderContent(folderId) {
    const children = await chrome.bookmarks.getChildren(folderId);
    for (const child of children) {
      await chrome.bookmarks.removeTree(child.id);
    }
  }

  async function getTopLevelFolders() {
    const tree = await chrome.bookmarks.getTree();
    const root = tree[0];
    const folders = root.children || [];
    const map = new Map();
    for (const folder of folders) {
      map.set(folder.title, folder.id);
    }
    return map;
  }

  async function fullBackupBookmarks() {
    try {
      const bookmarksTree = await getFullBookmarksTree();
      const client = await getWebDAVClient();
      await putRemoteBookmarks(client, bookmarksTree);
      const size = JSON.stringify(bookmarksTree).length;
      showNotification('书签备份', `已备份 ${size} 字节数据`);
      return { success: true, message: '书签备份成功' };
    } catch (err) {
      showNotification('书签备份失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function fullRestoreBookmarks() {
    try {
      const client = await getWebDAVClient();
      const remoteData = await getRemoteBookmarks(client);
      if (!remoteData || !Array.isArray(remoteData)) {
        showNotification('书签恢复', '远程无有效书签数据');
        return { success: false, message: '远程无有效书签数据' };
      }

      const topLevelMap = await getTopLevelFolders();
      const barId = topLevelMap.get('书签栏') || topLevelMap.get('Bookmarks Bar');
      const otherId = topLevelMap.get('其他书签') || topLevelMap.get('Other Bookmarks');
      const mobileId = topLevelMap.get('移动设备书签') || topLevelMap.get('Mobile Bookmarks');

      if (barId) await clearFolderContent(barId);
      if (otherId) await clearFolderContent(otherId);
      if (mobileId) await clearFolderContent(mobileId);

      for (const folderData of remoteData) {
        let targetId = null;
        if (folderData.title === '书签栏' || folderData.title === 'Bookmarks Bar') targetId = barId;
        else if (folderData.title === '其他书签' || folderData.title === 'Other Bookmarks') targetId = otherId;
        else if (folderData.title === '移动设备书签' || folderData.title === 'Mobile Bookmarks') targetId = mobileId;
        else targetId = barId;

        if (targetId && folderData.children) {
          await createBookmarkTree(folderData.children, targetId);
        }
      }

      showNotification('书签恢复', '书签已从云端恢复');
      return { success: true, message: '书签恢复成功' };
    } catch (err) {
      console.error(err);
      showNotification('书签恢复失败', err.message);
      return { success: false, message: err.message };
    }
  }

  return {
    fullBackupBookmarks,
    fullRestoreBookmarks
  };
})();