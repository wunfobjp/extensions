// common.js - 全局工具函数和常量
self.Common = (function() {
  const STORAGE_KEYS = {
    WEBDAV_URL: 'webdav_url',
    WEBDAV_USER: 'webdav_user',
    WEBDAV_PASS: 'webdav_pass',
    LAST_SYNC_TIME: 'last_sync_time',
    HISTORY_BACKUP_FILE: 'history_backup.json',
    BOOKMARKS_BACKUP_FILE: 'bookmarks_backup.json'
  };

  async function getStorage(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }

  async function setStorage(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  function showNotification(title, message, type = 'basic') {
    chrome.notifications.create({
      type: type,
      iconUrl: 'icons/icon48.png',
      title: title,
      message: message,
      priority: 2
    });
  }

  return {
    STORAGE_KEYS,
    getStorage,
    setStorage,
    showNotification
  };
})();