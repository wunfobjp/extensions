// background.js - Service Worker
importScripts('common.js', 'webdav-client.js', 'history-sync.js', 'bookmarks-sync.js');

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'incrementalBackup') {
    self.HistorySync.incrementalBackup().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'fullDownload') {
    self.HistorySync.fullDownload().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'fullBackup') {
    self.HistorySync.fullBackup().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'backupBookmarks') {
    self.BookmarksSync.fullBackupBookmarks().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'restoreBookmarks') {
    self.BookmarksSync.fullRestoreBookmarks().then(result => sendResponse(result));
    return true;
  }
  return false;
});