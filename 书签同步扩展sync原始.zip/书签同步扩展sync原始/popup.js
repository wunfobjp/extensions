const DEFAULT_SETTINGS = {
  url: '',
  username: '',
  password: '',
  syncMode: 'merge',
  autoSync: false,
  interval: 60,
  remotePath: '/bookmarks.json',
  swapBookmarkMobile: false
};

// 加载设置到表单
async function loadSettings() {
  const result = await chrome.storage.sync.get('settings');
  const settings = result.settings || DEFAULT_SETTINGS;
  
  document.getElementById('url').value = settings.url || '';
  document.getElementById('username').value = settings.username || '';
  document.getElementById('password').value = settings.password || '';
  document.getElementById('remotePath').value = settings.remotePath || '/bookmarks.json';
  document.getElementById('syncMode').value = settings.syncMode || 'merge';
  document.getElementById('autoSync').checked = settings.autoSync || false;
  document.getElementById('interval').value = settings.interval || 60;
  document.getElementById('swapBookmarkMobile').checked = settings.swapBookmarkMobile || false;
  
  if (settings.lastSync) {
    document.getElementById('status').textContent = `✅ 上次同步: ${new Date(settings.lastSync).toLocaleString()}`;
  } else {
    document.getElementById('status').textContent = '⏳ 尚未同步';
  }
  
  // 刷新统计
  await refreshStats();
}

// 刷新本地/远程书签统计
async function refreshStats() {
  try {
    // 获取本地书签数量
    const localCount = await chrome.runtime.sendMessage({ action: 'getLocalBookmarkCount' });
    document.getElementById('localBookmarkCount').textContent = localCount || 0;
    
    // 尝试获取远程书签数量（需配置有效）
    const settings = (await chrome.storage.sync.get('settings')).settings || DEFAULT_SETTINGS;
    if (settings.url) {
      try {
        const remoteCount = await chrome.runtime.sendMessage({ action: 'getRemoteBookmarkCount' });
        document.getElementById('remoteBookmarkCount').textContent = remoteCount !== null ? remoteCount : '?';
      } catch {
        document.getElementById('remoteBookmarkCount').textContent = '?';
      }
    } else {
      document.getElementById('remoteBookmarkCount').textContent = '-';
    }
  } catch (e) {
    console.warn('刷新统计失败:', e);
  }
}

// 保存设置
async function saveSettings() {
  const settings = {
    url: document.getElementById('url').value.trim(),
    username: document.getElementById('username').value.trim(),
    password: document.getElementById('password').value,
    remotePath: document.getElementById('remotePath').value.trim() || '/bookmarks.json',
    syncMode: document.getElementById('syncMode').value,
    autoSync: document.getElementById('autoSync').checked,
    interval: parseInt(document.getElementById('interval').value, 10),
    swapBookmarkMobile: document.getElementById('swapBookmarkMobile').checked
  };
  
  const old = await chrome.storage.sync.get('settings');
  if (old.settings?.lastSync) {
    settings.lastSync = old.settings.lastSync;
  }
  
  await chrome.storage.sync.set({ settings });
  chrome.runtime.sendMessage({ action: 'updateAlarm' });
  
  const statusEl = document.getElementById('status');
  statusEl.textContent = '💾 设置已保存';
  statusEl.classList.remove('error');
  setTimeout(() => loadSettings(), 800);
}

// 手动同步
async function syncNow() {
  const statusEl = document.getElementById('status');
  statusEl.textContent = '⏳ 同步中...';
  statusEl.classList.remove('error');
  
  try {
    const response = await chrome.runtime.sendMessage({ action: 'sync' });
    if (response.success) {
      statusEl.textContent = '✅ 同步成功';
    } else {
      statusEl.textContent = `❌ 同步失败: ${response.error}`;
      statusEl.classList.add('error');
    }
  } catch (e) {
    statusEl.textContent = `❌ 同步失败: ${e.message}`;
    statusEl.classList.add('error');
  }
  await refreshStats();
  setTimeout(() => loadSettings(), 1500);
}

// 独立上传
async function uploadOnly() {
  const statusEl = document.getElementById('status');
  statusEl.textContent = '⏳ 上传中...';
  statusEl.classList.remove('error');
  
  try {
    const response = await chrome.runtime.sendMessage({ action: 'upload' });
    if (response.success) {
      statusEl.textContent = '✅ 书签已上传到 WebDAV';
    } else {
      statusEl.textContent = `❌ 上传失败: ${response.error}`;
      statusEl.classList.add('error');
    }
  } catch (e) {
    statusEl.textContent = `❌ 上传失败: ${e.message}`;
    statusEl.classList.add('error');
  }
  await refreshStats();
  setTimeout(() => loadSettings(), 1500);
}

// 独立下载
async function downloadOnly() {
  const statusEl = document.getElementById('status');
  statusEl.textContent = '⏳ 下载中...';
  statusEl.classList.remove('error');
  
  try {
    const response = await chrome.runtime.sendMessage({ action: 'download' });
    if (response.success) {
      statusEl.textContent = '✅ 已从 WebDAV 下载并替换本地书签';
    } else {
      statusEl.textContent = `❌ 下载失败: ${response.error}`;
      statusEl.classList.add('error');
    }
  } catch (e) {
    statusEl.textContent = `❌ 下载失败: ${e.message}`;
    statusEl.classList.add('error');
  }
  await refreshStats();
  setTimeout(() => loadSettings(), 1500);
}

// 清空书签
async function clearBookmarks() {
  if (!confirm('⚠️ 确定要清空所有书签吗？（书签栏、其他书签、移动书签将被完全清空）')) return;
  
  const statusEl = document.getElementById('status');
  statusEl.textContent = '⏳ 清空中...';
  statusEl.classList.remove('error');
  
  try {
    const response = await chrome.runtime.sendMessage({ action: 'clearAllBookmarks' });
    if (response.success) {
      statusEl.textContent = '✅ 书签已清空';
    } else {
      statusEl.textContent = `❌ 清空失败: ${response.error}`;
      statusEl.classList.add('error');
    }
  } catch (e) {
    statusEl.textContent = `❌ 清空失败: ${e.message}`;
    statusEl.classList.add('error');
  }
  await refreshStats();
  setTimeout(() => loadSettings(), 1500);
}

// 绑定事件
document.addEventListener('DOMContentLoaded', loadSettings);
document.getElementById('save').addEventListener('click', saveSettings);
document.getElementById('syncNow').addEventListener('click', syncNow);
document.getElementById('uploadBtn').addEventListener('click', uploadOnly);
document.getElementById('downloadBtn').addEventListener('click', downloadOnly);
document.getElementById('clearBookmarksBtn').addEventListener('click', clearBookmarks);